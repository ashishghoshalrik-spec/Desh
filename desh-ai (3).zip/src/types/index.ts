export type ActiveTab = 'chat' | 'call' | 'ipphone' | 'writer' | 'translator' | 'quiz' | 'prompts';

export interface HotlineContact {
  number: string;
  name: string;
  subtitle: string;
  category: 'emergency' | 'govt' | 'ai' | 'health' | 'edu';
  icon: string;
  voicePrompt: string;
  avatar?: string;
}

export interface CallHistoryItem {
  id: string;
  number: string;
  name: string;
  timestamp: number;
  durationSeconds: number;
  type: 'incoming' | 'outgoing' | 'missed';
  avatar?: string;
}

export interface ScheduledCall {
  id: string;
  contactName: string;
  contactNumber: string;
  scheduledTime: number; // unix timestamp in ms
  note?: string;
  createdAt: number;
  status: 'pending' | 'completed' | 'cancelled';
  avatar?: string;
  reminded?: boolean;
}

export interface SavedContact {
  id: string;
  name: string;
  number: string;
  category?: string;
  note?: string;
  avatar?: string;
  createdAt: number;
}

export interface CallRecordingItem {
  id: string;
  contactName: string;
  contactNumber: string;
  timestamp: number;
  durationSeconds: number;
  audioBlob: Blob;
  sizeBytes: number;
  mimeType: string;
  avatar?: string;
  transcriptSummary?: string;
}

export type PersonaId = 'general' | 'bcs' | 'writer' | 'coder' | 'translator' | 'agriculture';

export interface Persona {
  id: PersonaId;
  name: string;
  nameEn: string;
  badge: string;
  icon: string;
  description: string;
  placeholder: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  timestamp: number;
  persona?: PersonaId;
  audioUrl?: string;
}

export interface QuizQuestion {
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  topic?: string;
  userSelection?: number;
}

export type TranslationMode = 'bn-to-en' | 'en-to-bn' | 'sadhu-to-cholito' | 'grammar-check';

export interface WriterTemplate {
  id: string;
  title: string;
  category: 'formal' | 'creative' | 'business' | 'social';
  description: string;
  promptExample: string;
}

export interface IpExtension {
  extension: string;
  sipUri: string;
  name: string;
  department: string;
  status: 'online' | 'busy' | 'away';
  voicePrompt: string;
  personaPrompt: string;
  voiceName?: 'Zephyr' | 'Kore' | 'Puck' | 'Charon' | 'Fenrir';
  description: string;
  codec: string;
  pingMs: number;
}

export interface IpCallRecord {
  id: string;
  extension: string;
  sipUri: string;
  callerName: string;
  timestamp: number;
  durationSeconds: number;
  status: 'completed' | 'missed' | 'rejected';
  direction: 'outgoing' | 'incoming';
  codec: string;
  jitterMs: number;
}

