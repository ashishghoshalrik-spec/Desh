import React, { useState } from 'react';
import { 
  Languages, 
  ArrowLeftRight, 
  Sparkles, 
  Copy, 
  Check, 
  RefreshCw, 
  CheckCircle2, 
  BookA, 
  Volume2
} from 'lucide-react';
import { TranslationMode } from '../types';
import { MarkdownView } from './MarkdownView';

const MODES: { id: TranslationMode; title: string; subtitle: string; icon: string }[] = [
  {
    id: 'bn-to-en',
    title: 'বাংলা ➔ ইংরেজি',
    subtitle: 'সাবলীল ও স্বাভাবিক ইংরেজি ভাবানুবাদ',
    icon: 'Languages',
  },
  {
    id: 'en-to-bn',
    title: 'English ➔ বাংলা',
    subtitle: 'প্রমিত ও মধুর বাংলা রূপান্তর',
    icon: 'Languages',
  },
  {
    id: 'sadhu-to-cholito',
    title: 'সাধু ➔ চলিত রূপান্তর',
    subtitle: 'প্রাচীন বা প্রাতিষ্ঠানিক সাধু থেকে আধুনিক চলিত',
    icon: 'BookA',
  },
  {
    id: 'grammar-check',
    title: 'বানান ও ব্যাকরণ শোধক',
    subtitle: 'বাংলা একাডেমি প্রমিত নিয়মানুযায়ী শুদ্ধিকরণ',
    icon: 'CheckCircle2',
  },
];

const SAMPLE_TEXTS: Record<TranslationMode, string> = {
  'bn-to-en': 'আমাদের দেশের নদীমাতৃক রূপ এবং গ্রামীণ মেঠোপথ মনের গভীরে অদ্ভুত এক প্রশান্তি জাগিয়ে তোলে।',
  'en-to-bn': 'Artificial intelligence has the tremendous potential to revolutionize education and healthcare across developing nations.',
  'sadhu-to-cholito': 'তিনি অত্যন্ত নিষ্ঠার সহিত নিজ দায়িত্ব পালন করিতেছিলেন এবং কাহাকেও কোনো অনুযোগ করিতে দেন নাই।',
  'grammar-check': 'ইতিপূর্বে তার সাথে আমার সাক্ষাত হয়েছিল কিন্তু সে কোন কথা বলেনি, শুধুমাত্র নীরব দর্শকের মতন দাড়িয়ে ছিলো।',
};

export const TranslatorTab: React.FC = () => {
  const [mode, setMode] = useState<TranslationMode>('bn-to-en');
  const [inputText, setInputText] = useState(SAMPLE_TEXTS['bn-to-en']);
  const [outputText, setOutputText] = useState('');
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleModeChange = (newMode: TranslationMode) => {
    setMode(newMode);
    setInputText(SAMPLE_TEXTS[newMode]);
    setOutputText('');
  };

  const handleSwap = () => {
    if (mode === 'bn-to-en') {
      setMode('en-to-bn');
      const currentOutput = outputText;
      setInputText(currentOutput || SAMPLE_TEXTS['en-to-bn']);
      setOutputText('');
    } else if (mode === 'en-to-bn') {
      setMode('bn-to-en');
      const currentOutput = outputText;
      setInputText(currentOutput || SAMPLE_TEXTS['bn-to-en']);
      setOutputText('');
    }
  };

  const handleTranslate = async () => {
    if (!inputText.trim() || loading) return;

    setLoading(true);
    try {
      const res = await fetch('/api/translate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: inputText,
          mode,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'অনুবাদ করা সম্ভব হয়নি');

      setOutputText(data.result);
    } catch (err: any) {
      alert(err.message || 'অনুবাদে সমস্যা হয়েছে');
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = () => {
    if (!outputText) return;
    navigator.clipboard.writeText(outputText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSpeech = (text: string) => {
    if (!text || !('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = mode === 'bn-to-en' ? 'en-US' : 'bn-BD';
    window.speechSynthesis.speak(utterance);
  };

  return (
    <div className="max-w-6xl mx-auto px-3 sm:px-6 py-6 space-y-6">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white flex items-center gap-2.5">
            <Languages className="text-emerald-600 dark:text-emerald-400" />
            অনুবাদ ও ব্যাকরণ নিরীক্ষাগার
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            বাংলা ও ইংরেজির নির্ভুল রূপান্তর, সাধু-চলিত রূপান্তর এবং বাংলা একাডেমি নিয়মানুযায়ী বানান শুদ্ধিকরণ
          </p>
        </div>
      </div>

      {/* Mode Selector */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5">
        {MODES.map((item) => {
          const active = mode === item.id;
          return (
            <button
              key={item.id}
              onClick={() => handleModeChange(item.id)}
              className={`p-3.5 rounded-2xl text-left border transition-all ${
                active
                  ? 'bg-emerald-600 text-white border-emerald-600 shadow-md shadow-emerald-700/20 font-semibold'
                  : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:border-emerald-500/40 hover:bg-slate-50 dark:hover:bg-slate-800/50'
              }`}
            >
              <div className="font-bold text-sm sm:text-base flex items-center justify-between">
                <span>{item.title}</span>
                {active && <Check size={16} />}
              </div>
              <p
                className={`text-[11px] mt-1 line-clamp-1 ${
                  active ? 'text-emerald-100' : 'text-slate-500 dark:text-slate-400'
                }`}
              >
                {item.subtitle}
              </p>
            </button>
          );
        })}
      </div>

      {/* Side by side Translation Panels */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-stretch">
        {/* Left: Input Panel */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800 text-xs font-bold text-slate-600 dark:text-slate-300">
              <span>
                {mode === 'bn-to-en' && 'বাংলা টেক্সট লিখুন'}
                {mode === 'en-to-bn' && 'Enter English Text'}
                {mode === 'sadhu-to-cholito' && 'সাধু ভাষার অনুচ্ছেদ দিন'}
                {mode === 'grammar-check' && 'যাচাই করার জন্য বাংলা টেক্সট দিন'}
              </span>
              {(mode === 'bn-to-en' || mode === 'en-to-bn') && (
                <button
                  onClick={handleSwap}
                  className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400 hover:underline"
                  title="ভাষা অদল-বদল করুন"
                >
                  <ArrowLeftRight size={13} />
                  <span>অদল-বদল</span>
                </button>
              )}
            </div>

            <textarea
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="এখানে আপনার টেক্সট পেস্ট করুন বা লিখুন..."
              rows={8}
              className="w-full mt-3 bg-transparent border-0 focus:outline-none text-sm md:text-base text-slate-900 dark:text-slate-100 placeholder:text-slate-400 leading-relaxed resize-none"
            />
          </div>

          <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
            <span className="text-xs text-slate-400">
              {inputText.length} অক্ষর • {inputText.trim() ? inputText.trim().split(/\s+/).length : 0} শব্দ
            </span>

            <div className="flex items-center gap-2">
              <button
                onClick={() => handleSpeech(inputText)}
                title="শুনুন"
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              >
                <Volume2 size={16} />
              </button>
              <button
                onClick={handleTranslate}
                disabled={!inputText.trim() || loading}
                className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-1.5 transition-all shadow-sm ${
                  inputText.trim() && !loading
                    ? 'bg-emerald-600 hover:bg-emerald-700 text-white active:scale-95'
                    : 'bg-slate-200 dark:bg-slate-800 text-slate-400 cursor-not-allowed'
                }`}
              >
                {loading ? (
                  <>
                    <RefreshCw size={14} className="animate-spin" />
                    <span>প্রক্রিয়াধীন...</span>
                  </>
                ) : (
                  <>
                    <Sparkles size={14} />
                    <span>
                      {mode === 'grammar-check' ? 'বানান পরীক্ষা করুন' : 'অনুবাদ করুন'}
                    </span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Right: Output Panel */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800 text-xs font-bold text-slate-600 dark:text-slate-300">
              <span>
                {mode === 'bn-to-en' && 'English Translation'}
                {mode === 'en-to-bn' && 'বাংলা অনুবাদ'}
                {mode === 'sadhu-to-cholito' && 'প্রমিত চলিত রূপ'}
                {mode === 'grammar-check' && 'সংশোধিত রূপ ও ভুলের বিশ্লেষণ'}
              </span>

              {outputText && (
                <button
                  onClick={handleCopy}
                  className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400 hover:underline"
                >
                  {copied ? <Check size={13} /> : <Copy size={13} />}
                  <span>{copied ? 'কপি হয়েছে' : 'কপি করুন'}</span>
                </button>
              )}
            </div>

            <div className="mt-3 min-h-[190px]">
              {outputText ? (
                <MarkdownView content={outputText} />
              ) : (
                <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-400">
                  <Languages size={32} className="text-slate-300 dark:text-slate-700 mb-2" />
                  <p className="text-xs sm:text-sm">
                    {mode === 'grammar-check'
                      ? 'বামপাশে আপনার বাংলা টেক্সট লিখে যাচাই করুন বাটনে চাপুন।'
                      : 'অনুবাদ দেখতে উপরের বাটনে চাপুন।'}
                  </p>
                </div>
              )}
            </div>
          </div>

          {outputText && (
            <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
              <span className="text-xs text-slate-400">
                {outputText.length} অক্ষর
              </span>
              <button
                onClick={() => handleSpeech(outputText)}
                title="শুনুন"
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              >
                <Volume2 size={16} />
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
