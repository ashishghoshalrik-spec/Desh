import React, { useState, useEffect, useRef } from 'react';
import { 
  Phone, 
  PhoneOff, 
  PhoneCall, 
  PhoneForwarded,
  Mic, 
  MicOff, 
  Volume2, 
  VolumeX, 
  Radio, 
  Activity, 
  Clock, 
  Wifi, 
  Server, 
  Settings2, 
  History, 
  Trash2, 
  RotateCcw, 
  Layers, 
  Sparkles, 
  CheckCircle2, 
  AlertCircle, 
  ShieldCheck, 
  User, 
  Globe, 
  CornerDownRight, 
  Pause, 
  Play, 
  Headphones, 
  Zap, 
  Search,
  Hash,
  ChevronRight,
  Info
} from 'lucide-react';
import { IpExtension, IpCallRecord } from '../types';
import { 
  playDtmfTone, 
  PhoneRinger, 
  floatTo16BitPCM, 
  arrayBufferToBase64, 
  playSipConnectedChime,
  IpHoldMusic 
} from '../utils/audio';

// Predefined Enterprise IP Extensions
const IP_EXTENSIONS: IpExtension[] = [
  {
    extension: '101',
    sipUri: 'sip:assistant@desh.ip:5060',
    name: 'দেশ AI মূল অপারেটর',
    department: 'সাধারণ ও বহুমুখী সেবা',
    status: 'online',
    voicePrompt: 'আসসালামু আলাইকুম! দেশ AI এন্টারপ্রাইজ আইপি ফোন সিস্টেমে আপনাকে স্বাগতম। আমি কীভাবে আপনাকে সহায়তা করতে পারি?',
    personaPrompt: 'তুমি দেশ AI এন্টারপ্রাইজ আইপি ফোন সিস্টেমের প্রধান ভয়েস অপারেটর। অত্যন্ত মার্জিত, প্রমিত ও স্পষ্ট বাংলায় কথা বলো। উত্তর টেলিফোন কলারদের জন্য সংক্ষিপ্ত ও শ্রুতিমধুর রাখো।',
    voiceName: 'Zephyr',
    description: 'দৈনন্দিন জিজ্ঞাসা, তথ্য, পরিকল্পনা ও বুদ্ধিবৃত্তিক সহায়তা',
    codec: 'PCM-16K/24K HD',
    pingMs: 18,
  },
  {
    extension: '102',
    sipUri: 'sip:bcs@desh.ip:5060',
    name: 'বিসিএস ও পিএসসি ক্যারিয়ার কোচ',
    department: 'শিক্ষা ও ক্যারিয়ার প্রস্তুতি',
    status: 'online',
    voicePrompt: 'বিসিএস ও সরকারি চাকরি প্রস্তুতি লাইভ আইপি ডেস্কে স্বাগতম! প্রিলিমিনারি বা ভাইভার কোন বিষয়ে প্রশ্ন আছে?',
    personaPrompt: 'তুমি বিসিএস ও সরকারি চাকরির সিনিয়র মেন্টর। শিক্ষার্থীদের প্রশ্নের তাৎক্ষণিক নির্ভুল ও অনুপ্রেরণাদায়ী উত্তর বাংলায় মুখে বলো।',
    voiceName: 'Kore',
    description: 'বিসিএস প্রিলিমিনারি, লিখিত, ভাইভা টিপস ও বিষয়ভিত্তিক জ্ঞান',
    codec: 'PCM-16K/24K HD',
    pingMs: 22,
  },
  {
    extension: '103',
    sipUri: 'sip:krishi@desh.ip:5060',
    name: 'কৃষি ও কৃষক ডিজিটাল হেল্পলাইন',
    department: 'কৃষি ও গ্রামীণ অর্থনীতি',
    status: 'online',
    voicePrompt: 'কৃষি সম্প্রসারণ ও কৃষক বন্ধু আইপি সেন্টারে স্বাগতম! আপনার ফসল বা খামার বিষয়ে বলুন।',
    personaPrompt: 'তুমি বাংলাদেশ কৃষি তথ্য সার্ভিসের জরুরি আইপি কল সেন্টার কর্মকর্তা। কৃষকের প্রশ্নের সহজ, বাস্তবসম্মত ও আন্তরিক বাংলা পরামর্শ দাও।',
    voiceName: 'Zephyr',
    description: 'ধান, সবজি, ফল, সার-কীটনাশক, মাছ ও ডেইরি খামার পরামর্শ',
    codec: 'PCM-16K/24K HD',
    pingMs: 25,
  },
  {
    extension: '104',
    sipUri: 'sip:legal@desh.ip:5060',
    name: 'নাগরিক অধিকার ও আইনি লাইভ ডেস্ক',
    department: 'আইন ও নাগরিক সেবা',
    status: 'online',
    voicePrompt: 'নাগরিক ও আইনি তথ্য আইপি হেল্পলাইনে স্বাগতম। আপনি কোন আইনি বিষয়ে দিকনির্দেশনা চান?',
    personaPrompt: 'তুমি নাগরিক অধিকার ও আইনি তথ্য বিশেষজ্ঞ। সংক্ষেপে আইনি দিক বুঝিয়ে বলো এবং প্রয়োজনে আইনজীবীর শরণাপন্ন হওয়ার পরামর্শ দাও।',
    voiceName: 'Puck',
    description: 'সংবিধান, মৌলিক অধিকার, জমিজমা ও প্রাথমিক আইনি তথ্য',
    codec: 'PCM-16K/24K HD',
    pingMs: 20,
  },
  {
    extension: '105',
    sipUri: 'sip:health@desh.ip:5060',
    name: 'ডিজিটাল স্বাস্থ্য ও টেলিমেডিসিন',
    department: 'স্বাস্থ্য ও পুষ্টি সেবা',
    status: 'online',
    voicePrompt: 'ডিজিটাল স্বাস্থ্য ও পুষ্টি আইপি সেবায় স্বাগতম। আপনার শারীরিক কোনো সমস্যা বা সুস্থতার পরামর্শ প্রয়োজন?',
    personaPrompt: 'তুমি প্রাথমিক স্বাস্থ্য ও পুষ্টি বিষয়ক তথ্য প্রদানকারী। চিকিৎসকের পরামর্শ নেওয়ার কথা মনে করিয়ে দিয়ে সাধারণ স্বাস্থ্য জ্ঞান শেয়ার করো।',
    voiceName: 'Kore',
    description: 'প্রাথমিক চিকিৎসা, পথ্য, পুষ্টি ও স্বাস্থ্য সচেতনতা',
    codec: 'PCM-16K/24K HD',
    pingMs: 21,
  },
  {
    extension: '106',
    sipUri: 'sip:english@desh.ip:5060',
    name: 'স্পোকেন ইংলিশ ও দ্বিভাষিক ট্রেইনার',
    department: 'ভাষা শিক্ষা ও দক্ষতা',
    status: 'online',
    voicePrompt: 'Hello and Welcome! Let us practice spoken English together or translate between Bangla and English.',
    personaPrompt: 'You are an engaging spoken English and bilingual practice partner. Correct user mistakes politely and converse naturally in English and Bangla.',
    voiceName: 'Zephyr',
    description: 'দৈনন্দিন ইংরেজি কথপোকথন, উচ্চারণ ও দ্বিভাষিক প্র্যাকটিস',
    codec: 'PCM-16K/24K HD',
    pingMs: 19,
  },
  {
    extension: '107',
    sipUri: 'sip:dev@desh.ip:5060',
    name: 'আইটি, ক্লাউড ও সফটওয়্যার সাপোর্ট',
    department: 'প্রযুক্তি ও ডেভেলপমেন্ট',
    status: 'online',
    voicePrompt: 'আইটি ও সফটওয়্যার সাপোর্ট ডেস্কে স্বাগতম! কোডিং, সিস্টেম ডিজাইন বা বাগ ফিক্সিং নিয়ে কথা বলুন।',
    personaPrompt: 'তুমি একজন অভিজ্ঞ ফুলস্ট্যাক আর্কিটেক্ট ও টেকনিক্যাল ট্রাবলশুটার। কোড, সিস্টেম ডিজাইন ও এরর সমাধান বাংলায় বুঝিয়ে দাও।',
    voiceName: 'Puck',
    description: 'প্রোগ্রামিং, ওয়েব ডেভেলপমেন্ট, ডাটাবেস ও সিস্টেম আর্কিটেকচার',
    codec: 'PCM-16K/24K HD',
    pingMs: 24,
  },
  {
    extension: '108',
    sipUri: 'sip:citizen@desh.ip:5060',
    name: 'বাংলাদেশ সরকারি সেবা ও এনআইডি ডেস্ক',
    department: 'ই-গভর্নেন্স ও নাগরিক পোর্টাল',
    status: 'online',
    voicePrompt: 'বাংলাদেশ সরকারি ই-সেবা তথ্য ডেস্কে স্বাগতম! পাসপোর্ট, জন্মনিবন্ধন বা এনআইডি সেবা বিষয়ে কী জানতে চান?',
    personaPrompt: 'তুমি বাংলাদেশ সরকারের ডিজিটাল নাগরিক সেবা বিশেষজ্ঞ। পাসপোর্ট, এনআইডি, জন্মনিবন্ধন ও সরকারি পোর্টালের তথ্য বুঝিয়ে বলো।',
    voiceName: 'Zephyr',
    description: 'পাসপোর্ট, এনআইডি কার্ড, ড্রাইভিং লাইসেন্স ও অনলাইন সেবা',
    codec: 'PCM-16K/24K HD',
    pingMs: 23,
  },
];

const KEYPAD_DIGITS = [
  { key: '1', sub: 'VOIP' },
  { key: '2', sub: 'BCS' },
  { key: '3', sub: 'AGRI' },
  { key: '4', sub: 'LAW' },
  { key: '5', sub: 'MED' },
  { key: '6', sub: 'LANG' },
  { key: '7', sub: 'CODE' },
  { key: '8', sub: 'GOV' },
  { key: '9', sub: 'SIP' },
  { key: '*', sub: 'LINE 1' },
  { key: '0', sub: '+' },
  { key: '#', sub: 'SEND' },
];

export const IpPhoneCall: React.FC = () => {
  // Input Dialing state
  const [dialTarget, setDialTarget] = useState<string>('101');
  const [selectedVoice, setSelectedVoice] = useState<'Zephyr' | 'Kore' | 'Puck'>('Zephyr');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Call States
  const [inCall, setInCall] = useState(false);
  const [callStatus, setCallStatus] = useState<'idle' | 'calling' | 'ringing' | 'connected' | 'hold' | 'ended'>('idle');
  const [activeExtension, setActiveExtension] = useState<IpExtension | null>(null);
  const [callDuration, setCallDuration] = useState(0);
  const [activeLine, setActiveLine] = useState<'line1' | 'line2'>('line1');
  
  // Controls
  const [isMuted, setIsMuted] = useState(false);
  const [speakerOn, setSpeakerOn] = useState(true);
  const [isOnHold, setIsOnHold] = useState(false);
  const [showKeypadOverlay, setShowKeypadOverlay] = useState(false);
  const [showSettingsModal, setShowSettingsModal] = useState(false);
  
  // Network / Hardware metrics
  const [latencyMs, setLatencyMs] = useState(21);
  const [jitterMs, setJitterMs] = useState(2);
  const [packetLoss, setPacketLoss] = useState(0);
  const [transcript, setTranscript] = useState<string[]>([]);
  const [aiSpeaking, setAiSpeaking] = useState(false);
  const [micActivity, setMicActivity] = useState(0);

  // Call Records State
  const [callRecords, setCallRecords] = useState<IpCallRecord[]>(() => {
    const saved = localStorage.getItem('desh_ip_call_records');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {}
    }
    return [
      {
        id: 'ip-rec-1',
        extension: '101',
        sipUri: 'sip:assistant@desh.ip:5060',
        callerName: 'দেশ AI মূল অপারেটর',
        timestamp: Date.now() - 3600000 * 2,
        durationSeconds: 94,
        status: 'completed',
        direction: 'outgoing',
        codec: 'PCM-16K/24K HD',
        jitterMs: 2,
      },
      {
        id: 'ip-rec-2',
        extension: '102',
        sipUri: 'sip:bcs@desh.ip:5060',
        callerName: 'বিসিএস ও পিএসসি ক্যারিয়ার কোচ',
        timestamp: Date.now() - 86400000,
        durationSeconds: 156,
        status: 'completed',
        direction: 'outgoing',
        codec: 'PCM-16K/24K HD',
        jitterMs: 3,
      },
    ];
  });

  // Audio References
  const wsRef = useRef<WebSocket | null>(null);
  const ringerRef = useRef<PhoneRinger | null>(null);
  const holdMusicRef = useRef<IpHoldMusic | null>(null);
  const timerIntervalRef = useRef<any>(null);
  const inputAudioCtxRef = useRef<AudioContext | null>(null);
  const outputAudioCtxRef = useRef<AudioContext | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const isMutedRef = useRef(false);
  const isOnHoldRef = useRef(false);
  const inCallRef = useRef(false);
  const hasReceivedLiveAudioRef = useRef(false);
  const nextScheduledTimeRef = useRef(0);
  const activeSourcesRef = useRef<AudioBufferSourceNode[]>([]);
  const transcriptEndRef = useRef<HTMLDivElement | null>(null);

  isMutedRef.current = isMuted;
  isOnHoldRef.current = isOnHold;
  inCallRef.current = inCall;

  // Persist Call records
  useEffect(() => {
    localStorage.setItem('desh_ip_call_records', JSON.stringify(callRecords));
  }, [callRecords]);

  // Auto scroll transcript
  useEffect(() => {
    transcriptEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [transcript]);

  // Periodic simulated network latency jitter
  useEffect(() => {
    if (inCall && callStatus === 'connected') {
      const interval = setInterval(() => {
        setLatencyMs(Math.floor(18 + Math.random() * 8));
        setJitterMs(Math.floor(1 + Math.random() * 3));
      }, 4000);
      return () => clearInterval(interval);
    }
  }, [inCall, callStatus]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      terminateCall();
    };
  }, []);

  // Format MM:SS duration
  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const remainder = secs % 60;
    return `${mins.toString().padStart(2, '0')}:${remainder.toString().padStart(2, '0')}`;
  };

  // Play gapless 24kHz PCM chunk received from server
  const playLivePCMChunk = (base64Data: string) => {
    if (isOnHoldRef.current) return;
    try {
      if (!outputAudioCtxRef.current || outputAudioCtxRef.current.state === 'closed') {
        const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
        outputAudioCtxRef.current = new AudioCtxClass({ sampleRate: 24000 });
      }
      const ctx = outputAudioCtxRef.current;
      if (ctx.state === 'suspended') {
        ctx.resume();
      }

      // Convert base64 to 16-bit PCM then Float32Array
      const binaryString = atob(base64Data);
      const len = binaryString.length;
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }
      const int16Array = new Int16Array(bytes.buffer);
      const float32Array = new Float32Array(int16Array.length);
      for (let i = 0; i < int16Array.length; i++) {
        float32Array[i] = int16Array[i] / 32768.0;
      }

      const audioBuffer = ctx.createBuffer(1, float32Array.length, 24000);
      audioBuffer.copyToChannel(float32Array, 0);

      const source = ctx.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(ctx.destination);

      const now = ctx.currentTime;
      if (nextScheduledTimeRef.current < now) {
        nextScheduledTimeRef.current = now;
      }

      source.start(nextScheduledTimeRef.current);
      nextScheduledTimeRef.current += audioBuffer.duration;

      activeSourcesRef.current.push(source);
      source.onended = () => {
        const idx = activeSourcesRef.current.indexOf(source);
        if (idx > -1) activeSourcesRef.current.splice(idx, 1);
        if (activeSourcesRef.current.length === 0) {
          setAiSpeaking(false);
        }
      };
    } catch (e) {
      console.error('Audio playback error:', e);
    }
  };

  const stopActiveAudioSources = () => {
    try {
      for (const s of activeSourcesRef.current) {
        try {
          s.stop();
        } catch (e) {}
      }
      activeSourcesRef.current = [];
      nextScheduledTimeRef.current = 0;
      setAiSpeaking(false);
    } catch (e) {}
  };

  const playBase64AudioChunk = (base64Audio: string) => {
    try {
      const audioUrl = base64Audio.startsWith('data:') ? base64Audio : `data:audio/wav;base64,${base64Audio}`;
      const audio = new Audio(audioUrl);
      setAiSpeaking(true);
      audio.onended = () => setAiSpeaking(false);
      audio.play().catch((e) => console.warn('Audio playback error:', e));
    } catch (e) {
      console.error('Failed to play base64 audio:', e);
    }
  };

  const playIpGreetingTTS = async (text: string, voiceName?: string) => {
    if (!text || isOnHoldRef.current) return;
    setAiSpeaking(true);
    try {
      const res = await fetch('/api/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text, voice: voiceName || 'Zephyr' }),
      });
      if (res.ok) {
        const data = await res.json();
        if (data.audio) {
          playBase64AudioChunk(data.audio);
          return;
        }
      }
    } catch (e) {
      console.warn('IP Phone TTS greeting error:', e);
    }
    if ('speechSynthesis' in window) {
      const u = new SpeechSynthesisUtterance(text);
      u.lang = 'bn-BD';
      u.onend = () => setAiSpeaking(false);
      window.speechSynthesis.speak(u);
    }
  };

  // Start Call Initiation
  const startIpCall = (target: string) => {
    if (inCall) return;
    const cleanTarget = target.trim();
    if (!cleanTarget) return;

    // Resolve extension details or custom SIP target
    const matched = IP_EXTENSIONS.find(
      (e) => e.extension === cleanTarget || e.sipUri.toLowerCase().includes(cleanTarget.toLowerCase())
    );

    const ext: IpExtension = matched || {
      extension: cleanTarget,
      sipUri: cleanTarget.includes('@') ? cleanTarget : `sip:${cleanTarget}@desh.ip:5060`,
      name: cleanTarget.includes('@') ? cleanTarget.split('@')[0] : `SIP Extension ${cleanTarget}`,
      department: 'Custom IP Endpoint',
      status: 'online',
      voicePrompt: 'Hello! You are connected to Desh AI IP Phone SIP Gateway.',
      personaPrompt: 'You are a professional enterprise VoIP voice operator for Desh AI.',
      voiceName: selectedVoice,
      description: 'Direct SIP / VoIP Call',
      codec: 'PCM-16K/24K HD',
      pingMs: 20,
    };

    setActiveExtension(ext);
    setInCall(true);
    setCallStatus('calling');
    setCallDuration(0);
    setTranscript([`[SIP INVITE] Initiating SIP call to ${ext.sipUri}...`]);
    setIsOnHold(false);
    setIsMuted(false);

    // Play ringing tone
    ringerRef.current = new PhoneRinger();
    ringerRef.current.start();

    // Setup WebSocket connection to server Live Voice endpoint
    setupLiveWebSocket(ext);
  };

  const setupLiveWebSocket = (ext: IpExtension) => {
    try {
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/live-call`;
      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;

      ws.onopen = () => {
        // Send SIP Dial action with initial greeting prompt
        ws.send(
          JSON.stringify({
            action: 'dial',
            number: ext.extension,
            name: ext.name,
            customInstruction: ext.personaPrompt,
            voiceName: ext.voiceName || selectedVoice,
            isIpPhone: true,
            sipUri: ext.sipUri,
            greetingPrompt: ext.voicePrompt,
          })
        );
      };

      ws.onmessage = (event) => {
        try {
          const msg = JSON.parse(event.data);

          // 1. Connected
          if (msg.type === 'connected') {
            ringerRef.current?.stop();
            playSipConnectedChime();
            setCallStatus('connected');

            const greeting =
              msg.greetingText ||
              ext.voicePrompt ||
              'আসসালামু আলাইকুম! দেশ AI আইপি ফোন সিস্টেমে স্বাগতম। বলুন কীভাবে সহায়তা করতে পারি?';

            setTranscript((prev) => [
              ...prev,
              `✓ [200 OK] সংযোগ সম্পন্ন হয়েছে। কোডেক: ${ext.codec} (24kHz HD Voice)`,
              `📞 অপারেটর: ${ext.name} নিজে থেকে উত্তর দিচ্ছেন...`,
              `${ext.name}: ${greeting}`,
            ]);
            setAiSpeaking(true);
            startCallTimer();
            setupMicAudioCapture(ws);

            // Proactive Answer: If Gemini Live stream doesn't arrive within 1300ms, immediately trigger synthesized voice
            hasReceivedLiveAudioRef.current = false;
            setTimeout(() => {
              if (!hasReceivedLiveAudioRef.current && inCallRef.current) {
                playIpGreetingTTS(greeting, ext.voiceName);
              }
            }, 1300);
          }

          // 2. Audio Stream from Gemini 3.8 Live (24kHz PCM)
          else if (msg.type === 'audio' && msg.audio) {
            hasReceivedLiveAudioRef.current = true;
            setAiSpeaking(true);
            playLivePCMChunk(msg.audio);
          }

          // 3. Audio from TTS (fallback or greeting)
          else if (msg.type === 'tts_audio' && msg.audio) {
            hasReceivedLiveAudioRef.current = true;
            setAiSpeaking(true);
            playBase64AudioChunk(msg.audio);
          }

          // 4. Transcription
          else if (msg.type === 'transcript' && msg.text) {
            setTranscript((prev) => {
              const last = prev[prev.length - 1];
              if (last && last.startsWith(`${ext.name}:`)) {
                const copy = [...prev];
                copy[copy.length - 1] = `${ext.name}: ${msg.text}`;
                return copy;
              }
              return [...prev, `${ext.name}: ${msg.text}`];
            });
          }

          // 5. Interrupted
          else if (msg.type === 'interrupted') {
            stopActiveAudioSources();
          }

          // 6. Remote Hangup
          else if (msg.type === 'call_ended') {
            terminateCall();
          }

          // 7. Fallback ready
          else if (msg.type === 'fallback_ready') {
            ringerRef.current?.stop();
            playSipConnectedChime();
            setCallStatus('connected');
            const greeting =
              msg.greetingText ||
              ext.voicePrompt ||
              '✓ [SIP CONNECTED] আইপি কল সেন্টারে যুক্ত আছেন। অপারেটর কথা বলছেন...';
            setTranscript((prev) => [
              ...prev,
              '✓ [SIP CONNECTED] আইপি কল সেন্টারে যুক্ত আছেন। অপারেটর উত্তর দিচ্ছেন...',
              `${ext.name}: ${greeting}`,
            ]);
            setAiSpeaking(true);
            startCallTimer();
            setupMicAudioCapture(ws);
            playIpGreetingTTS(greeting, ext.voiceName);
          }
        } catch (err) {
          console.error('IP Phone WS message handling error:', err);
        }
      };

      ws.onerror = (err) => {
        console.warn('IP Phone WebSocket error, running in simulated standby:', err);
        ringerRef.current?.stop();
        playSipConnectedChime();
        setCallStatus('connected');
        startCallTimer();
        setTranscript((prev) => [
          ...prev,
          '✓ [SIP BACKUP] আইপি কল সংযুক্ত রয়েছে। মাইক্রোফোন চালু আছে।',
        ]);
      };

      ws.onclose = () => {
        // Closed
      };
    } catch (e) {
      console.error('Failed to open IP Phone WebSocket:', e);
      ringerRef.current?.stop();
      playSipConnectedChime();
      setCallStatus('connected');
      startCallTimer();
    }
  };

  // Capture user microphone at 16kHz PCM
  const setupMicAudioCapture = async (ws: WebSocket) => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaStreamRef.current = stream;

      const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
      const inputCtx = new AudioCtxClass({ sampleRate: 16000 });
      inputAudioCtxRef.current = inputCtx;

      const source = inputCtx.createMediaStreamSource(stream);
      const processor = inputCtx.createScriptProcessor(4096, 1, 1);
      processorRef.current = processor;

      processor.onaudioprocess = (e) => {
        if (isMutedRef.current || isOnHoldRef.current || ws.readyState !== WebSocket.OPEN) return;
        const inputData = e.inputBuffer.getChannelData(0);

        // Calculate visualizer wave
        let sum = 0;
        for (let i = 0; i < inputData.length; i++) {
          sum += Math.abs(inputData[i]);
        }
        const avg = sum / inputData.length;
        setMicActivity(Math.min(100, Math.round(avg * 450)));

        // Convert Float32 to 16-bit PCM little-endian
        const pcmBuffer = floatTo16BitPCM(inputData);
        const base64Audio = arrayBufferToBase64(pcmBuffer);

        ws.send(
          JSON.stringify({
            action: 'audio',
            audio: base64Audio,
          })
        );
      };

      source.connect(processor);
      processor.connect(inputCtx.destination);
    } catch (err) {
      console.error('Microphone capture failed:', err);
      setTranscript((prev) => [
        ...prev,
        '⚠️ মাইক্রোফোন অ্যাক্সেস পাওয়া যায়নি। অনুগ্রহ করে ব্রাউজারে মাইক্রোফোনের অনুমতি দিন।',
      ]);
    }
  };

  const startCallTimer = () => {
    if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    timerIntervalRef.current = setInterval(() => {
      setCallDuration((prev) => prev + 1);
    }, 1000);
  };

  // Hold Toggle
  const toggleHold = () => {
    if (!inCall || callStatus !== 'connected') return;
    if (!isOnHold) {
      setIsOnHold(true);
      holdMusicRef.current = new IpHoldMusic();
      holdMusicRef.current.start();
      setTranscript((prev) => [...prev, '⏸️ [HOLD] কল হোল্ডে রাখা হয়েছে (হোল্ড টিউন বাজছে)...']);
    } else {
      setIsOnHold(false);
      holdMusicRef.current?.stop();
      holdMusicRef.current = null;
      setTranscript((prev) => [...prev, '▶️ [RESUME] কল পুনরায় সক্রিয় করা হয়েছে।']);
    }
  };

  // Mute Toggle
  const toggleMute = () => {
    setIsMuted((prev) => !prev);
  };

  // Speaker Toggle
  const toggleSpeaker = () => {
    setSpeakerOn((prev) => !prev);
  };

  // Send DTMF In-Call
  const handleKeypadPress = (digit: string) => {
    playDtmfTone(digit);
    if (inCall && wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(
        JSON.stringify({
          action: 'dtmf',
          digit,
        })
      );
      setTranscript((prev) => [...prev, `[DTMF KEY: '${digit}']`]);
    } else {
      setDialTarget((prev) => (prev.length < 15 ? prev + digit : prev));
    }
  };

  // Terminate Call
  const terminateCall = () => {
    ringerRef.current?.stop();
    ringerRef.current = null;

    holdMusicRef.current?.stop();
    holdMusicRef.current = null;

    if (timerIntervalRef.current) {
      clearInterval(timerIntervalRef.current);
      timerIntervalRef.current = null;
    }

    if (wsRef.current) {
      if (wsRef.current.readyState === WebSocket.OPEN) {
        wsRef.current.send(JSON.stringify({ action: 'hangup' }));
      }
      wsRef.current.close();
      wsRef.current = null;
    }

    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((t) => t.stop());
      mediaStreamRef.current = null;
    }

    if (processorRef.current) {
      try {
        processorRef.current.disconnect();
      } catch (e) {}
      processorRef.current = null;
    }

    if (inputAudioCtxRef.current) {
      try {
        inputAudioCtxRef.current.close();
      } catch (e) {}
      inputAudioCtxRef.current = null;
    }

    stopActiveAudioSources();

    if (inCall && activeExtension) {
      const newRec: IpCallRecord = {
        id: `ip-rec-${Date.now()}`,
        extension: activeExtension.extension,
        sipUri: activeExtension.sipUri,
        callerName: activeExtension.name,
        timestamp: Date.now(),
        durationSeconds: callDuration,
        status: callDuration > 0 ? 'completed' : 'missed',
        direction: 'outgoing',
        codec: activeExtension.codec,
        jitterMs: jitterMs,
      };
      setCallRecords((prev) => [newRec, ...prev]);
    }

    setInCall(false);
    setCallStatus('idle');
    setCallDuration(0);
    setIsOnHold(false);
    setIsMuted(false);
    setShowKeypadOverlay(false);
  };

  const filteredExtensions = IP_EXTENSIONS.filter(
    (e) =>
      e.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      e.extension.includes(searchQuery) ||
      e.department.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Top Banner / System Title */}
      <div className="bg-gradient-to-r from-slate-900 via-emerald-950 to-slate-900 text-white rounded-3xl p-5 sm:p-7 shadow-xl border border-emerald-500/20 relative overflow-hidden">
        {/* Glow Effects */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute -bottom-10 -left-10 w-72 h-72 bg-teal-500/10 rounded-full blur-2xl pointer-events-none"></div>

        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 border border-emerald-400/30 text-emerald-300 text-xs font-bold tracking-wide">
                <Radio size={13} className="text-emerald-400 animate-pulse" />
                <span>NextGen IP Phone System</span>
              </span>
              <span className="text-xs text-slate-400 font-mono">SIP v2.0 • WebRTC • Gemini 3.8 Live</span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white flex items-center gap-2.5">
              <span>আইপি ফোন কল সিস্টেম</span>
              <span className="text-xs px-2 py-0.5 rounded-md bg-emerald-600/40 text-emerald-200 border border-emerald-500/30 font-mono font-medium">
                VoIP IP-PBX
              </span>
            </h1>

            <p className="text-sm text-slate-300 max-w-2xl leading-relaxed">
              Gemini 3.8 Live API চালিত রিয়েল-টাইম ভয়েস কনভারসেশন ও এন্টারপ্রাইজ আইপি এক্সটেনশন নেটওয়ার্ক। হাই-ডেফিনিশন লো-লেটেন্সি বাংলা ও দ্বিভাষিক ডিজিটাল কল সেবা।
            </p>
          </div>

          {/* PBX Live Status Pills */}
          <div className="flex flex-wrap items-center gap-2.5 bg-black/40 backdrop-blur-md p-3 rounded-2xl border border-white/10 text-xs font-mono">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping"></span>
              <span className="text-emerald-300 font-bold">SIP ONLINE</span>
            </div>
            <span className="text-slate-600">|</span>
            <div className="text-slate-300 flex items-center gap-1">
              <Server size={13} className="text-teal-400" />
              <span>sip.desh.ai:5060</span>
            </div>
            <span className="text-slate-600">|</span>
            <div className="text-slate-300 flex items-center gap-1">
              <Wifi size={13} className="text-emerald-400" />
              <span>{latencyMs}ms Ping</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Grid: IP Phone Console & Speed Dial Directory */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* LEFT / CENTER: Hardware-Grade IP Deskphone Console (7 Cols) */}
        <div className="lg:col-span-7 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xl overflow-hidden flex flex-col">
          {/* IP Phone Top Bezel / Header */}
          <div className="bg-slate-100 dark:bg-slate-950 px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-3.5 h-3.5 rounded-full bg-emerald-500 shadow-sm shadow-emerald-500/50"></div>
              <div>
                <span className="font-mono font-bold text-xs uppercase tracking-wider text-slate-700 dark:text-slate-300">
                  Desh-IPX 9000 Series VoIP Console
                </span>
                <p className="text-[10px] text-slate-400 font-mono">Ext: 9001 (WebRTC Client) • Active Line: {activeLine.toUpperCase()}</p>
              </div>
            </div>

            {/* Line Selection Buttons */}
            <div className="flex items-center gap-1.5 bg-slate-200/70 dark:bg-slate-800/80 p-1 rounded-xl">
              <button
                onClick={() => setActiveLine('line1')}
                className={`px-2.5 py-1 rounded-lg text-xs font-mono font-bold transition-all flex items-center gap-1 ${
                  activeLine === 'line1'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                }`}
              >
                <span className="w-1.5 h-1.5 rounded-full bg-white"></span>
                Line 1
              </button>
              <button
                onClick={() => setActiveLine('line2')}
                className={`px-2.5 py-1 rounded-lg text-xs font-mono font-bold transition-all flex items-center gap-1 ${
                  activeLine === 'line2'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                }`}
              >
                <span className="w-1.5 h-1.5 rounded-full bg-slate-400"></span>
                Line 2
              </button>
            </div>
          </div>

          {/* LCD Backlit Display Screen */}
          <div className="p-6 bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 text-white relative overflow-hidden">
            {/* Screen Header / Status Row */}
            <div className="flex items-center justify-between text-xs font-mono text-emerald-400 border-b border-emerald-900/50 pb-2 mb-4">
              <div className="flex items-center gap-2">
                <span className={`w-2 h-2 rounded-full ${inCall ? 'bg-rose-500 animate-ping' : 'bg-emerald-400'}`}></span>
                <span className="font-bold">
                  {inCall
                    ? isOnHold
                      ? 'CALL ON HOLD (হোল্ড)'
                      : `CONNECTED (লাইভ কল) [${activeLine.toUpperCase()}]`
                    : 'SIP STANDBY - READY TO DIAL'}
                </span>
              </div>
              <div className="flex items-center gap-3 text-[11px] text-slate-400">
                <span>{inCall ? formatTime(callDuration) : '00:00'}</span>
                <span>•</span>
                <span>{inCall ? `${latencyMs}ms / Jitter ${jitterMs}ms` : 'Ready'}</span>
              </div>
            </div>

            {/* In-Call Active State or Idle Dialing Screen */}
            {inCall && activeExtension ? (
              <div className="space-y-4">
                {/* Caller Information & Visual Wave */}
                <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-slate-900/80 p-4 rounded-2xl border border-emerald-500/20 backdrop-blur-xs">
                  <div className="flex items-center gap-3.5">
                    <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center font-mono font-black text-xl text-white shadow-md shadow-emerald-500/20">
                      {activeExtension.extension}
                    </div>
                    <div>
                      <h3 className="text-lg font-bold text-white flex items-center gap-2">
                        <span>{activeExtension.name}</span>
                        {isOnHold && (
                          <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 font-mono">
                            ON HOLD
                          </span>
                        )}
                      </h3>
                      <p className="text-xs text-slate-400 font-mono">{activeExtension.sipUri}</p>
                    </div>
                  </div>

                  {/* Audio Visualizer Waves */}
                  <div className="flex items-end gap-1 h-8 px-3 py-1 bg-black/50 rounded-xl border border-emerald-500/20">
                    {[18, 35, 65, 85, 45, 95, 55, 30, 70, 40].map((h, i) => {
                      const dynamicH = aiSpeaking
                        ? Math.max(15, (h * (micActivity + 40)) % 100)
                        : micActivity > 10
                        ? Math.max(10, (micActivity * (i + 1)) % 100)
                        : 8;
                      return (
                        <span
                          key={i}
                          style={{ height: `${dynamicH}%` }}
                          className={`w-1 rounded-full transition-all duration-75 ${
                            aiSpeaking
                              ? 'bg-emerald-400'
                              : micActivity > 15
                              ? 'bg-teal-400'
                              : 'bg-slate-700'
                          }`}
                        ></span>
                      );
                    })}
                  </div>
                </div>

                {/* Live Real-time Conversation Display on LCD */}
                <div className="bg-black/60 rounded-2xl p-3.5 border border-emerald-950 font-mono text-xs text-emerald-300 max-h-40 min-h-[100px] overflow-y-auto space-y-1.5 scrollbar-thin">
                  {transcript.map((line, idx) => (
                    <div
                      key={idx}
                      className={`leading-relaxed ${
                        line.startsWith('✓')
                          ? 'text-emerald-400 font-bold'
                          : line.startsWith('[SIP') || line.startsWith('[DTMF')
                          ? 'text-teal-300'
                          : line.startsWith('⏸️')
                          ? 'text-amber-300'
                          : 'text-slate-200'
                      }`}
                    >
                      {line}
                    </div>
                  ))}
                  <div ref={transcriptEndRef} />
                </div>
              </div>
            ) : (
              /* Idle / Ready Screen */
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <span className="text-[11px] font-mono uppercase tracking-wider text-slate-400">
                      SIP Target / Extension Number:
                    </span>
                    <div className="text-2xl sm:text-3xl font-mono font-bold tracking-wider text-emerald-400 flex items-center gap-2 mt-0.5">
                      <span>{dialTarget || '___'}</span>
                      {dialTarget && (
                        <button
                          onClick={() => setDialTarget('')}
                          className="text-xs px-2 py-0.5 rounded-md bg-slate-800 text-slate-400 hover:text-white font-sans"
                        >
                          মুছুন
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Active Match Badge */}
                  {(() => {
                    const match = IP_EXTENSIONS.find((e) => e.extension === dialTarget.trim());
                    if (match) {
                      return (
                        <div className="text-right">
                          <span className="text-xs px-2.5 py-1 rounded-full bg-emerald-500/20 border border-emerald-400/30 text-emerald-300 font-bold">
                            {match.name}
                          </span>
                          <p className="text-[10px] text-slate-400 font-mono mt-1">{match.department}</p>
                        </div>
                      );
                    }
                    return null;
                  })()}
                </div>

                <div className="bg-black/40 rounded-xl p-3 border border-slate-800 text-xs text-slate-400 font-mono flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Globe size={13} className="text-emerald-400" />
                    <span>SIP Domain: @desh.ip:5060</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-emerald-300">
                    <ShieldCheck size={13} />
                    <span>TLS / SRTP Encrypted</span>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* In-Call Controls or Keypad Grid */}
          <div className="p-6 bg-slate-50 dark:bg-slate-900/90 border-t border-slate-200 dark:border-slate-800">
            {inCall ? (
              /* ACTIVE IN-CALL ACTION DOCK */
              <div className="space-y-5">
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {/* Mute Button */}
                  <button
                    onClick={toggleMute}
                    className={`p-3.5 rounded-2xl border flex flex-col items-center justify-center gap-1.5 transition-all shadow-xs ${
                      isMuted
                        ? 'bg-rose-50 dark:bg-rose-950/60 border-rose-300 dark:border-rose-800 text-rose-600 dark:text-rose-400 font-bold'
                        : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100'
                    }`}
                  >
                    {isMuted ? <MicOff size={22} /> : <Mic size={22} />}
                    <span className="text-xs font-semibold">{isMuted ? 'আনমিউট' : 'মিউট'}</span>
                  </button>

                  {/* Speaker Button */}
                  <button
                    onClick={toggleSpeaker}
                    className={`p-3.5 rounded-2xl border flex flex-col items-center justify-center gap-1.5 transition-all shadow-xs ${
                      speakerOn
                        ? 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-300 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300 font-bold'
                        : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100'
                    }`}
                  >
                    {speakerOn ? <Volume2 size={22} /> : <VolumeX size={22} />}
                    <span className="text-xs font-semibold">{speakerOn ? 'স্পিকার অন' : 'স্পিকার অফ'}</span>
                  </button>

                  {/* Hold Button */}
                  <button
                    onClick={toggleHold}
                    className={`p-3.5 rounded-2xl border flex flex-col items-center justify-center gap-1.5 transition-all shadow-xs ${
                      isOnHold
                        ? 'bg-amber-50 dark:bg-amber-950/60 border-amber-300 dark:border-amber-800 text-amber-700 dark:text-amber-300 font-bold'
                        : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100'
                    }`}
                  >
                    {isOnHold ? <Play size={22} /> : <Pause size={22} />}
                    <span className="text-xs font-semibold">{isOnHold ? 'রিজিউম' : 'হোল্ড'}</span>
                  </button>

                  {/* In-Call Keypad Toggle */}
                  <button
                    onClick={() => setShowKeypadOverlay(!showKeypadOverlay)}
                    className={`p-3.5 rounded-2xl border flex flex-col items-center justify-center gap-1.5 transition-all shadow-xs ${
                      showKeypadOverlay
                        ? 'bg-teal-50 dark:bg-teal-950/60 border-teal-300 dark:border-teal-800 text-teal-700 dark:text-teal-300 font-bold'
                        : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100'
                    }`}
                  >
                    <Hash size={22} />
                    <span className="text-xs font-semibold">কীপ্যাড DTMF</span>
                  </button>
                </div>

                {/* In-Call DTMF Keypad Overlay */}
                {showKeypadOverlay && (
                  <div className="bg-slate-100 dark:bg-slate-950 p-4 rounded-2xl border border-slate-200 dark:border-slate-800">
                    <p className="text-xs font-mono text-center text-slate-500 mb-3">টোন পাঠাতে বোতাম চাপুন (DTMF Signals)</p>
                    <div className="grid grid-cols-3 gap-2.5 max-w-xs mx-auto">
                      {KEYPAD_DIGITS.map((item) => (
                        <button
                          key={item.key}
                          onClick={() => handleKeypadPress(item.key)}
                          className="h-12 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex flex-col items-center justify-center hover:bg-emerald-50 dark:hover:bg-emerald-950 active:scale-95 transition-all"
                        >
                          <span className="text-base font-black text-slate-800 dark:text-slate-100">{item.key}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* End Call Button */}
                <button
                  onClick={terminateCall}
                  className="w-full py-4 rounded-2xl bg-gradient-to-r from-rose-600 to-rose-700 hover:from-rose-700 hover:to-rose-800 text-white font-bold text-base flex items-center justify-center gap-2.5 shadow-lg shadow-rose-600/30 transition-all active:scale-[0.99]"
                >
                  <PhoneOff size={20} />
                  <span>কল সমাপ্ত করুন (End Call)</span>
                </button>
              </div>
            ) : (
              /* IDLE DIAL PAD & INITIATE CALL */
              <div className="space-y-5">
                {/* 3x4 Hardware Style Keypad */}
                <div className="grid grid-cols-3 gap-3 max-w-sm mx-auto">
                  {KEYPAD_DIGITS.map((item) => (
                    <button
                      key={item.key}
                      onClick={() => handleKeypadPress(item.key)}
                      className="h-14 rounded-2xl bg-white dark:bg-slate-800/80 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 border border-slate-200 dark:border-slate-700 active:scale-95 transition-all flex flex-col items-center justify-center group shadow-xs"
                    >
                      <span className="text-xl font-black text-slate-800 dark:text-slate-100 group-hover:text-emerald-600 dark:group-hover:text-emerald-400">
                        {item.key}
                      </span>
                      <span className="text-[9px] font-mono uppercase text-slate-400 group-hover:text-emerald-600/70">
                        {item.sub}
                      </span>
                    </button>
                  ))}
                </div>

                {/* Dial / Connect Action Button */}
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => startIpCall(dialTarget)}
                    disabled={!dialTarget.trim()}
                    className="flex-1 py-4 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 disabled:opacity-50 text-white font-bold text-base flex items-center justify-center gap-2.5 shadow-lg shadow-emerald-600/30 transition-all active:scale-[0.99]"
                  >
                    <PhoneCall size={20} className="animate-bounce" />
                    <span>আইপি কল করুন (Connect Call)</span>
                  </button>

                  <button
                    onClick={() => setShowSettingsModal(true)}
                    title="আইপি ফোন সেটিংস"
                    className="p-4 rounded-2xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 transition-colors"
                  >
                    <Settings2 size={20} />
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* RIGHT: Enterprise Speed Dial Directory & Call Records (5 Cols) */}
        <div className="lg:col-span-5 space-y-6">
          {/* Extensions Speed Dial Directory */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xl p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Layers size={17} className="text-emerald-500" />
                  <span>আইপি ডিরেক্টরি (Speed Dial)</span>
                </h3>
                <p className="text-xs text-slate-500">এক ক্লিকেই এক্সটেনশনে ডায়াল করুন</p>
              </div>

              <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 font-mono font-bold">
                {IP_EXTENSIONS.length} Extensions
              </span>
            </div>

            {/* Quick Filter Search */}
            <div className="relative">
              <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="এক্সটেনশন বা বিভাগ খুঁজুন..."
                className="w-full pl-9 pr-4 py-2 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            {/* Extension Cards List */}
            <div className="space-y-2.5 max-h-[380px] overflow-y-auto pr-1 scrollbar-thin">
              {filteredExtensions.map((ext) => (
                <div
                  key={ext.extension}
                  className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/40 hover:bg-emerald-50/50 dark:hover:bg-slate-800 border border-slate-200/80 dark:border-slate-700/60 transition-all flex items-center justify-between group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300 flex items-center justify-center font-mono font-bold text-sm">
                      {ext.extension}
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-slate-900 dark:text-white group-hover:text-emerald-600 transition-colors">
                        {ext.name}
                      </h4>
                      <p className="text-[11px] text-slate-500 line-clamp-1">{ext.description}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => {
                        setDialTarget(ext.extension);
                        playDtmfTone('1');
                      }}
                      title="নম্বর সিলেক্ট করুন"
                      className="px-2.5 py-1.5 rounded-lg text-xs font-mono font-bold bg-slate-200/60 dark:bg-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-300 transition-colors"
                    >
                      {ext.extension}
                    </button>
                    <button
                      onClick={() => startIpCall(ext.extension)}
                      title="সরাসরি আইপি কল দিন"
                      className="p-2 rounded-lg bg-emerald-600 text-white hover:bg-emerald-700 transition-colors shadow-xs"
                    >
                      <Phone size={14} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Recent IP Call Logs */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xl p-5 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <History size={16} className="text-teal-500" />
                <span>আইপি কল হিস্ট্রি (Call Logs)</span>
              </h3>
              {callRecords.length > 0 && (
                <button
                  onClick={() => setCallRecords([])}
                  className="text-[11px] text-slate-400 hover:text-rose-500 flex items-center gap-1"
                >
                  <Trash2 size={12} />
                  <span>মুছুন</span>
                </button>
              )}
            </div>

            {callRecords.length === 0 ? (
              <p className="text-xs text-slate-400 text-center py-4">এখনও কোনো আইপি কল করা হয়নি</p>
            ) : (
              <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                {callRecords.map((rec) => (
                  <div
                    key={rec.id}
                    className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-800 text-xs flex items-center justify-between"
                  >
                    <div>
                      <div className="font-semibold text-slate-800 dark:text-slate-200">{rec.callerName}</div>
                      <div className="text-[10px] text-slate-400 font-mono">
                        Ext: {rec.extension} • {formatTime(rec.durationSeconds)} • {new Date(rec.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </div>
                    </div>
                    <button
                      onClick={() => startIpCall(rec.extension)}
                      className="p-1.5 rounded-lg bg-emerald-50 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-100"
                    >
                      <RotateCcw size={13} />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Settings / Configuration Modal */}
      {showSettingsModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 max-w-md w-full p-6 space-y-5 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="font-bold text-base text-slate-900 dark:text-white flex items-center gap-2">
                <Settings2 size={18} className="text-emerald-500" />
                <span>আইপি ফোন ও ভয়েস সেটিংস</span>
              </h3>
              <button
                onClick={() => setShowSettingsModal(false)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-white text-sm"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4">
              {/* Voice Persona Selection */}
              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1.5">
                  Gemini Live এআই ভয়েস পারসোনা (Voice Profile)
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['Zephyr', 'Kore', 'Puck'] as const).map((v) => (
                    <button
                      key={v}
                      onClick={() => setSelectedVoice(v)}
                      className={`py-2 px-3 rounded-xl text-xs font-semibold border text-center transition-all ${
                        selectedVoice === v
                          ? 'bg-emerald-50 dark:bg-emerald-950 border-emerald-500 text-emerald-700 dark:text-emerald-300 font-bold'
                          : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                      }`}
                    >
                      {v}
                    </button>
                  ))}
                </div>
              </div>

              {/* PBX Server Info */}
              <div className="bg-slate-50 dark:bg-slate-800/60 p-3 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-mono space-y-1">
                <div className="text-slate-500">SIP Proxy / Registrar:</div>
                <div className="font-bold text-slate-800 dark:text-slate-200">sip.desh.ai:5060 (UDP/TCP/WSS)</div>
                <div className="text-slate-500 mt-2">Active Audio Codec:</div>
                <div className="font-bold text-emerald-600 dark:text-emerald-400">L16 / PCM 24kHz Ultra-HD Voice</div>
              </div>
            </div>

            <button
              onClick={() => setShowSettingsModal(false)}
              className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs"
            >
              সংরক্ষণ করুন (Done)
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
