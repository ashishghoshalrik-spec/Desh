import React, { useState } from 'react';
import { 
  PenTool, 
  Sparkles, 
  Copy, 
  Check, 
  Download, 
  FileText, 
  RefreshCw, 
  Edit3, 
  Send,
  Sliders,
  Bookmark
} from 'lucide-react';
import { MarkdownView } from './MarkdownView';

interface DocumentPreset {
  id: string;
  name: string;
  type: string;
  tone: string;
  defaultTopic: string;
  recipient: string;
  iconName: string;
}

const PRESETS: DocumentPreset[] = [
  {
    id: 'leave',
    name: 'অফিস ছুটির দরখাস্ত',
    type: 'অফিস ছুটির আবেদনপত্র',
    tone: 'আনুষ্ঠানিক ও বিনয়ী',
    defaultTopic: 'ব্যক্তিগত অসুস্থতার কারণে আগামী ৩ দিনের ছুটির আবেদন',
    recipient: 'ব্যবস্থাপনা পরিচালক / বিভাগীয় প্রধান',
    iconName: 'FileText',
  },
  {
    id: 'job-app',
    name: 'চাকরির আবেদন ও কভার লেটার',
    type: 'চাকরির পূর্ণাঙ্গ আবেদনপত্র ও কভার লেটার',
    tone: 'পেশাদার ও আত্মবিশ্বাসী',
    defaultTopic: 'একটি স্বনামধন্য প্রতিষ্ঠানে সিনিয়র এক্সিকিউটিভ পদে নিয়োগের জন্য আবেদন',
    recipient: 'মানবসম্পদ বিভাগ (HR Department)',
    iconName: 'FileText',
  },
  {
    id: 'poem',
    name: 'বাংলা কবিতা রচনা',
    type: 'ছন্দময় আধুনিক বাংলা কবিতা',
    tone: 'কাব্যিক, আবেগঘন ও গভীর',
    defaultTopic: 'বাংলাদেশের নদী, বর্ষা এবং ফেলে আসা গ্রামের স্মৃতির প্রতি ভালোবাসা',
    recipient: 'সাধারণ পাঠক',
    iconName: 'PenTool',
  },
  {
    id: 'dc-letter',
    name: 'ডিসি / ইউএনও বরাবর আবেদন',
    type: 'প্রশাসনিক আবেদনপত্র ও স্মারকলিপি',
    tone: 'আনুষ্ঠানিক সরকারি চিঠি',
    defaultTopic: 'এলাকায় ভাঙা রাস্তা ও ড্রেনেজ ব্যবস্থা মেরামতের জন্য এলাকাবাসীর পক্ষে আবেদন',
    recipient: 'উপজেলা নির্বাহী অফিসার (ইউএনও)',
    iconName: 'FileText',
  },
  {
    id: 'facebook',
    name: 'ফেসবুক পোস্ট ও ক্যাপশন',
    type: 'আকর্ষণীয় সোশ্যাল মিডিয়া কনটেন্ট',
    tone: 'অনুপ্রেরণামূলক ও আকর্ষণীয়',
    defaultTopic: 'কঠোর পরিশ্রম, স্বপ্ন দেখা এবং তরুণদের এগিয়ে যাওয়া নিয়ে চমৎকার একটি পোস্ট',
    recipient: 'সোশ্যাল মিডিয়া অনুসারী',
    iconName: 'Sparkles',
  },
  {
    id: 'business-email',
    name: 'ব্যবসায়িক ইমেইল ও প্রস্তাবনা',
    type: 'ব্যবসায়িক পার্টনারশিপ ইমেইল',
    tone: 'কর্পোরেট ও স্পষ্ট',
    defaultTopic: 'আমাদের নতুন সফটওয়্যার সমাধান তাদের প্রতিষ্ঠানে ব্যবহারের জন্য যৌথ প্রস্তাবনা',
    recipient: 'ক্লায়েন্ট বা অংশীদার কোম্পানি',
    iconName: 'FileText',
  },
];

export const WriterTab: React.FC = () => {
  const [docType, setDocType] = useState('অফিস ছুটির আবেদনপত্র');
  const [topic, setTopic] = useState('ব্যক্তিগত অসুস্থতার কারণে আগামী ৩ দিনের ছুটির আবেদন');
  const [recipient, setRecipient] = useState('বিভাগীয় প্রধান / প্রতিষ্ঠান প্রধান');
  const [tone, setTone] = useState('আনুষ্ঠানিক ও বিনয়ী');
  const [length, setLength] = useState('মাঝারি');
  const [additionalNotes, setAdditionalNotes] = useState('');

  const [loading, setLoading] = useState(false);
  const [output, setOutput] = useState<string>('');
  const [copied, setCopied] = useState(false);
  const [isEditing, setIsEditing] = useState(false);

  const applyPreset = (preset: DocumentPreset) => {
    setDocType(preset.type);
    setTopic(preset.defaultTopic);
    setRecipient(preset.recipient);
    setTone(preset.tone);
  };

  const handleGenerate = async () => {
    if (!topic.trim() || loading) return;

    setLoading(true);
    setIsEditing(false);

    try {
      const fullTopic = `${topic}. ${recipient ? `প্রাপক/উদ্দেশ্য: ${recipient}.` : ''}`;
      const res = await fetch('/api/write', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: docType,
          topic: fullTopic,
          tone,
          length,
          details: additionalNotes,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'লেখা তৈরি করা সম্ভব হয়নি');

      setOutput(data.result);
    } catch (err: any) {
      alert(err.message || 'লেখা তৈরি করতে সমস্যা হয়েছে');
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = () => {
    if (!output) return;
    navigator.clipboard.writeText(output);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    if (!output) return;
    const blob = new Blob([output], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `desh-ai-document-${Date.now()}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="max-w-6xl mx-auto px-3 sm:px-6 py-6 space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-emerald-900 via-emerald-800 to-teal-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl relative overflow-hidden">
        <div className="relative z-10 max-w-2xl">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-700/60 text-emerald-200 border border-emerald-500/30 mb-3">
            <PenTool size={13} />
            বাংলা লেখা ও আবেদনপত্র স্টুডিও
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            প্রয়োজনীয় যেকোনো চিঠি, দরখাস্ত কিংবা সাহিত্য প্রস্তুত করুন নিমিষেই
          </h1>
          <p className="mt-2 text-emerald-100 text-sm sm:text-base leading-relaxed">
            সরকারি বা বেসরকারি অফিসের ছুটির আবেদনপত্র, চাকরির কভার লেটার, স্মারকলিপি কিংবা মনের মতো বাংলা কবিতা — দেশ AI প্রস্তুত করে দেবে নিখুঁত প্রমিত বাংলায়।
          </p>
        </div>
        {/* Background graphic motif */}
        <div className="absolute right-0 bottom-0 translate-x-10 translate-y-10 w-64 h-64 rounded-full bg-emerald-500/10 blur-2xl pointer-events-none"></div>
      </div>

      {/* Preset Chips */}
      <div>
        <label className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-2 block">
          জনপ্রিয় ফরম্যাটসমূহ থেকে বেছে নিন:
        </label>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
          {PRESETS.map((p) => (
            <button
              key={p.id}
              onClick={() => applyPreset(p)}
              className="p-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-emerald-500/50 hover:bg-emerald-50/30 dark:hover:bg-emerald-950/20 text-left transition-all shadow-sm group"
            >
              <div className="text-emerald-600 dark:text-emerald-400 font-bold text-xs mb-1 group-hover:translate-x-0.5 transition-transform">
                {p.name}
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-2">
                {p.type}
              </p>
            </button>
          ))}
        </div>
      </div>

      {/* Workspace Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Form: Inputs (5 Cols) */}
        <div className="lg:col-span-5 bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
            <h2 className="font-bold text-slate-900 dark:text-white flex items-center gap-2 text-base">
              <Sliders size={18} className="text-emerald-600" />
              লেখার নির্দেশনাবলী
            </h2>
          </div>

          {/* Document Type */}
          <div>
            <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
              লেখার ধরন / ক্যাটাগরি
            </label>
            <input
              type="text"
              value={docType}
              onChange={(e) => setDocType(e.target.value)}
              placeholder="যেমন: ছুটির দরখাস্ত, কবিতা, চাকরির কভার লেটার..."
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/30 focus:border-emerald-500"
            />
          </div>

          {/* Topic */}
          <div>
            <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
              মূল বিষয়বস্তু ও বিবরণ *
            </label>
            <textarea
              rows={3}
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="কী লিখতে চান? বিশদে লিখলে ফলাফল আরো চমৎকার হবে..."
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/30 focus:border-emerald-500 resize-none"
            />
          </div>

          {/* Recipient */}
          <div>
            <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
              প্রাপক / প্রতিষ্ঠান (ঐচ্ছিক)
            </label>
            <input
              type="text"
              value={recipient}
              onChange={(e) => setRecipient(e.target.value)}
              placeholder="যেমন: কোম্পানি প্রধান, প্রধান শিক্ষক, সম্মানিত ডিসি মহোদয়..."
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/30 focus:border-emerald-500"
            />
          </div>

          {/* Tone & Length */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                টোন বা মেজাজ
              </label>
              <select
                value={tone}
                onChange={(e) => setTone(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
              >
                <option value="আনুষ্ঠানিক ও বিনয়ী">আনুষ্ঠানিক ও বিনয়ী</option>
                <option value="পেশাদার ও স্পষ্ট">পেশাদার কর্পোরেট</option>
                <option value="কাব্যিক ও সৃজনশীল">কাব্যিক ও সৃজনশীল</option>
                <option value="আবেগঘন ও অনুপ্রেরণামূলক">অনুপ্রেরণামূলক</option>
                <option value="সহজ ও প্রাত্যহিক">সহজ ও ঘরোয়া</option>
              </select>
            </div>
            <div>
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                দৈর্ঘ্য
              </label>
              <select
                value={length}
                onChange={(e) => setLength(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
              >
                <option value="সংক্ষিপ্ত">সংক্ষিপ্ত</option>
                <option value="মাঝারি">মাঝারি (প্রমিত)</option>
                <option value="বিস্তারিত">বিস্তারিত</option>
              </select>
            </div>
          </div>

          {/* Additional Notes */}
          <div>
            <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
              বিশেষ কোনো তথ্য বা শর্ত (ঐচ্ছিক)
            </label>
            <input
              type="text"
              value={additionalNotes}
              onChange={(e) => setAdditionalNotes(e.target.value)}
              placeholder="যেমন: তারিখ উল্লেখ করুন, বিনীত নিবেদক অংশে নাম..."
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
            />
          </div>

          {/* Generate Button */}
          <button
            onClick={handleGenerate}
            disabled={!topic.trim() || loading}
            className={`w-full py-3.5 rounded-xl font-bold text-sm sm:text-base flex items-center justify-center gap-2 transition-all shadow-md ${
              topic.trim() && !loading
                ? 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-emerald-700/20 active:scale-95'
                : 'bg-slate-200 dark:bg-slate-800 text-slate-400 cursor-not-allowed'
            }`}
          >
            {loading ? (
              <>
                <RefreshCw size={18} className="animate-spin" />
                <span>দেশ AI রচনা প্রস্তুত করছে...</span>
              </>
            ) : (
              <>
                <Sparkles size={18} />
                <span>লেখা প্রস্তুত করুন</span>
              </>
            )}
          </button>
        </div>

        {/* Right Output: Result View (7 Cols) */}
        <div className="lg:col-span-7 bg-white dark:bg-slate-900 rounded-3xl p-5 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col min-h-[500px]">
          {/* Output Toolbar */}
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
            <div className="flex items-center gap-2">
              <FileText size={18} className="text-emerald-600 dark:text-emerald-400" />
              <span className="font-bold text-sm sm:text-base text-slate-900 dark:text-white">
                প্রস্তুতকৃত ফলাফল
              </span>
            </div>

            {output && (
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => setIsEditing(!isEditing)}
                  className="px-2.5 py-1 rounded-lg text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-1 transition-colors"
                >
                  <Edit3 size={13} />
                  <span>{isEditing ? 'প্রিভিউ দেখুন' : 'সম্পাদনা করুন'}</span>
                </button>
                <button
                  onClick={handleCopy}
                  className="px-2.5 py-1 rounded-lg text-xs font-semibold bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-100 flex items-center gap-1 transition-colors"
                >
                  {copied ? <Check size={13} /> : <Copy size={13} />}
                  <span>{copied ? 'কপি হয়েছে' : 'কপি করুন'}</span>
                </button>
                <button
                  onClick={handleDownload}
                  className="p-1 rounded-lg text-slate-500 hover:text-slate-800 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                  title="ডাউনলোড করুন"
                >
                  <Download size={16} />
                </button>
              </div>
            )}
          </div>

          {/* Output Body */}
          <div className="flex-1 py-4">
            {output ? (
              isEditing ? (
                <textarea
                  value={output}
                  onChange={(e) => setOutput(e.target.value)}
                  className="w-full h-full min-h-[400px] p-3 rounded-xl bg-slate-50 dark:bg-slate-800 font-mono text-sm leading-relaxed border border-slate-200 dark:border-slate-700 focus:outline-none"
                />
              ) : (
                <div className="bg-slate-50/50 dark:bg-slate-950/40 p-4 sm:p-6 rounded-2xl border border-slate-100 dark:border-slate-800/80">
                  <MarkdownView content={output} />
                </div>
              )
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-center p-8 text-slate-400">
                <div className="w-14 h-14 rounded-2xl bg-emerald-50 dark:bg-emerald-950/50 flex items-center justify-center text-emerald-600 dark:text-emerald-400 mb-3">
                  <PenTool size={26} />
                </div>
                <h3 className="font-bold text-slate-700 dark:text-slate-300 text-base mb-1">
                  এখনো কোনো লেখা তৈরি করা হয়নি
                </h3>
                <p className="text-xs sm:text-sm text-slate-500 max-w-sm">
                  বামপাশের ফর্ম পূরণ করে &apos;লেখা প্রস্তুত করুন&apos; বাটনে চাপুন। দেশ AI মুহূর্তেই আপনার দরকারি নথি সাজিয়ে দেবে।
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
