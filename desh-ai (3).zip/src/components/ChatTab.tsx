import React, { useState, useRef, useEffect } from 'react';
import { 
  Send, 
  Mic, 
  MicOff, 
  Volume2, 
  VolumeX, 
  RotateCcw, 
  Trash2, 
  Download, 
  Copy, 
  Check, 
  Sparkles, 
  BookOpen, 
  Briefcase, 
  Code, 
  Sprout, 
  Feather,
  Info
} from 'lucide-react';
import { ChatMessage, Persona, PersonaId } from '../types';
import { MarkdownView } from './MarkdownView';

const PERSONAS: Persona[] = [
  {
    id: 'general',
    name: 'সাধারণ আলাপ',
    nameEn: 'General AI',
    badge: 'ডিফল্ট',
    icon: 'Sparkles',
    description: 'দৈনন্দিন সব প্রশ্নের সহজ, নির্ভরযোগ্য ও আন্তরিক বাংলা উত্তর।',
    placeholder: 'দেশ AI কে যেকোনো প্রশ্ন জিজ্ঞেস করুন...',
  },
  {
    id: 'bcs',
    name: 'বিসিএস ও প্রস্তুতি',
    nameEn: 'BCS & Exam Mentor',
    badge: 'পরীক্ষা',
    icon: 'Briefcase',
    description: 'বিসিএস, ব্যাংক, সরকারি চাকরি ও বিশ্ববিদ্যালয় ভর্তি সহায়িকা।',
    placeholder: 'বিসিএস বা পরীক্ষার যেকোনো প্রশ্ন, শর্টকাট টেকনিক বা পরামর্শ চান...',
  },
  {
    id: 'writer',
    name: 'সাহিত্য ও ড্রাফটিং',
    nameEn: 'Poetry & Writing',
    badge: 'সৃজনশীল',
    icon: 'Feather',
    description: 'কবিতা, গল্প, সামাজিক পোস্ট, চিঠি ও আনুষ্ঠানিক দরখাস্ত।',
    placeholder: 'কী লিখতে চান? যেমন: "বৈশাখী গল্প" বা "ছুটির দরখাস্ত"...',
  },
  {
    id: 'coder',
    name: 'কোডিং ও টেক',
    nameEn: 'Coding Assistant',
    badge: 'আইটি',
    icon: 'Code',
    description: 'পাইথন, জাভাস্ক্রিপ্ট, এলগরিদম ও সফটওয়্যার ইঞ্জিনিয়ারিং।',
    placeholder: 'যেকোনো কোড লিখে দিন বা সমস্যা বর্ণনা করুন...',
  },
  {
    id: 'agriculture',
    name: 'কৃষি ও প্রকৃতি',
    nameEn: 'Agri Advisor',
    badge: 'কৃষি',
    icon: 'Sprout',
    description: 'ফসল চাষ, সার-কীটনাশক, মাছ ও পশুপালন সম্পর্কিত পরামর্শ।',
    placeholder: 'ফসলের রোগবালাই, সার প্রয়োগ বা আধুনিক চাষাবাদ নিয়ে জানতে চান...',
  },
];

const SUGGESTED_PROMPTS = [
  { text: 'বাংলাদেশের সংবিধানের ৪টি মূলনীতি ও তাৎপর্য ব্যাখ্যা করো', tag: 'রাষ্ট্র' },
  { text: 'বিসিএস প্রিলিমিনারি সাধারণ জ্ঞান অংশে ভালো করার কার্যকরী রুটিন', tag: 'বিসিএস' },
  { text: 'অফিস ছুটির জন্য বসের কাছে একটি ভদ্র ও মার্জিত দরখাস্ত লিখে দাও', tag: 'দরখাস্ত' },
  { text: 'রবীন্দ্রনাথ ঠাকুরের ‘সোনার তরী’ কবিতার রূপক ও দার্শনিক অর্থ', tag: 'সাহিত্য' },
  { text: 'জাভাস্ক্রিপ্ট দিয়ে একটি সাধারণ ক্যালকুলেটর বানানোর কোড ও ব্যাখ্যা', tag: 'কোডিং' },
  { text: 'ছাদবাগানে টমেটো ও মরিচ চাষের সহজ যত্ন ও সার পদ্ধতি', tag: 'কৃষি' },
];

export const ChatTab: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    const saved = localStorage.getItem('desh_ai_chat');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // ignore
      }
    }
    return [
      {
        id: 'welcome',
        role: 'assistant',
        text: 'স্বাগতম! আমি **দেশ AI** (Desh AI)।\n\nআমি বাংলাদেশ ও বিশ্বের সকল বাংলাভাষীর জন্য বিশেষভাবে প্রশিক্ষিত কৃত্রিম বুদ্ধিমত্তা। আপনি আমাকে যেকোনো সাধারণ জিজ্ঞাসা, বিসিএস ও চাকরির পড়াশোনা, দরখাস্ত ও কবিতা রচনা, অনুবাদ, কিংবা কোডিং সমস্যার বিষয়ে প্রশ্ন করতে পারেন।\n\n*আজ আপনাকে কীভাবে সহায়তা করতে পারি?*',
        timestamp: Date.now(),
        persona: 'general',
      },
    ];
  });

  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [selectedPersona, setSelectedPersona] = useState<PersonaId>('general');
  const [isRecording, setIsRecording] = useState(false);
  const [playingAudioId, setPlayingAudioId] = useState<string | null>(null);
  const [audioLoadingId, setAudioLoadingId] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const audioPlayerRef = useRef<HTMLAudioElement | null>(null);
  const recognitionRef = useRef<any>(null);

  // Save to localStorage
  useEffect(() => {
    localStorage.setItem('desh_ai_chat', JSON.stringify(messages));
  }, [messages]);

  // Scroll to bottom on new message
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  // Initialize Speech Recognition
  useEffect(() => {
    const handleInsertPrompt = (e: any) => {
      if (e.detail?.prompt) {
        setInput(e.detail.prompt);
      }
    };
    window.addEventListener('desh:insert-prompt', handleInsertPrompt);
    return () => window.removeEventListener('desh:insert-prompt', handleInsertPrompt);
  }, []);

  useEffect(() => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = 'bn-BD'; // Default to Bangla (Bangladesh)

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setInput((prev) => (prev ? `${prev} ${transcript}` : transcript));
        setIsRecording(false);
      };

      recognition.onerror = () => {
        setIsRecording(false);
      };

      recognition.onend = () => {
        setIsRecording(false);
      };

      recognitionRef.current = recognition;
    }
  }, []);

  const toggleRecording = () => {
    if (!recognitionRef.current) {
      alert('আপনার ব্রাউজারে স্পিচ রিকগনিশন সমর্থন করে না। অনুগ্রহ করে ক্রোম ব্রাউজার ব্যবহার করুন।');
      return;
    }

    if (isRecording) {
      recognitionRef.current.stop();
      setIsRecording(false);
    } else {
      try {
        recognitionRef.current.start();
        setIsRecording(true);
      } catch (err) {
        console.error(err);
      }
    }
  };

  const handleSend = async (userText?: string) => {
    const textToSend = (userText || input).trim();
    if (!textToSend || loading) return;

    const userMessage: ChatMessage = {
      id: `usr_${Date.now()}`,
      role: 'user',
      text: textToSend,
      timestamp: Date.now(),
      persona: selectedPersona,
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setLoading(true);

    try {
      // Build history
      const historyTurns = messages
        .filter((m) => m.id !== 'welcome')
        .slice(-6)
        .map((m) => ({ role: m.role, text: m.text }));

      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: textToSend,
          history: historyTurns,
          persona: selectedPersona,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || 'রেসপন্স পেতে ব্যর্থ হয়েছে');
      }

      const botMessage: ChatMessage = {
        id: `asst_${Date.now()}`,
        role: 'assistant',
        text: data.reply || 'কোনো উত্তর পাওয়া যায়নি।',
        timestamp: Date.now(),
        persona: selectedPersona,
      };

      setMessages((prev) => [...prev, botMessage]);
    } catch (err: any) {
      const errorMessage: ChatMessage = {
        id: `err_${Date.now()}`,
        role: 'assistant',
        text: `⚠️ **সংযোগ বিঘ্নিত হয়েছে**: ${err.message || 'সার্ভারে সমস্যা দেখা দিয়েছে'}। দয়া করে কিছুক্ষণ পর আবার চেষ্টা করুন।`,
        timestamp: Date.now(),
        persona: selectedPersona,
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleTTS = async (id: string, text: string) => {
    // If currently playing, stop it
    if (playingAudioId === id) {
      if (audioPlayerRef.current) {
        audioPlayerRef.current.pause();
        audioPlayerRef.current = null;
      }
      window.speechSynthesis?.cancel();
      setPlayingAudioId(null);
      return;
    }

    // Clean markdown symbols for cleaner speech
    const plainText = text.replace(/[*#`_>-]/g, ' ').replace(/\n+/g, ' ').trim().slice(0, 350);

    setAudioLoadingId(id);

    try {
      // First attempt server TTS
      const res = await fetch('/api/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: plainText }),
      });

      if (res.ok) {
        const data = await res.json();
        if (data.audio) {
          const audio = new Audio(data.audio);
          audioPlayerRef.current = audio;
          audio.onended = () => setPlayingAudioId(null);
          audio.onerror = () => {
            fallbackSpeech(plainText, id);
          };
          await audio.play();
          setPlayingAudioId(id);
          setAudioLoadingId(null);
          return;
        }
      }
      fallbackSpeech(plainText, id);
    } catch (e) {
      fallbackSpeech(plainText, id);
    } finally {
      setAudioLoadingId(null);
    }
  };

  const fallbackSpeech = (text: string, id: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'bn-BD';
      utterance.onend = () => setPlayingAudioId(null);
      utterance.onerror = () => setPlayingAudioId(null);
      window.speechSynthesis.speak(utterance);
      setPlayingAudioId(id);
    } else {
      alert('ভয়েস প্লেয়ার আপনার সিস্টেমে কাজ করছে না।');
    }
  };

  const handleClearChat = () => {
    if (confirm('আপনি কি সমস্ত চ্যাট হিস্ট্রি মুছে ফেলতে চান?')) {
      setMessages([
        {
          id: 'welcome',
          role: 'assistant',
          text: 'চ্যাট হিস্ট্রি মুছে ফেলা হয়েছে। নতুন কী জানতে বা লিখতে চান বলুন!',
          timestamp: Date.now(),
          persona: 'general',
        },
      ]);
    }
  };

  const handleDownload = () => {
    const exportText = messages
      .map(
        (m) =>
          `[${m.role === 'user' ? 'আপনি' : 'দেশ AI'}] (${new Date(m.timestamp).toLocaleTimeString()}):\n${m.text}\n`
      )
      .join('\n---\n\n');

    const blob = new Blob([exportText], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `desh-ai-chat-${Date.now()}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const currentPersona = PERSONAS.find((p) => p.id === selectedPersona) || PERSONAS[0];

  return (
    <div className="flex flex-col h-[calc(100vh-4rem)] max-w-5xl mx-auto px-2 sm:px-4">
      {/* Persona Bar */}
      <div className="py-2.5 border-b border-slate-200/80 dark:border-slate-800/80 flex items-center justify-between gap-2 overflow-x-auto no-scrollbar">
        <div className="flex items-center gap-1.5 sm:gap-2">
          {PERSONAS.map((persona) => {
            const active = selectedPersona === persona.id;
            return (
              <button
                key={persona.id}
                onClick={() => setSelectedPersona(persona.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs sm:text-sm font-medium whitespace-nowrap transition-all ${
                  active
                    ? 'bg-emerald-700 text-white shadow-sm shadow-emerald-700/20 font-semibold ring-2 ring-emerald-500/30'
                    : 'bg-slate-100 dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-800'
                }`}
              >
                <span>{persona.name}</span>
                <span
                  className={`text-[10px] px-1 py-0.2 rounded ${
                    active
                      ? 'bg-emerald-800 text-emerald-100'
                      : 'bg-slate-200 dark:bg-slate-800 text-slate-500 dark:text-slate-400'
                  }`}
                >
                  {persona.badge}
                </span>
              </button>
            );
          })}
        </div>

        {/* Chat Control Actions */}
        <div className="flex items-center gap-1">
          <button
            onClick={handleDownload}
            title="চ্যাট হিস্ট্রি ডাউনলোড করুন"
            className="p-1.5 rounded-lg text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <Download size={16} />
          </button>
          <button
            onClick={handleClearChat}
            title="চ্যাট ক্লিয়ার করুন"
            className="p-1.5 rounded-lg text-slate-500 hover:text-rose-600 dark:text-slate-400 dark:hover:text-rose-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <Trash2 size={16} />
          </button>
        </div>
      </div>

      {/* Messages Container */}
      <div className="flex-1 overflow-y-auto py-4 space-y-4 px-1">
        {messages.map((message) => {
          const isUser = message.role === 'user';
          const isPlaying = playingAudioId === message.id;
          const isAudioLoading = audioLoadingId === message.id;

          return (
            <div
              key={message.id}
              className={`flex gap-3 ${isUser ? 'justify-end' : 'justify-start'}`}
            >
              {!isUser && (
                <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-emerald-700 to-teal-500 flex items-center justify-center text-white font-bold text-xs shrink-0 shadow-sm mt-1">
                  দেশ
                </div>
              )}

              <div
                className={`max-w-[85%] md:max-w-[78%] rounded-2xl px-4 py-3 shadow-sm ${
                  isUser
                    ? 'bg-emerald-700 text-white rounded-tr-none'
                    : 'bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800/80 text-slate-800 dark:text-slate-100 rounded-tl-none'
                }`}
              >
                {/* Message Header for Assistant */}
                {!isUser && (
                  <div className="flex items-center justify-between gap-3 pb-1.5 mb-2 border-b border-slate-100 dark:border-slate-800 text-[11px] text-slate-400">
                    <span className="font-semibold text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                      <Sparkles size={12} />
                      দেশ AI
                    </span>
                    <div className="flex items-center gap-2">
                      {/* Read Aloud Button */}
                      <button
                        onClick={() => handleTTS(message.id, message.text)}
                        title={isPlaying ? 'বন্ধ করুন' : 'শুনে নিন'}
                        disabled={isAudioLoading}
                        className={`p-1 rounded hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors ${
                          isPlaying ? 'text-emerald-600 dark:text-emerald-400 font-bold' : ''
                        }`}
                      >
                        {isAudioLoading ? (
                          <span className="text-[10px] animate-pulse">প্রস্তুত হচ্ছে...</span>
                        ) : isPlaying ? (
                          <VolumeX size={14} className="text-rose-500" />
                        ) : (
                          <Volume2 size={14} />
                        )}
                      </button>

                      {/* Copy Button */}
                      <button
                        onClick={() => handleCopy(message.id, message.text)}
                        title="কপি করুন"
                        className="p-1 rounded hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                      >
                        {copiedId === message.id ? (
                          <Check size={14} className="text-emerald-500" />
                        ) : (
                          <Copy size={14} />
                        )}
                      </button>
                    </div>
                  </div>
                )}

                {/* Content */}
                {isUser ? (
                  <p className="whitespace-pre-wrap leading-relaxed text-sm md:text-base font-normal">
                    {message.text}
                  </p>
                ) : (
                  <MarkdownView content={message.text} />
                )}

                <div
                  className={`text-[10px] mt-2 text-right ${
                    isUser ? 'text-emerald-200' : 'text-slate-400'
                  }`}
                >
                  {new Date(message.timestamp).toLocaleTimeString([], {
                    hour: '2-digit',
                    minute: '2-digit',
                  })}
                </div>
              </div>

              {isUser && (
                <div className="w-8 h-8 rounded-xl bg-slate-800 dark:bg-slate-700 flex items-center justify-center text-white font-semibold text-xs shrink-0 mt-1">
                  আপনি
                </div>
              )}
            </div>
          );
        })}

        {/* Loading Indicator */}
        {loading && (
          <div className="flex gap-3 items-start">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-emerald-700 to-teal-500 flex items-center justify-center text-white font-bold text-xs shrink-0 shadow-sm animate-pulse">
              দেশ
            </div>
            <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800/80 rounded-2xl rounded-tl-none px-4 py-3 shadow-sm flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-emerald-600 animate-bounce"></div>
              <div className="w-2 h-2 rounded-full bg-emerald-600 animate-bounce [animation-delay:-.15s]"></div>
              <div className="w-2 h-2 rounded-full bg-emerald-600 animate-bounce [animation-delay:-.3s]"></div>
              <span className="text-xs text-slate-500 dark:text-slate-400 ml-1">
                দেশ AI উত্তর প্রস্তুত করছে...
              </span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Prompts (if chat is short) */}
      {messages.length <= 2 && (
        <div className="py-2 overflow-x-auto no-scrollbar">
          <p className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1.5 flex items-center gap-1">
            <Sparkles size={12} className="text-amber-500" />
            দ্রুত প্রশ্ন করতে ক্লিক করুন:
          </p>
          <div className="flex gap-1.5">
            {SUGGESTED_PROMPTS.map((item, idx) => (
              <button
                key={idx}
                onClick={() => handleSend(item.text)}
                className="whitespace-nowrap px-3 py-1.5 rounded-xl text-xs bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-emerald-500/50 hover:bg-emerald-50/50 dark:hover:bg-emerald-950/30 text-slate-700 dark:text-slate-300 transition-colors flex items-center gap-1.5"
              >
                <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-100 dark:bg-emerald-950 px-1 rounded">
                  {item.tag}
                </span>
                <span>{item.text}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Input Box Area */}
      <div className="py-3 border-t border-slate-200/80 dark:border-slate-800/80">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend();
          }}
          className="relative flex items-end gap-2 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-2xl p-2 shadow-sm focus-within:border-emerald-500 focus-within:ring-2 focus-within:ring-emerald-500/20 transition-all"
        >
          {/* Voice input button */}
          <button
            type="button"
            onClick={toggleRecording}
            title={isRecording ? 'ভয়েস ইনপুট বন্ধ করুন' : 'বাংলায় মুখে বলুন (Voice)'}
            className={`p-2.5 rounded-xl transition-colors shrink-0 ${
              isRecording
                ? 'bg-rose-500 text-white animate-pulse'
                : 'text-slate-400 hover:text-emerald-600 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            {isRecording ? <MicOff size={19} /> : <Mic size={19} />}
          </button>

          {/* Text Area */}
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
            placeholder={
              isRecording
                ? 'শুনছি... অনুগ্রহ করে স্পষ্ট করে বাংলায় বলুন...'
                : currentPersona.placeholder
            }
            rows={1}
            className="flex-1 bg-transparent border-0 focus:outline-none resize-none py-1.5 px-1 text-sm md:text-base text-slate-800 dark:text-slate-100 placeholder:text-slate-400 max-h-32"
            style={{ minHeight: '38px' }}
          />

          {/* Send Button */}
          <button
            type="submit"
            disabled={!input.trim() || loading}
            className={`p-2.5 rounded-xl font-medium transition-all shrink-0 ${
              input.trim() && !loading
                ? 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-md shadow-emerald-700/20 active:scale-95'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-400 cursor-not-allowed'
            }`}
          >
            <Send size={18} />
          </button>
        </form>
        <div className="flex items-center justify-between px-2 pt-1.5 text-[11px] text-slate-400">
          <span>প্রমিত বাংলা ও ইংরেজি উভয় ভাষায় লিখতে পারেন</span>
          <span className="flex items-center gap-1">
            <Info size={11} />
            এআই ভুল করতে পারে, জরুরি তথ্য যাচাই করুন
          </span>
        </div>
      </div>
    </div>
  );
};
