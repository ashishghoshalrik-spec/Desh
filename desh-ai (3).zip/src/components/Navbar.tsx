import React from 'react';
import { 
  MessageSquare, 
  PhoneCall,
  PenTool, 
  Languages, 
  GraduationCap, 
  Sparkles, 
  Moon, 
  Sun, 
  Compass, 
  Share2,
  Check,
  Radio
} from 'lucide-react';
import { ActiveTab } from '../types';

interface NavbarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  darkMode: boolean;
  setDarkMode: (val: boolean) => void;
  onOpenPromptsModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  darkMode,
  setDarkMode,
  onOpenPromptsModal,
}) => {
  const [copiedShare, setCopiedShare] = React.useState(false);

  const handleShare = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(window.location.href);
      setCopiedShare(true);
      setTimeout(() => setCopiedShare(false), 2000);
    }
  };

  const navItems: { id: ActiveTab; label: string; icon: React.ReactNode; badge?: string }[] = [
    {
      id: 'chat',
      label: 'দেশ চ্যাট',
      icon: <MessageSquare size={18} />,
    },
    {
      id: 'call',
      label: 'ডায়াল ও কল',
      icon: <PhoneCall size={18} />,
      badge: 'লাইভ ভয়েস',
    },
    {
      id: 'ipphone',
      label: 'আইপি ফোন',
      icon: <Radio size={18} />,
      badge: 'VoIP',
    },
    {
      id: 'writer',
      label: 'লেখা ও আবেদন',
      icon: <PenTool size={18} />,
      badge: 'জনপ্রিয়',
    },
    {
      id: 'translator',
      label: 'অনুবাদ ও ব্যাকরণ',
      icon: <Languages size={18} />,
    },
    {
      id: 'quiz',
      label: 'বিসিএস ও প্রস্তুতি',
      icon: <GraduationCap size={18} />,
      badge: 'কুইজ',
    },
  ];

  return (
    <header className="sticky top-0 z-40 w-full backdrop-blur-md bg-white/85 dark:bg-slate-950/85 border-b border-emerald-950/10 dark:border-emerald-800/20 transition-colors">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Brand Logo */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setActiveTab('chat')}
              className="flex items-center gap-2.5 group text-left focus:outline-none"
            >
              <div className="relative w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-700 via-emerald-600 to-teal-500 flex items-center justify-center shadow-md shadow-emerald-700/20 group-hover:scale-105 transition-transform">
                <span className="text-white font-black text-xl tracking-tighter">দে</span>
                {/* Red sun dot reminiscent of the Bangladesh flag */}
                <div className="absolute top-1.5 right-1.5 w-3 h-3 rounded-full bg-rose-500 border-2 border-white dark:border-slate-950 shadow-sm animate-pulse"></div>
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="font-extrabold text-xl tracking-tight text-slate-900 dark:text-white">
                    দেশ <span className="text-emerald-600 dark:text-emerald-400">AI</span>
                  </span>
                  <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                    বাংলা
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 hidden sm:block">
                  বাংলাদেশের প্রথম পূর্ণাঙ্গ কৃত্রিম বুদ্ধিমত্তা
                </p>
              </div>
            </button>
          </div>

          {/* Desktop Nav Items */}
          <nav className="hidden md:flex items-center gap-1 bg-slate-100/80 dark:bg-slate-900/80 p-1 rounded-2xl border border-slate-200/80 dark:border-slate-800">
            {navItems.map((item) => {
              const active = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`relative flex items-center gap-2 px-3.5 py-2 rounded-xl text-sm font-medium transition-all ${
                    active
                      ? 'bg-white dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300 shadow-sm font-semibold border border-emerald-600/20'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-200/50 dark:hover:bg-slate-800/50'
                  }`}
                >
                  {item.icon}
                  <span>{item.label}</span>
                  {item.badge && (
                    <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-rose-500/10 text-rose-600 dark:text-rose-400 border border-rose-500/20 font-bold">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Right Actions */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            {/* Inspiring Prompts Button */}
            <button
              onClick={onOpenPromptsModal}
              className="hidden lg:flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 hover:bg-emerald-100 transition-colors"
            >
              <Compass size={15} />
              <span>প্রম্পট আইডিয়া</span>
            </button>

            {/* Share App */}
            <button
              onClick={handleShare}
              title="শেয়ার লিংক কপি করুন"
              className="p-2 rounded-xl text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              {copiedShare ? <Check size={18} className="text-emerald-500" /> : <Share2 size={18} />}
            </button>

            {/* Dark / Light Toggle */}
            <button
              onClick={() => setDarkMode(!darkMode)}
              title={darkMode ? 'লাইট মোড অন করুন' : 'ডার্ক মোড অন করুন'}
              className="p-2 rounded-xl text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              {darkMode ? <Sun size={19} className="text-amber-400" /> : <Moon size={19} />}
            </button>
          </div>
        </div>

        {/* Mobile Horizontal Subnav */}
        <div className="flex md:hidden items-center gap-1.5 py-2 overflow-x-auto no-scrollbar border-t border-slate-200/50 dark:border-slate-800/50">
          {navItems.map((item) => {
            const active = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`whitespace-nowrap flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                  active
                    ? 'bg-emerald-600 text-white font-semibold shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 bg-slate-100 dark:bg-slate-900'
                }`}
              >
                {item.icon}
                <span>{item.label}</span>
              </button>
            );
          })}
          <button
            onClick={onOpenPromptsModal}
            className="whitespace-nowrap flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800"
          >
            <Sparkles size={13} />
            <span>আইডিয়া</span>
          </button>
        </div>
      </div>
    </header>
  );
};
