import React, { useState, useEffect, useRef } from 'react';
import { 
  Phone, 
  PhoneOff, 
  PhoneCall, 
  Mic, 
  MicOff, 
  Volume2, 
  VolumeX, 
  Delete, 
  Clock, 
  History, 
  Bookmark, 
  Sparkles, 
  ShieldAlert, 
  Grid, 
  Send,
  Radio,
  Headphones,
  Check,
  AlertCircle,
  Trash2,
  Copy,
  Search,
  X,
  Smile,
  User,
  RotateCcw,
  Calendar,
  CalendarPlus,
  CalendarClock,
  Bell,
  BellRing,
  Plus,
  CheckCircle2,
  BookUser,
  UserPlus,
  Edit3,
  Tag,
  Disc,
  Download,
  Play,
  Pause,
  HardDrive
} from 'lucide-react';
import { HotlineContact, CallHistoryItem, ScheduledCall, SavedContact, CallRecordingItem } from '../types';
import { 
  playDtmfTone, 
  PhoneRinger, 
  floatTo16BitPCM, 
  arrayBufferToBase64, 
  base64ToArrayBuffer 
} from '../utils/audio';
import {
  saveCallRecording,
  getAllCallRecordings,
  deleteCallRecording,
  clearAllCallRecordings,
  formatBytes,
  downloadCallRecording
} from '../utils/callRecordingStorage';

const HOTLINES: HotlineContact[] = [
  {
    number: '16122',
    name: 'দেশ AI মূল কল সেন্টার',
    subtitle: 'সাধারণ তথ্য, বুদ্ধিমত্তা ও দৈনিক পরামর্শ',
    category: 'ai',
    icon: 'Sparkles',
    voicePrompt: 'দেশ AI প্রধান কল সেন্টারে স্বাগতম! আপনি যেকোনো প্রশ্ন করতে পারেন।',
  },
  {
    number: '16123',
    name: 'বিসিএস ও ক্যারিয়ার হেল্পলাইন',
    subtitle: 'বিসিএস প্রস্তুতি, চাকরি, ভাইভা টিপস ও শিক্ষা',
    category: 'edu',
    icon: 'GraduationCap',
    voicePrompt: 'বিসিএস ও ক্যারিয়ার হেল্পলাইনে স্বাগতম! বিসিএস বা পরীক্ষার কোন বিষয়ে জানতে চান?',
  },
  {
    number: '16124',
    name: 'কৃষি ও গ্রামীণ সেবা কল সেন্টার',
    subtitle: 'ফসল চাষ, সার-কীটনাশক, মাছ ও পশুপালন',
    category: 'govt',
    icon: 'Sprout',
    voicePrompt: 'কৃষি তথ্য ও গ্রামীণ সেবা হেল্পলাইনে স্বাগতম! আপনার ফসল সম্পর্কে বলুন।',
  },
  {
    number: '16125',
    name: 'নাগরিক অধিকার ও আইনি সহায়তা',
    subtitle: 'সংবিধান, মৌলিক অধিকার ও আইনি দিকনির্দেশনা',
    category: 'govt',
    icon: 'BookOpen',
    voicePrompt: 'নাগরিক ও আইনি তথ্য সেবায় স্বাগতম! কী বিষয়ে পরামর্শ প্রয়োজন?',
  },
  {
    number: '16126',
    name: 'ডিজিটাল স্বাস্থ্য তথ্য সেবা',
    subtitle: 'প্রাথমিক চিকিৎসা, পুষ্টি ও স্বাস্থ্য তথ্য',
    category: 'health',
    icon: 'Heart',
    voicePrompt: 'স্বাস্থ্য তথ্য ও সুস্থতা সেবায় স্বাগতম! আপনার স্বাস্থ্য বিষয়ক প্রশ্নটি করুন।',
  },
  {
    number: '16127',
    name: 'বাংলা সাহিত্য ও কবিতা আসর',
    subtitle: 'কবিতা আবৃত্তি, সাহিত্যের রস ও কথপোকথন',
    category: 'ai',
    icon: 'Feather',
    voicePrompt: 'বাংলা সাহিত্য ও কবিতা আসরে স্বাগতম! আজ কী শুনতে বা আলোচনা করতে চান?',
  },
  {
    number: '999',
    name: 'জাতীয় জরুরি সেবা (সিমুলেশন)',
    subtitle: 'বাংলাদেশ পুলিশ, ফায়ার সার্ভিস ও অ্যাম্বুলেন্স তথ্য',
    category: 'emergency',
    icon: 'ShieldAlert',
    voicePrompt: 'জাতীয় জরুরি তথ্য সহায়তায় স্বাগতম! আপনার জরুরি অবস্থা জানান।',
  },
];

export const INITIAL_CONTACTS: SavedContact[] = [
  {
    id: 'c-1',
    name: 'আম্মু / পরিবার',
    number: '01711223344',
    category: 'পরিবার',
    note: 'বাসার সার্বক্ষণিক জরুরি যোগাযোগ',
    createdAt: Date.now() - 86400000 * 5,
  },
  {
    id: 'c-2',
    name: 'ডাঃ রফিকুল ইসলাম',
    number: '01819556677',
    category: 'স্বাস্থ্য',
    note: 'পারিবারিক মেডিসিন বিশেষজ্ঞ ডাক্তার',
    createdAt: Date.now() - 86400000 * 4,
  },
  {
    id: 'c-3',
    name: 'তানভীর আহমেদ (অফিস)',
    number: '01911998877',
    category: 'অফিস',
    note: 'প্রজেক্ট ম্যানেজার ও টিম লিডার',
    createdAt: Date.now() - 86400000 * 3,
  },
  {
    id: 'c-4',
    name: 'রাকিব হাসান (বন্ধু)',
    number: '01622334455',
    category: 'বন্ধু',
    note: 'ভার্সিটি স্টাডি ও বিসিএস পার্টনার',
    createdAt: Date.now() - 86400000 * 2,
  },
  {
    id: 'c-5',
    name: 'দেশ AI মূল কল সেন্টার',
    number: '16122',
    category: 'জরুরি',
    note: '২৪/৭ বাংলা ইন্টেলিজেন্ট কল ও তথ্য সেবা',
    createdAt: Date.now() - 86400000,
  },
  {
    id: 'c-6',
    name: 'বিসিএস ও ক্যারিয়ার হেল্পলাইন',
    number: '16123',
    category: 'শিক্ষা',
    note: 'বিসিএস প্রিলিমিনারি ও ক্যারিয়ার পরামর্শ',
    createdAt: Date.now() - 43200000,
  },
];

export const CONTACT_CATEGORIES = [
  { id: 'সব', label: 'সব কন্টাক্ট', badgeClass: '' },
  { id: 'পরিবার', label: 'পরিবার', badgeClass: 'bg-rose-50 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300 border-rose-200 dark:border-rose-800' },
  { id: 'বন্ধু', label: 'বন্ধু', badgeClass: 'bg-purple-50 text-purple-700 dark:bg-purple-950/60 dark:text-purple-300 border-purple-200 dark:border-purple-800' },
  { id: 'অফিস', label: 'অফিস', badgeClass: 'bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300 border-blue-200 dark:border-blue-800' },
  { id: 'স্বাস্থ্য', label: 'স্বাস্থ্য', badgeClass: 'bg-teal-50 text-teal-700 dark:bg-teal-950/60 dark:text-teal-300 border-teal-200 dark:border-teal-800' },
  { id: 'জরুরি', label: 'জরুরি', badgeClass: 'bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300 border-amber-200 dark:border-amber-800' },
  { id: 'শিক্ষা', label: 'শিক্ষা', badgeClass: 'bg-indigo-50 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-300 border-indigo-200 dark:border-indigo-800' },
  { id: 'সাধারণ', label: 'সাধারণ', badgeClass: 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 border-slate-200 dark:border-slate-700' },
];

const KEYPAD_BUTTONS = [
  { digit: '1', sub: 'সাধারণ' },
  { digit: '2', sub: 'বিসিএস' },
  { digit: '3', sub: 'কৃষি' },
  { digit: '4', sub: 'আইন' },
  { digit: '5', sub: 'স্বাস্থ্য' },
  { digit: '6', sub: 'সাহিত্য' },
  { digit: '7', sub: 'জরুরি' },
  { digit: '8', sub: 'কোডিং' },
  { digit: '9', sub: 'অনুবাদ' },
  { digit: '*', sub: 'কমান্ড' },
  { digit: '0', sub: '+' },
  { digit: '#', sub: 'হ্যাশ' },
];

const GRADIENT_PALETTES = [
  'from-emerald-600 to-teal-800',
  'from-blue-600 to-indigo-800',
  'from-purple-600 to-indigo-900',
  'from-rose-600 to-pink-800',
  'from-amber-600 to-orange-800',
  'from-cyan-600 to-blue-800',
  'from-violet-600 to-fuchsia-800',
  'from-teal-600 to-emerald-900',
];

export function getGradientForString(str: string): string {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = str.charCodeAt(i) + ((hash << 5) - hash);
  }
  const index = Math.abs(hash) % GRADIENT_PALETTES.length;
  return GRADIENT_PALETTES[index];
}

export function getInitials(name: string, number: string): string {
  const cleanName = name.replace(/[^a-zA-Z0-9\u0980-\u09FF\s]/g, '').trim();
  if (cleanName) {
    const words = cleanName.split(/\s+/);
    if (words.length >= 2) {
      return (words[0].slice(0, 1) + words[1].slice(0, 1));
    }
    return cleanName.slice(0, 2);
  }
  return number.slice(-2);
}

const EMOJI_CATEGORIES = [
  {
    name: 'জনপ্রিয় ও জাতীয়',
    emojis: ['🇧🇩', '🤖', '🎓', '🌾', '⚖️', '🩺', '✍️', '🚨', '🏛️', '⭐'],
  },
  {
    name: 'শিক্ষা ও ক্যারিয়ার',
    emojis: ['🎓', '📚', '💼', '✍️', '🎯', '💡', '🏆', '📝', '🧠', '💻'],
  },
  {
    name: 'কৃষি ও প্রকৃতি',
    emojis: ['🌾', '🚜', '🐟', '🐄', '🌴', '🌱', '🌿', '🥭', '🌻', '🍎'],
  },
  {
    name: 'স্বাস্থ্য ও চিকিৎসা',
    emojis: ['🩺', '🏥', '💊', '❤️', '🧘', '🚑', '🩹', '🍎', '🍵', '🧬'],
  },
  {
    name: 'আইন ও নাগরিক',
    emojis: ['⚖️', '🏛️', '🛡️', '📜', '👮', '🚨', '📋', '🔑', '🤝', '🏢'],
  },
  {
    name: 'সাহিত্য ও সংস্কৃতি',
    emojis: ['✍️', '🎭', '📜', '🎨', '🎵', '📖', '☕', '🌸', '✨', '🎙️'],
  },
  {
    name: 'যোগাযোগ ও ব্যক্তি',
    emojis: ['📞', '☎️', '👤', '👨‍💼', '👩‍💼', '👨‍🌾', '👩‍🎓', '💬', '🔔', '❤️'],
  },
];

interface CallTabProps {
  onNavigateToIpPhone?: () => void;
}

export const CallTab: React.FC<CallTabProps> = ({ onNavigateToIpPhone }) => {
  const [dialedNumber, setDialedNumber] = useState('');
  const [activeTab, setActiveTab] = useState<'keypad' | 'contacts' | 'recordings' | 'hotlines' | 'history' | 'schedule'>('keypad');
  
  // Call States
  const [inCall, setInCall] = useState(false);
  const [callStatus, setCallStatus] = useState<'connecting' | 'ringing' | 'connected' | 'ended'>('connecting');
  const [activeContact, setActiveContact] = useState<{ number: string; name: string }>({ number: '', name: '' });
  const [callDuration, setCallDuration] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [speakerOn, setSpeakerOn] = useState(true);
  const [showInCallKeypad, setShowInCallKeypad] = useState(false);
  const [transcript, setTranscript] = useState<string[]>([]);
  const [inCallTextInput, setInCallTextInput] = useState('');
  const [micWaveActivity, setMicWaveActivity] = useState(0);
  const [aiSpeaking, setAiSpeaking] = useState(false);

  // Call Recording States & Browser IndexedDB Storage
  const [recordings, setRecordings] = useState<CallRecordingItem[]>([]);
  const [recordingsSearchQuery, setRecordingsSearchQuery] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [recordingDuration, setRecordingDuration] = useState(0);
  const [playingRecordingId, setPlayingRecordingId] = useState<string | null>(null);
  const [playbackProgress, setPlaybackProgress] = useState(0);
  const [playbackCurrentTime, setPlaybackCurrentTime] = useState(0);
  const [toastMessage, setToastMessage] = useState<{
    text: string;
    actionText?: string;
    onAction?: () => void;
  } | null>(null);

  // Call History State
  const [history, setHistory] = useState<CallHistoryItem[]>(() => {
    const saved = localStorage.getItem('desh_call_history');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return [
      {
        id: 'h1',
        number: '16122',
        name: 'দেশ AI মূল কল সেন্টার',
        timestamp: Date.now() - 3600000,
        durationSeconds: 84,
        type: 'outgoing',
      },
      {
        id: 'h2',
        number: '16123',
        name: 'বিসিএস ও ক্যারিয়ার হেল্পলাইন',
        timestamp: Date.now() - 86400000,
        durationSeconds: 142,
        type: 'outgoing',
      },
    ];
  });

  // Search Queries for Speed Dial & Call History
  const [speedDialSearchQuery, setSpeedDialSearchQuery] = useState('');
  const [historySearchQuery, setHistorySearchQuery] = useState('');

  // Scheduled Calls State (stored in localStorage)
  const [scheduledCalls, setScheduledCalls] = useState<ScheduledCall[]>(() => {
    const saved = localStorage.getItem('desh_scheduled_calls');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {}
    }
    // Seed useful default reminders for first-time onboarding
    return [
      {
        id: 'sc-1',
        contactName: 'বিসিএস ও ক্যারিয়ার হেল্পলাইন',
        contactNumber: '16123',
        scheduledTime: Date.now() + 3600000 * 2,
        note: 'বাংলা ব্যাকরণ ও সাধারণ জ্ঞান প্রস্তুতি পরামর্শ',
        createdAt: Date.now() - 60000,
        status: 'pending',
      },
      {
        id: 'sc-2',
        contactName: 'কৃষি ও কৃষক বন্ধু কল সেন্টার',
        contactNumber: '16124',
        scheduledTime: Date.now() + 86400000,
        note: 'আমের ফলন বৃদ্ধি ও সার প্রয়োগ বিষয়ক প্রশ্ন',
        createdAt: Date.now() - 120000,
        status: 'pending',
      },
    ];
  });

  const [scheduleSearchQuery, setScheduleSearchQuery] = useState('');
  const [scheduleFilter, setScheduleFilter] = useState<'all' | 'pending' | 'completed'>('pending');

  // Schedule Call Modal Dialog State
  const [isScheduleModalOpen, setIsScheduleModalOpen] = useState(false);
  const [scheduleForm, setScheduleForm] = useState<{
    contactName: string;
    contactNumber: string;
    date: string;
    time: string;
    note: string;
  }>({
    contactName: '',
    contactNumber: '',
    date: '',
    time: '',
    note: '',
  });

  // Active Reminder Alert state
  const [activeReminder, setActiveReminder] = useState<ScheduledCall | null>(null);

  // Custom Avatar / Emoji Mapping stored in localStorage: { [contactNumber]: emojiString }
  const [customAvatars, setCustomAvatars] = useState<Record<string, string>>(() => {
    const saved = localStorage.getItem('desh_contact_avatars');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {}
    }
    return {
      '16122': '🤖',
      '16123': '🎓',
      '16124': '🌾',
      '16125': '⚖️',
      '16126': '🩺',
      '16127': '✍️',
      '999': '🚨',
      '01711223344': '❤️',
      '01819556677': '🩺',
      '01911998877': '💼',
      '01622334455': '🤝',
    };
  });

  // Saved Contacts State (Stored in localStorage)
  const [contacts, setContacts] = useState<SavedContact[]>(() => {
    const saved = localStorage.getItem('desh_saved_contacts');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {}
    }
    return INITIAL_CONTACTS;
  });

  const [contactSearchQuery, setContactSearchQuery] = useState('');
  const [contactCategoryFilter, setContactCategoryFilter] = useState<string>('সব');
  const [isContactModalOpen, setIsContactModalOpen] = useState(false);
  const [contactForm, setContactForm] = useState<{
    id?: string;
    name: string;
    number: string;
    category: string;
    note: string;
    avatar?: string;
  }>({
    name: '',
    number: '',
    category: 'সাধারণ',
    note: '',
    avatar: '',
  });

  // Save contacts to localStorage
  useEffect(() => {
    localStorage.setItem('desh_saved_contacts', JSON.stringify(contacts));
  }, [contacts]);

  const openAddContactModal = (prefillNumber?: string, prefillName?: string) => {
    setContactForm({
      name: prefillName || '',
      number: prefillNumber || '',
      category: 'সাধারণ',
      note: '',
      avatar: '',
    });
    setIsContactModalOpen(true);
  };

  const openEditContactModal = (contact: SavedContact) => {
    setContactForm({
      id: contact.id,
      name: contact.name,
      number: contact.number,
      category: contact.category || 'সাধারণ',
      note: contact.note || '',
      avatar: customAvatars[contact.number] || '',
    });
    setIsContactModalOpen(true);
  };

  const handleSaveContact = (e: React.FormEvent) => {
    e.preventDefault();
    if (!contactForm.name.trim() || !contactForm.number.trim()) return;

    const trimmedNumber = contactForm.number.trim();
    const trimmedName = contactForm.name.trim();

    if (contactForm.id) {
      // Edit existing
      setContacts((prev) =>
        prev.map((c) =>
          c.id === contactForm.id
            ? {
                ...c,
                name: trimmedName,
                number: trimmedNumber,
                category: contactForm.category,
                note: contactForm.note.trim() || undefined,
              }
            : c
        )
      );
    } else {
      // Add new
      const newContact: SavedContact = {
        id: `c-${Date.now()}`,
        name: trimmedName,
        number: trimmedNumber,
        category: contactForm.category || 'সাধারণ',
        note: contactForm.note.trim() || undefined,
        createdAt: Date.now(),
      };
      setContacts((prev) => [newContact, ...prev]);
    }

    if (contactForm.avatar) {
      setCustomAvatars((prev) => ({
        ...prev,
        [trimmedNumber]: contactForm.avatar!,
      }));
    }

    setIsContactModalOpen(false);
  };

  const handleDeleteContact = (id: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    const contact = contacts.find((c) => c.id === id);
    if (!contact) return;
    if (window.confirm(`আপনি কি "${contact.name}" কন্টাক্টটি মুছে ফেলতে চান?`)) {
      setContacts((prev) => prev.filter((c) => c.id !== id));
    }
  };

  // Save custom avatars to localStorage
  useEffect(() => {
    localStorage.setItem('desh_contact_avatars', JSON.stringify(customAvatars));
  }, [customAvatars]);

  // Target contact currently being edited for custom emoji/avatar
  const [editingAvatarTarget, setEditingAvatarTarget] = useState<{
    number: string;
    name: string;
    currentAvatar?: string;
  } | null>(null);
  const [customEmojiInput, setCustomEmojiInput] = useState('');

  const handleAssignEmoji = (number: string, emoji: string | null) => {
    setCustomAvatars((prev) => {
      const updated = { ...prev };
      if (!emoji) {
        delete updated[number];
      } else {
        updated[number] = emoji;
      }
      return updated;
    });

    // Also update history records
    setHistory((prev) =>
      prev.map((item) =>
        item.number === number ? { ...item, avatar: emoji || undefined } : item
      )
    );

    // Also update contacts records
    setContacts((prev) =>
      prev.map((item) =>
        item.number === number ? { ...item, avatar: emoji || undefined } : item
      )
    );

    setEditingAvatarTarget(null);
  };

  // Helper to render contact avatar (custom emoji or auto-generated gradient with initials)
  const renderContactAvatar = (
    number: string,
    name: string,
    sizeClass = 'w-11 h-11',
    editable = true
  ) => {
    const customEmoji = customAvatars[number];
    const gradient = getGradientForString(number + name);
    const initials = getInitials(name, number);

    return (
      <div className="relative group shrink-0">
        <div
          className={`${sizeClass} rounded-2xl bg-gradient-to-tr ${gradient} flex items-center justify-center font-bold text-white shadow-xs select-none transition-transform group-hover:scale-105`}
        >
          {customEmoji ? (
            <span className="text-xl leading-none">{customEmoji}</span>
          ) : (
            <span className="font-mono text-xs sm:text-sm tracking-tight">{initials}</span>
          )}
        </div>

        {editable && (
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setEditingAvatarTarget({
                number,
                name,
                currentAvatar: customEmoji,
              });
              setCustomEmojiInput(customEmoji || '');
            }}
            title="ইমোজি বা অবতার পরিবর্তন করুন"
            className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xs flex items-center justify-center text-slate-500 hover:text-emerald-600 dark:hover:text-emerald-400 transition-colors opacity-80 group-hover:opacity-100"
          >
            <Smile size={11} />
          </button>
        )}
      </div>
    );
  };

  // Filtered Contacts
  const filteredContacts = contacts
    .filter((c) => {
      if (contactCategoryFilter === 'সব') return true;
      return c.category === contactCategoryFilter;
    })
    .filter((c) => {
      if (!contactSearchQuery.trim()) return true;
      const q = contactSearchQuery.toLowerCase().trim();
      return (
        c.name.toLowerCase().includes(q) ||
        c.number.includes(q) ||
        (c.note && c.note.toLowerCase().includes(q)) ||
        (c.category && c.category.toLowerCase().includes(q))
      );
    });

  // Filtered Speed Dial Hotlines
  const filteredHotlines = HOTLINES.filter((item) => {
    const q = speedDialSearchQuery.trim().toLowerCase();
    if (!q) return true;
    return (
      item.name.toLowerCase().includes(q) ||
      item.number.includes(q) ||
      item.subtitle.toLowerCase().includes(q)
    );
  });

  // Filtered Call History
  const filteredHistory = history.filter((item) => {
    const q = historySearchQuery.trim().toLowerCase();
    if (!q) return true;
    return (
      item.name.toLowerCase().includes(q) ||
      item.number.includes(q)
    );
  });

  // Filtered Call Recordings (IndexedDB)
  const filteredRecordings = recordings.filter((item) => {
    const q = recordingsSearchQuery.trim().toLowerCase();
    if (!q) return true;
    return (
      item.contactName.toLowerCase().includes(q) ||
      item.contactNumber.includes(q)
    );
  });

  // Filtered & Sorted Scheduled Calls
  const filteredScheduledCalls = scheduledCalls
    .filter((item) => {
      if (scheduleFilter === 'pending') return item.status === 'pending';
      if (scheduleFilter === 'completed') return item.status === 'completed';
      return true;
    })
    .filter((item) => {
      if (!scheduleSearchQuery.trim()) return true;
      const q = scheduleSearchQuery.toLowerCase().trim();
      return (
        item.contactName.toLowerCase().includes(q) ||
        item.contactNumber.includes(q) ||
        (item.note && item.note.toLowerCase().includes(q))
      );
    })
    .sort((a, b) => {
      if (a.status === 'pending' && b.status === 'pending') {
        return a.scheduledTime - b.scheduledTime;
      }
      return b.scheduledTime - a.scheduledTime;
    });

  const pendingScheduleCount = scheduledCalls.filter((c) => c.status === 'pending').length;

  // Persist scheduled calls to localStorage
  useEffect(() => {
    localStorage.setItem('desh_scheduled_calls', JSON.stringify(scheduledCalls));
  }, [scheduledCalls]);

  // Audio chime player for reminder alert
  const playReminderChime = () => {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const audioCtx = new AudioCtx();
      const now = audioCtx.currentTime;

      // Note 1: E5 (659.25Hz)
      const osc1 = audioCtx.createOscillator();
      const gain1 = audioCtx.createGain();
      osc1.type = 'sine';
      osc1.frequency.setValueAtTime(659.25, now);
      gain1.gain.setValueAtTime(0.3, now);
      gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.5);
      osc1.connect(gain1);
      gain1.connect(audioCtx.destination);
      osc1.start(now);
      osc1.stop(now + 0.5);

      // Note 2: G5 (783.99Hz)
      const osc2 = audioCtx.createOscillator();
      const gain2 = audioCtx.createGain();
      osc2.type = 'sine';
      osc2.frequency.setValueAtTime(783.99, now + 0.18);
      gain2.gain.setValueAtTime(0.3, now + 0.18);
      gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.8);
      osc2.connect(gain2);
      gain2.connect(audioCtx.destination);
      osc2.start(now + 0.18);
      osc2.stop(now + 0.8);
    } catch (e) {}
  };

  // Scheduled Call Timer Monitor
  useEffect(() => {
    const checkSchedules = () => {
      const now = Date.now();
      const dueCall = scheduledCalls.find(
        (c) => c.status === 'pending' && !c.reminded && c.scheduledTime <= now
      );

      if (dueCall) {
        setScheduledCalls((prev) =>
          prev.map((c) => (c.id === dueCall.id ? { ...c, reminded: true } : c))
        );
        playReminderChime();
        setActiveReminder(dueCall);

        if ('Notification' in window && Notification.permission === 'granted') {
          try {
            new Notification('🔔 দেশ AI - কল করার সময় হয়েছে!', {
              body: `${dueCall.contactName} (${dueCall.contactNumber})${
                dueCall.note ? `\nনোট: ${dueCall.note}` : ''
              }`,
            });
          } catch (e) {}
        }
      }
    };

    const interval = setInterval(checkSchedules, 5000);
    return () => clearInterval(interval);
  }, [scheduledCalls]);

  // Open Schedule Modal with prefilled contact details
  const openScheduleModal = (contact?: { name: string; number: string }) => {
    const targetDate = new Date(Date.now() + 30 * 60000); // 30 minutes from now default
    const year = targetDate.getFullYear();
    const month = String(targetDate.getMonth() + 1).padStart(2, '0');
    const day = String(targetDate.getDate()).padStart(2, '0');
    const hours = String(targetDate.getHours()).padStart(2, '0');
    const minutes = String(targetDate.getMinutes()).padStart(2, '0');

    setScheduleForm({
      contactName: contact?.name || (dialedNumber.trim() ? `কন্টাক্ট (${dialedNumber.trim()})` : ''),
      contactNumber: contact?.number || dialedNumber.trim() || '',
      date: `${year}-${month}-${day}`,
      time: `${hours}:${minutes}`,
      note: '',
    });
    setIsScheduleModalOpen(true);
  };

  // Helper presets for schedule modal
  const setPresetScheduleTime = (minutesAhead: number) => {
    const target = new Date(Date.now() + minutesAhead * 60000);
    const year = target.getFullYear();
    const month = String(target.getMonth() + 1).padStart(2, '0');
    const day = String(target.getDate()).padStart(2, '0');
    const hours = String(target.getHours()).padStart(2, '0');
    const minutes = String(target.getMinutes()).padStart(2, '0');

    setScheduleForm((prev) => ({
      ...prev,
      date: `${year}-${month}-${day}`,
      time: `${hours}:${minutes}`,
    }));
  };

  const setEveningOrMorningPreset = (isTomorrow: boolean, hour: number, minute: number = 0) => {
    const target = new Date();
    if (isTomorrow) {
      target.setDate(target.getDate() + 1);
    }
    const year = target.getFullYear();
    const month = String(target.getMonth() + 1).padStart(2, '0');
    const day = String(target.getDate()).padStart(2, '0');
    const hours = String(hour).padStart(2, '0');
    const minutes = String(minute).padStart(2, '0');

    setScheduleForm((prev) => ({
      ...prev,
      date: `${year}-${month}-${day}`,
      time: `${hours}:${minutes}`,
    }));
  };

  // Save new scheduled call
  const handleSaveSchedule = (e: React.FormEvent) => {
    e.preventDefault();
    if (!scheduleForm.contactNumber.trim()) return;

    const [year, month, day] = scheduleForm.date.split('-').map(Number);
    const [hours, minutes] = scheduleForm.time.split(':').map(Number);
    const scheduledDate = new Date(year, month - 1, day, hours, minutes);
    const timestamp = scheduledDate.getTime();

    const newSchedule: ScheduledCall = {
      id: `sc-${Date.now()}`,
      contactName: scheduleForm.contactName.trim() || `কন্টাক্ট (${scheduleForm.contactNumber.trim()})`,
      contactNumber: scheduleForm.contactNumber.trim(),
      scheduledTime: isNaN(timestamp) ? Date.now() + 3600000 : timestamp,
      note: scheduleForm.note.trim() || undefined,
      createdAt: Date.now(),
      status: 'pending',
      reminded: false,
    };

    setScheduledCalls((prev) => [newSchedule, ...prev]);
    setIsScheduleModalOpen(false);

    // Request notification permission if available
    if ('Notification' in window && Notification.permission === 'default') {
      try {
        Notification.requestPermission();
      } catch (e) {}
    }
  };

  const deleteScheduledCall = (id: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setScheduledCalls((prev) => prev.filter((item) => item.id !== id));
    if (activeReminder?.id === id) {
      setActiveReminder(null);
    }
  };

  const toggleScheduleStatus = (id: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setScheduledCalls((prev) =>
      prev.map((item) =>
        item.id === id
          ? {
              ...item,
              status: item.status === 'completed' ? 'pending' : 'completed',
              reminded: item.status === 'completed' ? false : item.reminded,
            }
          : item
      )
    );
  };

  const handleCallFromSchedule = (call: ScheduledCall) => {
    // Mark as completed
    setScheduledCalls((prev) =>
      prev.map((item) => (item.id === call.id ? { ...item, status: 'completed' } : item))
    );
    startCall(call.contactNumber, call.contactName);
  };

  const handleSnoozeReminder = (minutes: number = 10) => {
    if (!activeReminder) return;
    const newTime = Date.now() + minutes * 60000;
    setScheduledCalls((prev) =>
      prev.map((c) =>
        c.id === activeReminder.id
          ? { ...c, scheduledTime: newTime, reminded: false, status: 'pending' }
          : c
      )
    );
    setActiveReminder(null);
  };

  const handleDismissReminder = () => {
    setActiveReminder(null);
  };

  const handleCallNowFromReminder = () => {
    if (!activeReminder) return;
    const target = activeReminder;
    setActiveReminder(null);
    handleCallFromSchedule(target);
  };

  const formatScheduledDateTime = (timestamp: number) => {
    const d = new Date(timestamp);
    const now = new Date();

    const isToday = d.toDateString() === now.toDateString();
    const tomorrow = new Date(now);
    tomorrow.setDate(tomorrow.getDate() + 1);
    const isTomorrow = d.toDateString() === tomorrow.toDateString();

    let timeString = '';
    try {
      timeString = d.toLocaleTimeString('bn-BD', {
        hour: '2-digit',
        minute: '2-digit',
        hour12: true,
      });
    } catch (e) {}
    if (!timeString) {
      timeString = d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    }

    let datePrefix = '';
    if (isToday) {
      datePrefix = 'আজ';
    } else if (isTomorrow) {
      datePrefix = 'আগামীকাল';
    } else {
      try {
        datePrefix = d.toLocaleDateString('bn-BD', {
          day: 'numeric',
          month: 'short',
          year: 'numeric',
        });
      } catch (e) {
        datePrefix = d.toLocaleDateString();
      }
    }

    return `${datePrefix}, ${timeString}`;
  };

  const getRelativeScheduleBadge = (timestamp: number, status: string) => {
    if (status === 'completed') {
      return {
        text: 'সম্পন্ন',
        color: 'bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400',
      };
    }
    const diff = timestamp - Date.now();
    const diffMin = Math.round(diff / 60000);

    if (diff < -60000) {
      return {
        text: 'সময় অতিক্রান্ত',
        color: 'bg-rose-100 dark:bg-rose-950/60 text-rose-700 dark:text-rose-400 font-semibold',
      };
    }
    if (diff >= -60000 && diff <= 60000) {
      return {
        text: 'এখনই সময়!',
        color: 'bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 font-bold animate-pulse',
      };
    }
    if (diffMin < 60) {
      return {
        text: `${diffMin} মিনিট বাকি`,
        color: 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 font-semibold',
      };
    }
    const diffHours = Math.round(diffMin / 60);
    if (diffHours < 24) {
      return {
        text: `প্রায় ${diffHours} ঘণ্টা পর`,
        color: 'bg-teal-100 dark:bg-teal-950/60 text-teal-700 dark:text-teal-300 font-medium',
      };
    }
    const diffDays = Math.round(diffHours / 24);
    return {
      text: `${diffDays} দিন পর`,
      color: 'bg-blue-100 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 font-medium',
    };
  };

  // Audio References
  const ringerRef = useRef<PhoneRinger | null>(null);
  const wsRef = useRef<WebSocket | null>(null);
  const inputAudioCtxRef = useRef<AudioContext | null>(null);
  const outputAudioCtxRef = useRef<AudioContext | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const isMutedRef = useRef(false);
  const activeSourcesRef = useRef<AudioBufferSourceNode[]>([]);
  const nextStartTimeRef = useRef(0);
  const timerRef = useRef<any>(null);
  const hasReceivedLiveAudioRef = useRef(false);

  // Call Recording References & Audio Mixer
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);
  const recordingTimerRef = useRef<any>(null);
  const recordingDurationRef = useRef(0);
  const recordingDestRef = useRef<MediaStreamAudioDestinationNode | null>(null);
  const micSourceForRecRef = useRef<MediaStreamAudioSourceNode | null>(null);
  const audioPlayerRef = useRef<HTMLAudioElement | null>(null);
  const playingUrlRef = useRef<string | null>(null);

  // Sync ref with state
  useEffect(() => {
    isMutedRef.current = isMuted;
  }, [isMuted]);

  // Load recordings from IndexedDB on component mount
  useEffect(() => {
    let isMounted = true;
    getAllCallRecordings().then((items) => {
      if (isMounted) setRecordings(items);
    }).catch((err) => {
      console.warn('Failed to load call recordings from IndexedDB:', err);
    });

    return () => {
      isMounted = false;
      if (playingUrlRef.current) {
        URL.revokeObjectURL(playingUrlRef.current);
      }
      if (audioPlayerRef.current) {
        audioPlayerRef.current.pause();
      }
    };
  }, []);

  // Toast notification helper
  const showToast = (text: string, actionText?: string, onAction?: () => void) => {
    setToastMessage({ text, actionText, onAction });
    setTimeout(() => {
      setToastMessage((prev) => (prev?.text === text ? null : prev));
    }, 5000);
  };

  // Start recording active call audio
  const startCallRecording = () => {
    if (isRecording || !inCall) return;

    try {
      if (!outputAudioCtxRef.current || outputAudioCtxRef.current.state === 'closed') {
        setupAudioPlayback();
      }
      const ctx = outputAudioCtxRef.current;
      if (!ctx) return;

      if (!recordingDestRef.current) {
        recordingDestRef.current = ctx.createMediaStreamDestination();
      }

      // Mix microphone input into recording destination if available
      if (mediaStreamRef.current && !micSourceForRecRef.current) {
        try {
          const micSource = ctx.createMediaStreamSource(mediaStreamRef.current);
          micSource.connect(recordingDestRef.current);
          micSourceForRecRef.current = micSource;
        } catch (e) {
          console.warn('Microphone node could not connect to recording destination:', e);
        }
      }

      const streamToRecord = recordingDestRef.current.stream;
      recordedChunksRef.current = [];

      const options: MediaRecorderOptions = {};
      if (typeof MediaRecorder !== 'undefined') {
        if (MediaRecorder.isTypeSupported('audio/webm;codecs=opus')) {
          options.mimeType = 'audio/webm;codecs=opus';
        } else if (MediaRecorder.isTypeSupported('audio/webm')) {
          options.mimeType = 'audio/webm';
        } else if (MediaRecorder.isTypeSupported('audio/mp4')) {
          options.mimeType = 'audio/mp4';
        }
      }

      const mr = new MediaRecorder(streamToRecord, options);
      mr.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) {
          recordedChunksRef.current.push(e.data);
        }
      };

      mr.onstop = async () => {
        const mime = mr.mimeType || 'audio/webm';
        const blob = new Blob(recordedChunksRef.current, { type: mime });
        if (blob.size > 0) {
          const recItem: CallRecordingItem = {
            id: `rec_${Date.now()}`,
            contactName: activeContact.name || 'কল রেকর্ডিং',
            contactNumber: activeContact.number || dialedNumber || 'হটলাইন',
            timestamp: Date.now(),
            durationSeconds: recordingDurationRef.current,
            audioBlob: blob,
            sizeBytes: blob.size,
            mimeType: mime,
            avatar: customAvatars[activeContact.number],
          };

          try {
            await saveCallRecording(recItem);
            const updated = await getAllCallRecordings();
            setRecordings(updated);
            showToast('✓ কল রেকর্ডিং সফলভাবে ব্রাউজারে সংরক্ষিত হয়েছে!', 'রেকর্ডিং শুনুন', () => {
              setActiveTab('recordings');
            });
          } catch (saveErr) {
            console.error('Failed to save recording to IndexedDB:', saveErr);
            showToast('⚠️ রেকর্ডিং ব্রাউজারে সংরক্ষণ করতে সমস্যা হয়েছে');
          }
        }
      };

      mr.start(250);
      mediaRecorderRef.current = mr;
      setIsRecording(true);
      setRecordingDuration(0);
      recordingDurationRef.current = 0;

      if (recordingTimerRef.current) clearInterval(recordingTimerRef.current);
      recordingTimerRef.current = setInterval(() => {
        setRecordingDuration((prev) => {
          const next = prev + 1;
          recordingDurationRef.current = next;
          return next;
        });
      }, 1000);
    } catch (err) {
      console.error('Failed to start call recording:', err);
      showToast('⚠️ এই ডিভাইসে কল রেকর্ডিং শুরু করা যায়নি');
    }
  };

  // Stop recording active call audio
  const stopCallRecording = () => {
    if (recordingTimerRef.current) {
      clearInterval(recordingTimerRef.current);
      recordingTimerRef.current = null;
    }
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      try {
        mediaRecorderRef.current.stop();
      } catch (e) {
        console.warn('Error stopping media recorder:', e);
      }
    }
    setIsRecording(false);
  };

  // Toggle audio playback for a saved recording
  const handleTogglePlayRecording = (recording: CallRecordingItem) => {
    if (playingRecordingId === recording.id) {
      if (audioPlayerRef.current) {
        if (audioPlayerRef.current.paused) {
          audioPlayerRef.current.play();
        } else {
          audioPlayerRef.current.pause();
          setPlayingRecordingId(null);
        }
      }
      return;
    }

    if (audioPlayerRef.current) {
      audioPlayerRef.current.pause();
    }
    if (playingUrlRef.current) {
      URL.revokeObjectURL(playingUrlRef.current);
    }

    const url = URL.createObjectURL(recording.audioBlob);
    playingUrlRef.current = url;
    const audio = new Audio(url);
    audioPlayerRef.current = audio;
    setPlayingRecordingId(recording.id);
    setPlaybackProgress(0);
    setPlaybackCurrentTime(0);

    audio.ontimeupdate = () => {
      if (audio.duration) {
        setPlaybackProgress(audio.currentTime / audio.duration);
        setPlaybackCurrentTime(Math.floor(audio.currentTime));
      }
    };

    audio.onended = () => {
      setPlayingRecordingId(null);
      setPlaybackProgress(0);
      setPlaybackCurrentTime(0);
    };

    audio.onerror = (e) => {
      console.warn('Audio playback error:', e);
      setPlayingRecordingId(null);
      showToast('⚠️ অডিও ফাইলটি চালাতে সমস্যা হয়েছে');
    };

    audio.play().catch((err) => {
      console.warn('Autoplay error:', err);
      setPlayingRecordingId(null);
    });
  };

  const handleSeekRecording = (percent: number) => {
    if (audioPlayerRef.current && audioPlayerRef.current.duration) {
      audioPlayerRef.current.currentTime = percent * audioPlayerRef.current.duration;
    }
  };

  const handleDeleteRecording = async (id: string, e?: React.MouseEvent) => {
    e?.stopPropagation();
    if (window.confirm('আপনি কি এই অডিও রেকর্ডিংটি ব্রাউজার থেকে মুছে ফেলতে চান?')) {
      if (playingRecordingId === id && audioPlayerRef.current) {
        audioPlayerRef.current.pause();
        setPlayingRecordingId(null);
      }
      await deleteCallRecording(id);
      const updated = await getAllCallRecordings();
      setRecordings(updated);
    }
  };

  const handleClearAllRecordings = async () => {
    if (window.confirm('আপনি কি ব্রাউজার থেকে সমস্ত কল রেকর্ডিং মুছে ফেলতে চান? এটি পুনরায় ফিরিয়ে আনা যাবে না।')) {
      if (audioPlayerRef.current) {
        audioPlayerRef.current.pause();
        setPlayingRecordingId(null);
      }
      await clearAllCallRecordings();
      setRecordings([]);
    }
  };

  // Save history to localStorage
  useEffect(() => {
    localStorage.setItem('desh_call_history', JSON.stringify(history));
  }, [history]);

  // Clear all call history from state and localStorage
  const clearAllHistory = () => {
    if (window.confirm('আপনি কি সমস্ত কল হিস্ট্রি মুছে ফেলতে চান? (Clear All Call History?)')) {
      setHistory([]);
      localStorage.removeItem('desh_call_history');
    }
  };

  // Delete individual call history item
  const deleteHistoryItem = (id: string, e?: React.MouseEvent) => {
    e?.stopPropagation();
    setHistory((prev) => prev.filter((item) => item.id !== id));
  };

  // Clean up on unmount
  useEffect(() => {
    return () => {
      endCallCleanup();
      if (playingUrlRef.current) {
        URL.revokeObjectURL(playingUrlRef.current);
      }
      if (audioPlayerRef.current) {
        audioPlayerRef.current.pause();
      }
    };
  }, []);

  const handleKeyPress = (digit: string) => {
    playDtmfTone(digit);
    if (!inCall) {
      setDialedNumber((prev) => (prev.length < 15 ? prev + digit : prev));
    } else {
      // In-call DTMF
      if (wsRef.current?.readyState === WebSocket.OPEN) {
        wsRef.current.send(JSON.stringify({ action: 'dtmf', digit }));
      }
    }
  };

  const handleBackspace = () => {
    setDialedNumber((prev) => prev.slice(0, -1));
  };

  const handleClearAll = () => {
    setDialedNumber('');
  };

  const startCall = (numberToCall?: string, contactName?: string) => {
    const targetNumber = (numberToCall || dialedNumber).trim();
    if (!targetNumber) return;

    // Identify Contact Name
    const matchedSaved = contacts.find((c) => c.number === targetNumber);
    const matched = HOTLINES.find((h) => h.number === targetNumber);
    const resolvedName =
      contactName ||
      matchedSaved?.name ||
      matched?.name ||
      (targetNumber.startsWith('1612') ? 'দেশ AI বিশেষ হেল্পলাইন' : `নম্বর: ${targetNumber}`);

    setActiveContact({ number: targetNumber, name: resolvedName });
    setInCall(true);
    setCallStatus('connecting');
    setCallDuration(0);
    setTranscript([`টেলিফোন ডায়াল করা হচ্ছে: ${resolvedName} (${targetNumber})...`]);
    setIsMuted(false);
    setShowInCallKeypad(false);

    // Initialize Ringer
    if (!ringerRef.current) {
      ringerRef.current = new PhoneRinger();
    }
    ringerRef.current.start();
    setCallStatus('ringing');

    // Connect WebSocket to /live-call
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/live-call`;

    try {
      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;

      ws.onopen = () => {
        // Resolve immediate greeting text for this call
        const resolvedGreeting =
          matched?.voicePrompt ||
          (matchedSaved
            ? `আসসালামু আলাইকুম ${matchedSaved.name}! আমি দেশ AI। বলুন আপনাকে কীভাবে সাহায্য করতে পারি?`
            : undefined);

        // Send Dial initiation
        ws.send(
          JSON.stringify({
            action: 'dial',
            number: targetNumber,
            name: resolvedName,
            hotlineCategory: matched?.category || 'ai',
            greetingPrompt: resolvedGreeting,
          })
        );
      };

      ws.onmessage = async (event) => {
        try {
          const msg = JSON.parse(event.data);

          // 1. Connected
          if (msg.type === 'connected') {
            ringerRef.current?.stop();
            setCallStatus('connected');
            startTimer();
            setupMicrophoneCapture(ws);
            setupAudioPlayback();

            const greeting =
              msg.greetingText ||
              matched?.voicePrompt ||
              'আসসালামু আলাইকুম! দেশ AI মূল কল সেন্টারে আপনাকে স্বাগতম। বলুন আপনাকে কীভাবে সাহায্য করতে পারি?';

            setTranscript((prev) => [
              ...prev,
              '✓ সংযোগ স্থাপিত হয়েছে। AI অপারেটর আগে কথা বলছেন...',
              `দেশ AI: ${greeting}`,
            ]);
            setAiSpeaking(true);

            // Proactive Answer: If live audio chunk from Gemini Live hasn't started playing within 1300ms, immediately play greeting
            hasReceivedLiveAudioRef.current = false;
            setTimeout(() => {
              if (!hasReceivedLiveAudioRef.current && wsRef.current?.readyState === WebSocket.OPEN) {
                playGreeting(greeting, true);
              }
            }, 1300);
          }

          // 2. Audio playback from Gemini Live (24kHz PCM)
          else if (msg.type === 'audio' && msg.audio) {
            hasReceivedLiveAudioRef.current = true;
            setAiSpeaking(true);
            playLivePCMChunk(msg.audio);
          }

          // 3. TTS Audio from server (fallback or greeting)
          else if (msg.type === 'tts_audio' && msg.audio) {
            hasReceivedLiveAudioRef.current = true;
            setAiSpeaking(true);
            if (msg.text) {
              setTranscript((prev) => {
                const last = prev[prev.length - 1];
                if (last && last.startsWith('দেশ AI:')) return prev;
                return [...prev, `দেশ AI: ${msg.text}`];
              });
            }
            playBase64AudioFile(msg.audio);
          }

          // 4. Transcript
          else if (msg.type === 'transcript' && msg.text) {
            setTranscript((prev) => {
              const last = prev[prev.length - 1];
              if (last && last.startsWith('দেশ AI:')) {
                const updated = [...prev];
                updated[updated.length - 1] = `দেশ AI: ${msg.text}`;
                return updated;
              }
              return [...prev, `দেশ AI: ${msg.text}`];
            });
          }

          // 5. Interrupted
          else if (msg.type === 'interrupted') {
            stopQueuedAudio();
            setAiSpeaking(false);
          }

          // 6. Call Ended
          else if (msg.type === 'call_ended') {
            hangupCall();
          }

          // 7. Fallback ready
          else if (msg.type === 'fallback_ready') {
            ringerRef.current?.stop();
            setCallStatus('connected');
            const greeting =
              msg.greetingText ||
              matched?.voicePrompt ||
              'আসসালামু আলাইকুম! দেশ AI কল সেন্টারে আপনাকে স্বাগতম। আপনি কী জানতে চান?';
            setTranscript((prev) => [
              ...prev,
              '✓ স্মার্ট কল সেন্টারে যুক্ত আছেন। AI অপারেটর কথা বলছেন...',
              `দেশ AI: ${greeting}`,
            ]);
            startTimer();
            setupAudioPlayback();
            // Greet user with speech right away
            playGreeting(greeting, true);
          }
        } catch (err) {
          console.error('WS message handling error:', err);
        }
      };

      ws.onerror = (err) => {
        console.warn('WebSocket error, switching to fallback voice call:', err);
        ringerRef.current?.stop();
        setCallStatus('connected');
        startTimer();
        setupAudioPlayback();
        playGreeting(matched?.voicePrompt || 'আসসালামু আলাইকুম! দেশ এআই কল সেন্টারে আপনাকে স্বাগতম।');
      };

      ws.onclose = () => {
        // ws closed
      };
    } catch (e) {
      console.error('Failed to instantiate WebSocket:', e);
      ringerRef.current?.stop();
      setCallStatus('connected');
      startTimer();
      playGreeting(matched?.voicePrompt || 'আসসালামু আলাইকুম! দেশ AI কল সেন্টারে স্বাগতম।');
    }
  };

  const setupMicrophoneCapture = async (ws: WebSocket) => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaStreamRef.current = stream;

      // Also connect mic stream to recording destination if active
      if (outputAudioCtxRef.current && recordingDestRef.current && !micSourceForRecRef.current) {
        try {
          const micSource = outputAudioCtxRef.current.createMediaStreamSource(stream);
          micSource.connect(recordingDestRef.current);
          micSourceForRecRef.current = micSource;
        } catch (e) {}
      }

      const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
      const inputCtx = new AudioCtxClass({ sampleRate: 16000 });
      inputAudioCtxRef.current = inputCtx;

      const source = inputCtx.createMediaStreamSource(stream);
      // ScriptProcessor for 16kHz PCM streaming
      const processor = inputCtx.createScriptProcessor(4096, 1, 1);
      processorRef.current = processor;

      processor.onaudioprocess = (e) => {
        if (isMutedRef.current || ws.readyState !== WebSocket.OPEN) return;
        const inputData = e.inputBuffer.getChannelData(0);

        // Calculate visualizer wave
        let sum = 0;
        for (let i = 0; i < inputData.length; i += 16) {
          sum += Math.abs(inputData[i]);
        }
        setMicWaveActivity(Math.min(1, (sum / (inputData.length / 16)) * 4));

        const pcm16 = floatTo16BitPCM(inputData);
        const base64 = arrayBufferToBase64(pcm16);
        ws.send(JSON.stringify({ action: 'audio', audio: base64 }));
      };

      source.connect(processor);
      processor.connect(inputCtx.destination);
    } catch (err) {
      console.warn('Microphone permission not granted or unsupported:', err);
      setTranscript((prev) => [
        ...prev,
        '⚠️ মাইক্রোফোনে এক্সেস পাওয়া যায়নি। আপনি নিচের ইনপুট বক্সে লিখেও সরাসরি কল করতে পারেন।',
      ]);
    }
  };

  const setupAudioPlayback = () => {
    if (!outputAudioCtxRef.current || outputAudioCtxRef.current.state === 'closed') {
      const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
      outputAudioCtxRef.current = new AudioCtxClass({ sampleRate: 24000 });
      nextStartTimeRef.current = outputAudioCtxRef.current.currentTime;
    }
    if (outputAudioCtxRef.current.state === 'suspended') {
      outputAudioCtxRef.current.resume();
    }
    if (!recordingDestRef.current && outputAudioCtxRef.current) {
      try {
        recordingDestRef.current = outputAudioCtxRef.current.createMediaStreamDestination();
      } catch (e) {}
    }
  };

  const playLivePCMChunk = (base64PCM: string) => {
    if (!outputAudioCtxRef.current) setupAudioPlayback();
    const ctx = outputAudioCtxRef.current;
    if (!ctx) return;

    try {
      const arrayBuffer = base64ToArrayBuffer(base64PCM);
      const int16Array = new Int16Array(arrayBuffer);
      const float32Array = new Float32Array(int16Array.length);

      for (let i = 0; i < int16Array.length; i++) {
        float32Array[i] = int16Array[i] / 32768.0;
      }

      const audioBuffer = ctx.createBuffer(1, float32Array.length, 24000);
      audioBuffer.copyToChannel(float32Array, 0);

      const source = ctx.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(ctx.destination);

      if (recordingDestRef.current) {
        try {
          source.connect(recordingDestRef.current);
        } catch (e) {}
      }

      const currentTime = ctx.currentTime;
      const startTime = Math.max(currentTime, nextStartTimeRef.current);
      source.start(startTime);
      nextStartTimeRef.current = startTime + audioBuffer.duration;
      activeSourcesRef.current.push(source);

      source.onended = () => {
        activeSourcesRef.current = activeSourcesRef.current.filter((s) => s !== source);
        if (activeSourcesRef.current.length === 0) {
          setAiSpeaking(false);
        }
      };
    } catch (e) {
      console.error('Error playing live PCM chunk:', e);
    }
  };

  const stopQueuedAudio = () => {
    activeSourcesRef.current.forEach((src) => {
      try {
        src.stop();
      } catch (e) {}
    });
    activeSourcesRef.current = [];
    if (outputAudioCtxRef.current) {
      nextStartTimeRef.current = outputAudioCtxRef.current.currentTime;
    }
  };

  const playBase64AudioFile = (base64Audio: string) => {
    try {
      const audioUrl = base64Audio.startsWith('data:') ? base64Audio : `data:audio/wav;base64,${base64Audio}`;
      const audio = new Audio(audioUrl);
      if (outputAudioCtxRef.current && recordingDestRef.current) {
        try {
          const src = outputAudioCtxRef.current.createMediaElementSource(audio);
          src.connect(outputAudioCtxRef.current.destination);
          src.connect(recordingDestRef.current);
        } catch (e) {}
      }
      setAiSpeaking(true);
      audio.onended = () => setAiSpeaking(false);
      audio.play().catch((e) => console.warn('Audio play error:', e));
    } catch (e) {
      console.error('Error playing base64 audio:', e);
    }
  };

  const playGreeting = async (text: string, skipTranscript: boolean = false) => {
    if (!text) return;
    setAiSpeaking(true);
    if (!skipTranscript) {
      setTranscript((prev) => [...prev, `দেশ AI: ${text}`]);
    }
    try {
      const res = await fetch('/api/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text }),
      });
      if (res.ok) {
        const data = await res.json();
        if (data.audio) {
          playBase64AudioFile(data.audio);
          return;
        }
      }
    } catch (e) {
      // fallback to speech synthesis
    }
    if ('speechSynthesis' in window) {
      const u = new SpeechSynthesisUtterance(text);
      u.lang = 'bn-BD';
      u.onend = () => setAiSpeaking(false);
      window.speechSynthesis.speak(u);
    }
  };

  const startTimer = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = setInterval(() => {
      setCallDuration((prev) => prev + 1);
    }, 1000);
  };

  const hangupCall = () => {
    // Record to history and sync immediately to localStorage
    if (callDuration > 0 || activeContact.number) {
      const record: CallHistoryItem = {
        id: `call_${Date.now()}`,
        number: activeContact.number || dialedNumber,
        name: activeContact.name || 'অজ্ঞাত কল',
        timestamp: Date.now(),
        durationSeconds: callDuration,
        type: 'outgoing',
      };
      setHistory((prev) => {
        const updated = [record, ...prev];
        try {
          localStorage.setItem('desh_call_history', JSON.stringify(updated));
        } catch (e) {}
        return updated;
      });
    }

    endCallCleanup();
    setCallStatus('ended');
    setTimeout(() => {
      setInCall(false);
    }, 1200);
  };

  const endCallCleanup = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      stopCallRecording();
    }
    if (micSourceForRecRef.current) {
      try {
        micSourceForRecRef.current.disconnect();
      } catch (e) {}
      micSourceForRecRef.current = null;
    }
    ringerRef.current?.stop();
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
    if (wsRef.current) {
      if (wsRef.current.readyState === WebSocket.OPEN) {
        wsRef.current.send(JSON.stringify({ action: 'hangup' }));
      }
      wsRef.current.close();
      wsRef.current = null;
    }
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((track) => track.stop());
      mediaStreamRef.current = null;
    }
    if (processorRef.current) {
      processorRef.current.disconnect();
      processorRef.current = null;
    }
    if (inputAudioCtxRef.current && inputAudioCtxRef.current.state !== 'closed') {
      inputAudioCtxRef.current.close();
      inputAudioCtxRef.current = null;
    }
    stopQueuedAudio();
    setAiSpeaking(false);
    setMicWaveActivity(0);
  };

  const handleSendInCallText = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inCallTextInput.trim()) return;
    const text = inCallTextInput.trim();
    setTranscript((prev) => [...prev, `আপনি: ${text}`]);
    setInCallTextInput('');

    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ action: 'user_text', text }));
    } else {
      // Direct call fallback via /api/chat
      fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: text }),
      })
        .then((r) => r.json())
        .then((data) => {
          if (data.reply) {
            playGreeting(data.reply);
          }
        });
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="max-w-4xl mx-auto px-3 sm:px-6 py-4 sm:py-6">
      {/* Top Banner Header */}
      <div className="mb-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-gradient-to-r from-emerald-900 via-teal-900 to-slate-900 p-5 sm:p-6 rounded-3xl text-white shadow-lg">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping"></span>
            <span className="text-xs uppercase font-extrabold tracking-wider text-emerald-300">
              রিয়েল-টাইম লাইভ এআই কল সিস্টেম
            </span>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">
              gemini-3.8-live
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black tracking-tight">
            দেশ ডায়াল প্যাড ও টেলিফোন সেবা
          </h1>
          <p className="text-emerald-100 text-xs sm:text-sm mt-1 max-w-xl">
            সরাসরি বোতাম টিপে ডায়াল করুন অথবা হটলাইনে কল করে যেকোনো সরকারি তথ্য, বিসিএস প্রস্তুতি, কৃষি বা চিকিৎসায় লাইভ কথা বলুন।
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 self-stretch sm:self-auto justify-end">
          {onNavigateToIpPhone && (
            <button
              onClick={onNavigateToIpPhone}
              className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-600 hover:to-emerald-600 text-white text-xs font-bold flex items-center gap-1.5 shadow-md shadow-emerald-950/40 transition-all hover:scale-105 active:scale-95"
            >
              <Radio size={14} className="text-white animate-pulse" />
              <span>আইপি ফোন (IP Phone)</span>
            </button>
          )}
          <div className="px-3 py-1.5 rounded-xl bg-white/10 backdrop-blur-xs border border-white/10 text-xs font-semibold flex items-center gap-2">
            <Radio size={14} className="text-emerald-400 animate-pulse" />
            <span>ভয়েস চ্যানেল প্রস্তুত</span>
          </div>
        </div>
      </div>

      {/* Main Calling Card */}
      {!inCall ? (
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xl overflow-hidden max-w-md mx-auto">
          {/* Sub Navigation: Keypad, Contacts, Hotlines, History, Schedule */}
          <div className="flex border-b border-slate-100 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-950/40 p-1.5 gap-1 text-[11px] sm:text-xs font-bold overflow-x-auto no-scrollbar">
            <button
              onClick={() => setActiveTab('keypad')}
              className={`flex-1 min-w-[62px] py-2 px-1 rounded-xl flex items-center justify-center gap-1 transition-all ${
                activeTab === 'keypad'
                  ? 'bg-white dark:bg-slate-800 text-emerald-700 dark:text-emerald-300 shadow-xs'
                  : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Grid size={14} />
              <span className="truncate">ডায়াল</span>
            </button>
            <button
              onClick={() => setActiveTab('contacts')}
              className={`flex-1 min-w-[66px] py-2 px-1 rounded-xl flex items-center justify-center gap-1 transition-all ${
                activeTab === 'contacts'
                  ? 'bg-white dark:bg-slate-800 text-emerald-700 dark:text-emerald-300 shadow-xs'
                  : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <BookUser size={14} />
              <span className="truncate">কন্টাক্টস</span>
              {contacts.length > 0 && (
                <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 font-bold">
                  {contacts.length}
                </span>
              )}
            </button>
            <button
              onClick={() => setActiveTab('recordings')}
              className={`flex-1 min-w-[66px] py-2 px-1 rounded-xl flex items-center justify-center gap-1 transition-all ${
                activeTab === 'recordings'
                  ? 'bg-white dark:bg-slate-800 text-emerald-700 dark:text-emerald-300 shadow-xs'
                  : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Disc size={14} className={recordings.length > 0 ? 'text-rose-500' : ''} />
              <span className="truncate">রেকর্ডস</span>
              {recordings.length > 0 && (
                <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-rose-100 dark:bg-rose-950/80 text-rose-700 dark:text-rose-300 font-bold">
                  {recordings.length}
                </span>
              )}
            </button>
            <button
              onClick={() => setActiveTab('hotlines')}
              className={`flex-1 min-w-[62px] py-2 px-1 rounded-xl flex items-center justify-center gap-1 transition-all ${
                activeTab === 'hotlines'
                  ? 'bg-white dark:bg-slate-800 text-emerald-700 dark:text-emerald-300 shadow-xs'
                  : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Bookmark size={14} />
              <span className="truncate">হটলাইন</span>
            </button>
            <button
              onClick={() => setActiveTab('history')}
              className={`flex-1 min-w-[62px] py-2 px-1 rounded-xl flex items-center justify-center gap-1 transition-all ${
                activeTab === 'history'
                  ? 'bg-white dark:bg-slate-800 text-emerald-700 dark:text-emerald-300 shadow-xs'
                  : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <History size={14} />
              <span className="truncate">হিস্ট্রি</span>
              {history.length > 0 && (
                <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 font-bold">
                  {history.length}
                </span>
              )}
            </button>
          </div>

          {/* TAB 1: KEYPAD */}
          {activeTab === 'keypad' && (
            <div className="p-6 space-y-6">
              {/* Display Screen */}
              <div className="relative bg-slate-50 dark:bg-slate-950 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 min-h-[82px] flex flex-col justify-center">
                <div className="flex items-center justify-between">
                  <div className="flex-1 overflow-x-auto text-center font-mono font-bold text-2xl sm:text-3xl tracking-widest text-slate-900 dark:text-white px-2 no-scrollbar">
                    {dialedNumber || (
                      <span className="text-slate-300 dark:text-slate-600 font-sans text-base sm:text-lg font-normal">
                        নম্বর তুলুন বা কন্টাক্ট খুঁজুন...
                      </span>
                    )}
                  </div>
                  {dialedNumber && (
                    <button
                      onClick={handleBackspace}
                      onDoubleClick={handleClearAll}
                      title="মুছে ফেলুন (ডাবল ক্লিকে সব মুছবে)"
                      className="p-2 rounded-xl text-slate-400 hover:text-rose-500 hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors"
                    >
                      <Delete size={20} />
                    </button>
                  )}
                </div>

                {/* Real-time Matched Contact Name or Save Shortcut */}
                {dialedNumber && (
                  <div className="text-center mt-1">
                    {(() => {
                      const matchedSaved = contacts.find((c) => c.number === dialedNumber.trim());
                      const matchedHotline = HOTLINES.find((h) => h.number === dialedNumber.trim());
                      const matched = matchedSaved || matchedHotline;

                      if (matched) {
                        return (
                          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 text-[11px] font-bold text-emerald-700 dark:text-emerald-300">
                            <User size={11} />
                            <span>{matched.name}</span>
                            {'category' in matched && matched.category && (
                              <span className="opacity-75 font-normal">({matched.category})</span>
                            )}
                          </div>
                        );
                      }
                      return (
                        <button
                          type="button"
                          onClick={() => openAddContactModal(dialedNumber.trim())}
                          className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-950/50 dark:hover:bg-emerald-900/60 border border-emerald-200 dark:border-emerald-800 text-[11px] font-bold text-emerald-700 dark:text-emerald-300 transition-colors"
                        >
                          <UserPlus size={11} />
                          <span>+ এই নম্বরে কন্টাক্ট সেভ করুন</span>
                        </button>
                      );
                    })()}
                  </div>
                )}
              </div>

              {/* Speed Dial Chips */}
              <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-1">
                {HOTLINES.slice(0, 4).map((h) => (
                  <button
                    key={h.number}
                    onClick={() => {
                      setDialedNumber(h.number);
                      playDtmfTone('1');
                    }}
                    className="whitespace-nowrap px-2.5 py-1 rounded-lg text-[11px] font-bold bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 hover:bg-emerald-100"
                  >
                    {h.number} ({h.name.split(' ')[0]})
                  </button>
                ))}
              </div>

              {/* 3x4 Dial Pad Keypad */}
              <div className="grid grid-cols-3 gap-3.5 max-w-xs mx-auto">
                {KEYPAD_BUTTONS.map((btn) => (
                  <button
                    key={btn.digit}
                    onClick={() => handleKeyPress(btn.digit)}
                    className="h-16 rounded-2xl bg-slate-100 hover:bg-emerald-50 dark:bg-slate-800/80 dark:hover:bg-emerald-950/50 border border-slate-200 dark:border-slate-700/80 active:scale-95 transition-all flex flex-col items-center justify-center group shadow-xs"
                  >
                    <span className="text-2xl font-black text-slate-800 dark:text-slate-100 group-hover:text-emerald-600 dark:group-hover:text-emerald-400">
                      {btn.digit}
                    </span>
                    <span className="text-[10px] font-semibold text-slate-400 group-hover:text-emerald-600/80 dark:group-hover:text-emerald-400/80 uppercase">
                      {btn.sub}
                    </span>
                  </button>
                ))}
              </div>

              {/* Big Call Button & Additional Actions */}
              <div className="flex flex-col items-center justify-center gap-2 pt-2">
                <button
                  onClick={() => startCall()}
                  disabled={!dialedNumber.trim()}
                  className={`w-full max-w-xs py-4 rounded-2xl font-black text-base flex items-center justify-center gap-2.5 shadow-xl transition-all ${
                    dialedNumber.trim()
                      ? 'bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white shadow-emerald-700/30'
                      : 'bg-slate-200 dark:bg-slate-800 text-slate-400 cursor-not-allowed'
                  }`}
                >
                  <PhoneCall size={20} className="animate-pulse" />
                  <span>কল করুন (Call)</span>
                </button>

                {dialedNumber.trim() && (
                  <div className="flex items-center gap-2 w-full max-w-xs">
                    {!contacts.some((c) => c.number === dialedNumber.trim()) ? (
                      <button
                        type="button"
                        onClick={() => openAddContactModal(dialedNumber.trim())}
                        className="flex-1 py-2 rounded-xl border border-emerald-500/30 bg-emerald-50/60 dark:bg-emerald-950/40 hover:bg-emerald-100 dark:hover:bg-emerald-900/60 text-emerald-700 dark:text-emerald-300 font-bold text-xs flex items-center justify-center gap-1.5 transition-all shadow-xs"
                      >
                        <UserPlus size={14} />
                        <span>কন্টাক্ট সেভ</span>
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={() => {
                          const found = contacts.find((c) => c.number === dialedNumber.trim());
                          if (found) openEditContactModal(found);
                        }}
                        className="flex-1 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 text-slate-700 dark:text-slate-200 font-bold text-xs flex items-center justify-center gap-1.5 transition-all shadow-xs"
                      >
                        <Edit3 size={13} />
                        <span>কন্টাক্ট এডিট</span>
                      </button>
                    )}

                    <button
                      type="button"
                      onClick={() => openScheduleModal({ name: '', number: dialedNumber.trim() })}
                      className="flex-1 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 text-slate-700 dark:text-slate-200 font-bold text-xs flex items-center justify-center gap-1.5 transition-all shadow-xs"
                    >
                      <CalendarClock size={14} />
                      <span>শিডিউল</span>
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 2: CONTACTS & PHONEBOOK */}
          {activeTab === 'contacts' && (
            <div className="p-4 sm:p-5 space-y-3.5 max-h-[520px] overflow-y-auto">
              {/* Header with Add Contact Button */}
              <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
                <div>
                  <h3 className="font-extrabold text-sm sm:text-base text-slate-900 dark:text-white flex items-center gap-1.5">
                    <BookUser size={17} className="text-emerald-600 dark:text-emerald-400" />
                    <span>কন্টাক্ট বুক (Contacts)</span>
                  </h3>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    নাম ও নম্বর দিয়ে সেভ করা পরিচিতিদের তালিকা
                  </p>
                </div>

                <button
                  onClick={() => openAddContactModal()}
                  className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white text-xs font-bold transition-all shadow-xs flex items-center gap-1.5"
                >
                  <UserPlus size={14} />
                  <span>নতুন কন্টাক্ট</span>
                </button>
              </div>

              {/* Search Bar for Contacts */}
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  <Search size={15} />
                </div>
                <input
                  type="text"
                  value={contactSearchQuery}
                  onChange={(e) => setContactSearchQuery(e.target.value)}
                  placeholder="কন্টাক্ট খুঁজুন (নাম, নম্বর বা নোট)..."
                  className="w-full pl-9 pr-8 py-2 rounded-xl bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-emerald-500/30 focus:border-emerald-500 transition-all"
                />
                {contactSearchQuery && (
                  <button
                    onClick={() => setContactSearchQuery('')}
                    title="ক্লিয়ার করুন"
                    className="absolute inset-y-0 right-0 pr-2.5 flex items-center text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                  >
                    <X size={14} />
                  </button>
                )}
              </div>

              {/* Category Filter Chips */}
              <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5">
                {CONTACT_CATEGORIES.map((cat) => (
                  <button
                    key={cat.id}
                    onClick={() => setContactCategoryFilter(cat.id)}
                    className={`whitespace-nowrap px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all ${
                      contactCategoryFilter === cat.id
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : 'bg-slate-100 dark:bg-slate-800/80 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                    }`}
                  >
                    {cat.label}
                  </button>
                ))}
              </div>

              {/* Contact List */}
              {contacts.length === 0 ? (
                <div className="py-12 px-4 text-center text-slate-400 space-y-3">
                  <BookUser size={36} className="mx-auto text-slate-300 dark:text-slate-700" />
                  <p className="text-xs text-slate-500">
                    এখনও কোনো কন্টাক্ট যোগ করা হয়নি।
                  </p>
                  <button
                    onClick={() => openAddContactModal()}
                    className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-all shadow-xs inline-flex items-center gap-1.5"
                  >
                    <UserPlus size={14} />
                    <span>প্রথম কন্টাক্ট সেভ করুন</span>
                  </button>
                </div>
              ) : filteredContacts.length === 0 ? (
                <div className="py-8 px-4 text-center text-slate-400 space-y-2">
                  <Search size={28} className="mx-auto text-slate-300 dark:text-slate-700" />
                  <p className="text-xs text-slate-500">
                    কোনো কন্টাক্ট খুঁজে পাওয়া যায়নি।
                  </p>
                  <button
                    onClick={() => {
                      setContactSearchQuery('');
                      setContactCategoryFilter('সব');
                    }}
                    className="text-xs text-emerald-600 dark:text-emerald-400 font-semibold hover:underline"
                  >
                    ফিল্টার রিসেট করুন
                  </button>
                </div>
              ) : (
                <div className="space-y-2">
                  {filteredContacts.map((contact) => {
                    const categoryObj = CONTACT_CATEGORIES.find((c) => c.id === contact.category);
                    const badgeClass =
                      categoryObj?.badgeClass ||
                      'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 border-slate-200 dark:border-slate-700';

                    return (
                      <div
                        key={contact.id}
                        className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/70 hover:border-emerald-500/60 transition-all flex items-center justify-between group"
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          {renderContactAvatar(contact.number, contact.name, 'w-11 h-11 text-base')}
                          <div className="min-w-0">
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-sm text-slate-900 dark:text-white truncate">
                                {contact.name}
                              </span>
                              {contact.category && (
                                <span
                                  className={`text-[10px] px-2 py-0.2 rounded-full border font-semibold shrink-0 ${badgeClass}`}
                                >
                                  {contact.category}
                                </span>
                              )}
                            </div>
                            <div className="flex items-center gap-2 text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                              <span className="font-mono font-semibold text-slate-700 dark:text-slate-300">
                                {contact.number}
                              </span>
                              {contact.note && (
                                <>
                                  <span>•</span>
                                  <span className="truncate max-w-[120px] sm:max-w-[180px]">
                                    {contact.note}
                                  </span>
                                </>
                              )}
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-1 shrink-0">
                          <button
                            type="button"
                            onClick={() => openEditContactModal(contact)}
                            title="কন্টাক্ট এডিট করুন"
                            className="p-1.5 rounded-xl text-slate-400 hover:text-emerald-600 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
                          >
                            <Edit3 size={14} />
                          </button>
                          <button
                            type="button"
                            onClick={() =>
                              openScheduleModal({ name: contact.name, number: contact.number })
                            }
                            title="এই কন্টাক্টে শিডিউল কল সেট করুন"
                            className="p-1.5 rounded-xl text-slate-400 hover:text-emerald-600 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
                          >
                            <CalendarClock size={14} />
                          </button>
                          <button
                            type="button"
                            onClick={() => startCall(contact.number, contact.name)}
                            title="সরাসরি কল করুন"
                            className="p-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white transition-all shadow-xs flex items-center justify-center active:scale-95"
                          >
                            <Phone size={14} />
                          </button>
                          <button
                            type="button"
                            onClick={(e) => handleDeleteContact(contact.id, e)}
                            title="কন্টাক্ট মুছে ফেলুন"
                            className="p-1.5 rounded-xl text-slate-400 hover:text-rose-500 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
                          >
                            <Trash2 size={14} />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* TAB 2: SPEED DIAL (HOTLINES) */}
          {activeTab === 'hotlines' && (
            <div className="p-4 sm:p-5 space-y-3 max-h-[480px] overflow-y-auto">
              {/* Header */}
              <div className="flex items-center justify-between pb-1">
                <div>
                  <h3 className="font-extrabold text-sm sm:text-base text-slate-900 dark:text-white flex items-center gap-1.5">
                    <Bookmark size={16} className="text-emerald-600 dark:text-emerald-400" />
                    <span>স্পিড ডায়াল ও সরকারি হটলাইন</span>
                  </h3>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    জরুরি ও বিশেষায়িত সেবাগুলোতে সরাসরি ডায়াল করুন
                  </p>
                </div>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-bold">
                  {filteredHotlines.length} টি
                </span>
              </div>

              {/* Search Bar for Speed Dial */}
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  <Search size={15} />
                </div>
                <input
                  type="text"
                  value={speedDialSearchQuery}
                  onChange={(e) => setSpeedDialSearchQuery(e.target.value)}
                  placeholder="স্পিড ডায়াল খুঁজুন (নাম বা নম্বর, যেমন: ১৬১২২, বিসিএস)..."
                  className="w-full pl-9 pr-8 py-2 rounded-xl bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 focus:border-emerald-500 transition-all"
                />
                {speedDialSearchQuery && (
                  <button
                    onClick={() => setSpeedDialSearchQuery('')}
                    title="ক্লিয়ার করুন"
                    className="absolute inset-y-0 right-0 pr-2.5 flex items-center text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                  >
                    <X size={14} />
                  </button>
                )}
              </div>

              {/* Hotlines List */}
              {filteredHotlines.length === 0 ? (
                <div className="py-8 px-4 text-center text-slate-400 space-y-2">
                  <Search size={28} className="mx-auto text-slate-300 dark:text-slate-700" />
                  <p className="text-xs text-slate-500">
                    &apos;{speedDialSearchQuery}&apos; দিয়ে কোনো কন্টাক্ট বা হটলাইন পাওয়া যায়নি।
                  </p>
                  <button
                    onClick={() => setSpeedDialSearchQuery('')}
                    className="text-xs text-emerald-600 dark:text-emerald-400 font-semibold hover:underline"
                  >
                    সব হটলাইন দেখুন
                  </button>
                </div>
              ) : (
                <div className="space-y-2">
                  {filteredHotlines.map((item) => (
                    <div
                      key={item.number}
                      onClick={() => startCall(item.number, item.name)}
                      className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/70 hover:border-emerald-500 hover:bg-emerald-50/20 dark:hover:bg-emerald-950/20 cursor-pointer transition-all flex items-center justify-between group"
                    >
                      <div className="flex items-center gap-3">
                        {renderContactAvatar(item.number, item.name, 'w-11 h-11 text-base')}
                        <div>
                          <div className="font-bold text-sm text-slate-900 dark:text-white group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors flex items-center gap-2">
                            <span>{item.name}</span>
                            <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-slate-200/70 dark:bg-slate-700/60 text-slate-600 dark:text-slate-300 font-bold">
                              {item.number}
                            </span>
                          </div>
                          <div className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-1">
                            {item.subtitle}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            openScheduleModal({ name: item.name, number: item.number });
                          }}
                          title="এই কন্টাক্টে কল শিডিউল করুন"
                          className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950/60 dark:hover:text-emerald-300 transition-colors"
                        >
                          <CalendarClock size={16} />
                        </button>
                        <button
                          type="button"
                          title="সরাসরি কল করুন"
                          className="p-2 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 group-hover:bg-emerald-600 group-hover:text-white transition-colors"
                        >
                          <Phone size={16} />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 3: CALL HISTORY (STORED IN LOCALSTORAGE) */}
          {activeTab === 'history' && (
            <div className="p-4 sm:p-5 space-y-3 max-h-[480px] overflow-y-auto">
              {/* History Header & Clear Action */}
              <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-2">
                  <h3 className="font-extrabold text-sm sm:text-base text-slate-900 dark:text-white flex items-center gap-1.5">
                    <History size={16} className="text-emerald-600 dark:text-emerald-400" />
                    <span>Call History</span>
                  </h3>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 font-semibold border border-emerald-200 dark:border-emerald-800">
                    localStorage
                  </span>
                </div>

                {history.length > 0 && (
                  <button
                    onClick={clearAllHistory}
                    title="সব কল হিস্ট্রি মুছে ফেলুন"
                    className="text-[11px] font-semibold text-rose-600 dark:text-rose-400 hover:text-rose-700 flex items-center gap-1 p-1 rounded-lg hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors"
                  >
                    <Trash2 size={13} />
                    <span>সব মুছুন</span>
                  </button>
                )}
              </div>

              {/* Search Bar for Call History */}
              {history.length > 0 && (
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                    <Search size={15} />
                  </div>
                  <input
                    type="text"
                    value={historySearchQuery}
                    onChange={(e) => setHistorySearchQuery(e.target.value)}
                    placeholder="কল হিস্ট্রি খুঁজুন (নাম বা ফোন নম্বর)..."
                    className="w-full pl-9 pr-8 py-2 rounded-xl bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 focus:border-emerald-500 transition-all"
                  />
                  {historySearchQuery && (
                    <button
                      onClick={() => setHistorySearchQuery('')}
                      title="ক্লিয়ার করুন"
                      className="absolute inset-y-0 right-0 pr-2.5 flex items-center text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                    >
                      <X size={14} />
                    </button>
                  )}
                </div>
              )}

              {/* Stats Summary Bar */}
              {history.length > 0 && !historySearchQuery && (
                <div className="grid grid-cols-2 gap-2 p-2.5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/70 dark:border-slate-700/60 text-xs">
                  <div>
                    <span className="text-[10px] text-slate-400 uppercase font-bold block">মোট ডায়াল</span>
                    <span className="font-extrabold text-slate-800 dark:text-slate-100">{history.length} টি কল</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 uppercase font-bold block">মোট স্থায়িত্ব</span>
                    <span className="font-extrabold text-emerald-600 dark:text-emerald-400">
                      {(() => {
                        const total = history.reduce((acc, h) => acc + (h.durationSeconds || 0), 0);
                        const mins = Math.floor(total / 60);
                        const secs = total % 60;
                        return mins > 0 ? `${mins} মি. ${secs} সে.` : `${secs} সেকেন্ড`;
                      })()}
                    </span>
                  </div>
                </div>
              )}

              {/* Call List */}
              {history.length === 0 ? (
                <div className="py-12 px-4 text-center text-slate-400 space-y-3">
                  <div className="w-14 h-14 mx-auto rounded-2xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-400">
                    <History size={28} />
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-700 dark:text-slate-300 text-sm">কোনো কল হিস্ট্রি নেই</h4>
                    <p className="text-xs text-slate-500 max-w-xs mx-auto mt-1">
                      ডায়াল প্যাড থেকে যেকোনো নম্বরে বা হটলাইনে কল করলে তা স্বয়ংক্রিয়ভাবে ব্রাউজারের লোকাল স্টোরেজে সংরক্ষিত থাকবে।
                    </p>
                  </div>
                  <button
                    onClick={() => setActiveTab('keypad')}
                    className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-all shadow-sm"
                  >
                    ডায়াল প্যাডে যান
                  </button>
                </div>
              ) : filteredHistory.length === 0 ? (
                <div className="py-8 px-4 text-center text-slate-400 space-y-2">
                  <Search size={28} className="mx-auto text-slate-300 dark:text-slate-700" />
                  <p className="text-xs text-slate-500">
                    &apos;{historySearchQuery}&apos; দিয়ে কোনো কল রেকর্ড পাওয়া যায়নি।
                  </p>
                  <button
                    onClick={() => setHistorySearchQuery('')}
                    className="text-xs text-emerald-600 dark:text-emerald-400 font-semibold hover:underline"
                  >
                    সব হিস্ট্রি দেখুন
                  </button>
                </div>
              ) : (
                <div className="space-y-2">
                  {filteredHistory.map((h) => {
                    const durationText = h.durationSeconds > 0 
                      ? (h.durationSeconds >= 60 
                          ? `${Math.floor(h.durationSeconds / 60)} মি. ${h.durationSeconds % 60} সে.`
                          : `${h.durationSeconds} সেকেন্ড`)
                      : 'সংক্ষিপ্ত (০ সে.)';

                    const dateStr = new Date(h.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
                    const dayStr = new Date(h.timestamp).toLocaleDateString([], { month: 'short', day: 'numeric' });

                    return (
                      <div
                        key={h.id}
                        className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-700/80 hover:border-emerald-500/50 transition-all flex items-center justify-between group"
                      >
                        <div className="flex items-center gap-3">
                          {renderContactAvatar(h.number, h.name, 'w-11 h-11 text-base')}
                          <div>
                            <div className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white">
                              {h.name}
                            </div>
                            <div className="text-[11px] text-slate-400 flex items-center gap-1.5 mt-0.5">
                              <span className="font-mono font-semibold text-slate-600 dark:text-slate-300">{h.number}</span>
                              <span>•</span>
                              <span className="text-emerald-600 dark:text-emerald-400 font-medium">{durationText}</span>
                              <span>•</span>
                              <span>{dayStr}, {dateStr}</span>
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-1.5 shrink-0">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              openScheduleModal({ name: h.name, number: h.number });
                            }}
                            title="শিডিউল রিমাইন্ডার সেট করুন"
                            className="p-1.5 rounded-xl text-slate-400 hover:text-emerald-600 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
                          >
                            <CalendarClock size={14} />
                          </button>
                          <button
                            onClick={() => startCall(h.number, h.name)}
                            title="পুনরায় এই নম্বরে কল করুন"
                            className="px-2.5 py-1.5 rounded-xl bg-emerald-50 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-300 text-xs font-bold hover:bg-emerald-600 hover:text-white transition-all flex items-center gap-1"
                          >
                            <Phone size={13} />
                            <span className="hidden sm:inline">কল</span>
                          </button>
                          <button
                            onClick={(e) => deleteHistoryItem(h.id, e)}
                            title="এই রেকর্ডটি মুছে ফেলুন"
                            className="p-1.5 rounded-xl text-slate-400 hover:text-rose-500 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
                          >
                            <Trash2 size={14} />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* TAB 4: SCHEDULE CALLS & REMINDERS */}
          {activeTab === 'schedule' && (
            <div className="p-4 sm:p-5 space-y-3.5 max-h-[520px] overflow-y-auto">
              {/* Header with Add Button */}
              <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
                <div>
                  <h3 className="font-extrabold text-sm sm:text-base text-slate-900 dark:text-white flex items-center gap-1.5">
                    <CalendarClock size={16} className="text-emerald-600 dark:text-emerald-400" />
                    <span>শিডিউল কল ও রিমাইন্ডার</span>
                  </h3>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    নির্দিষ্ট সময়ে কথা বলার জন্য অ্যালার্ট সেট করুন
                  </p>
                </div>

                <button
                  onClick={() => openScheduleModal()}
                  className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white text-xs font-bold flex items-center gap-1 shadow-sm transition-all"
                >
                  <Plus size={14} />
                  <span>নতুন শিডিউল</span>
                </button>
              </div>

              {/* Notification Permission Prompt if Default */}
              {typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'default' && (
                <div className="p-2.5 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/50 flex items-center justify-between text-xs text-amber-900 dark:text-amber-200">
                  <div className="flex items-center gap-2">
                    <BellRing size={15} className="text-amber-600 shrink-0" />
                    <span className="text-[11px]">যথাসময়ে রিমাইন্ডার পেতে ব্রাউজার নোটিফিকেশন অন করুন</span>
                  </div>
                  <button
                    onClick={() => {
                      Notification.requestPermission();
                    }}
                    className="px-2 py-0.5 rounded-lg bg-amber-200/80 dark:bg-amber-800 text-[10px] font-bold text-amber-950 dark:text-amber-100 shrink-0 hover:bg-amber-300 transition-colors"
                  >
                    অনুমতি দিন
                  </button>
                </div>
              )}

              {/* Search Bar & Filter Pills */}
              <div className="space-y-2">
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                    <Search size={15} />
                  </div>
                  <input
                    type="text"
                    value={scheduleSearchQuery}
                    onChange={(e) => setScheduleSearchQuery(e.target.value)}
                    placeholder="নাম, নম্বর বা নোট দিয়ে খুঁজুন..."
                    className="w-full pl-9 pr-8 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-emerald-500/30 transition-all"
                  />
                  {scheduleSearchQuery && (
                    <button
                      onClick={() => setScheduleSearchQuery('')}
                      className="absolute inset-y-0 right-0 pr-2.5 flex items-center text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                    >
                      <X size={14} />
                    </button>
                  )}
                </div>

                {/* Filter Tabs */}
                <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800/60 p-1 rounded-xl text-xs font-semibold">
                  <button
                    onClick={() => setScheduleFilter('pending')}
                    className={`flex-1 py-1 rounded-lg text-center transition-all ${
                      scheduleFilter === 'pending'
                        ? 'bg-white dark:bg-slate-700 text-emerald-700 dark:text-emerald-300 shadow-xs'
                        : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
                    }`}
                  >
                    আসন্ন কল ({pendingScheduleCount})
                  </button>
                  <button
                    onClick={() => setScheduleFilter('all')}
                    className={`flex-1 py-1 rounded-lg text-center transition-all ${
                      scheduleFilter === 'all'
                        ? 'bg-white dark:bg-slate-700 text-emerald-700 dark:text-emerald-300 shadow-xs'
                        : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
                    }`}
                  >
                    সকল ({scheduledCalls.length})
                  </button>
                  <button
                    onClick={() => setScheduleFilter('completed')}
                    className={`flex-1 py-1 rounded-lg text-center transition-all ${
                      scheduleFilter === 'completed'
                        ? 'bg-white dark:bg-slate-700 text-emerald-700 dark:text-emerald-300 shadow-xs'
                        : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
                    }`}
                  >
                    সম্পন্ন ({scheduledCalls.filter((c) => c.status === 'completed').length})
                  </button>
                </div>
              </div>

              {/* Scheduled Calls List */}
              {filteredScheduledCalls.length === 0 ? (
                <div className="py-10 text-center space-y-3">
                  <div className="w-12 h-12 mx-auto rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-400 flex items-center justify-center">
                    <CalendarClock size={24} />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm text-slate-700 dark:text-slate-300">
                      কোনো শিডিউল কল পাওয়া যায়নি
                    </h4>
                    <p className="text-xs text-slate-400 mt-0.5">
                      {scheduleSearchQuery ? 'অন্য কোনো নাম বা নম্বর দিয়ে খুঁজুন' : 'নির্দিষ্ট সময়ে কথা বলতে একটি নতুন কল শিডিউল করুন'}
                    </p>
                  </div>
                  <button
                    onClick={() => openScheduleModal()}
                    className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-all shadow-sm"
                  >
                    <Plus size={14} />
                    <span>কল শিডিউল করুন</span>
                  </button>
                </div>
              ) : (
                <div className="space-y-2.5">
                  {filteredScheduledCalls.map((item) => {
                    const badge = getRelativeScheduleBadge(item.scheduledTime, item.status);
                    return (
                      <div
                        key={item.id}
                        className={`p-3 rounded-2xl border transition-all ${
                          item.status === 'completed'
                            ? 'bg-slate-50/60 dark:bg-slate-900/40 border-slate-200/50 dark:border-slate-800/50 opacity-70'
                            : 'bg-white dark:bg-slate-800/90 border-slate-200 dark:border-slate-700/80 shadow-xs hover:border-emerald-500/40'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-2.5">
                          {/* Avatar & Contact Info */}
                          <div className="flex items-start gap-2.5 min-w-0">
                            {renderContactAvatar(item.contactNumber, item.contactName, 'w-10 h-10', false)}
                            <div className="min-w-0">
                              <div className="flex items-center gap-2 flex-wrap">
                                <h4 className={`font-bold text-xs sm:text-sm truncate ${
                                  item.status === 'completed' ? 'line-through text-slate-500' : 'text-slate-900 dark:text-white'
                                }`}>
                                  {item.contactName}
                                </h4>
                                <span className={`text-[10px] px-2 py-0.5 rounded-full ${badge.color}`}>
                                  {badge.text}
                                </span>
                              </div>

                              <div className="text-[11px] font-mono text-emerald-600 dark:text-emerald-400 font-semibold mt-0.5">
                                {item.contactNumber}
                              </div>

                              <div className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-1 mt-1 font-medium">
                                <Clock size={12} className="text-slate-400 shrink-0" />
                                <span>{formatScheduledDateTime(item.scheduledTime)}</span>
                              </div>

                              {item.note && (
                                <div className="mt-1.5 p-1.5 rounded-lg bg-slate-50 dark:bg-slate-900/60 border border-slate-100 dark:border-slate-800 text-[11px] text-slate-600 dark:text-slate-300">
                                  📝 {item.note}
                                </div>
                              )}
                            </div>
                          </div>

                          {/* Action Buttons */}
                          <div className="flex items-center gap-1 shrink-0 pt-0.5">
                            {item.status === 'pending' ? (
                              <button
                                onClick={() => handleCallFromSchedule(item)}
                                title="এখনই কল করুন"
                                className="px-2.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white text-xs font-bold shadow-xs flex items-center gap-1 transition-all"
                              >
                                <Phone size={13} />
                                <span>কল</span>
                              </button>
                            ) : null}

                            <button
                              onClick={(e) => toggleScheduleStatus(item.id, e)}
                              title={item.status === 'completed' ? 'পুনরায় সক্রিয় করুন' : 'সম্পন্ন হিসেবে চিহ্নিত করুন'}
                              className={`p-1.5 rounded-xl transition-colors ${
                                item.status === 'completed'
                                  ? 'text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950/40'
                                  : 'text-slate-400 hover:text-emerald-600 hover:bg-slate-100 dark:hover:bg-slate-700'
                              }`}
                            >
                              <CheckCircle2 size={16} />
                            </button>

                            <button
                              onClick={(e) => deleteScheduledCall(item.id, e)}
                              title="শিডিউল মুছে ফেলুন"
                              className="p-1.5 rounded-xl text-slate-400 hover:text-rose-500 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
                            >
                              <Trash2 size={15} />
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}
        </div>
      ) : (
        /* IN-CALL ACTIVE SCREEN */
        <div className="bg-gradient-to-b from-slate-900 via-emerald-950 to-slate-950 text-white rounded-3xl border border-emerald-800/40 shadow-2xl overflow-hidden max-w-md mx-auto p-6 flex flex-col justify-between min-h-[560px] relative animate-fade-in">
          {/* Top Info */}
          <div className="text-center pt-4 space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold bg-white/10 backdrop-blur-xs text-emerald-300 border border-emerald-500/30">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
              {callStatus === 'connecting' && 'সংযোগ স্থাপন করা হচ্ছে...'}
              {callStatus === 'ringing' && 'রিং হচ্ছে (Ringing)...'}
              {callStatus === 'connected' && `কল যুক্ত আছে • ${formatTime(callDuration)}`}
              {callStatus === 'ended' && 'কল সমাপ্ত হয়েছে'}
            </div>

            <h2 className="text-2xl font-black tracking-tight text-white mt-2">
              {activeContact.name}
            </h2>
            <div className="text-sm font-mono text-emerald-400">
              {activeContact.number}
            </div>
          </div>

          {/* Caller Pulse Animation */}
          <div className="my-auto py-6 flex flex-col items-center justify-center relative">
            <div className="relative">
              {/* Outer pulsing ring */}
              <div
                className={`absolute inset-0 rounded-full bg-emerald-500/20 blur-xl transition-transform duration-300 ${
                  aiSpeaking || micWaveActivity > 0.1 ? 'scale-150 animate-pulse' : 'scale-100'
                }`}
              ></div>

              {/* Middle ring */}
              <div
                className={`w-32 h-32 rounded-full border-2 border-emerald-400/40 flex items-center justify-center transition-all ${
                  aiSpeaking ? 'ring-8 ring-emerald-500/30' : ''
                }`}
              >
                {/* Center Core Avatar */}
                <div className={`w-24 h-24 rounded-full bg-gradient-to-tr ${getGradientForString(activeContact.number + activeContact.name)} flex items-center justify-center text-white shadow-2xl select-none`}>
                  {customAvatars[activeContact.number] ? (
                    <span className="text-4xl animate-pulse">
                      {customAvatars[activeContact.number]}
                    </span>
                  ) : aiSpeaking ? (
                    <Headphones size={38} className="animate-bounce" />
                  ) : activeContact.name ? (
                    <span className="font-mono text-2xl font-black">
                      {getInitials(activeContact.name, activeContact.number)}
                    </span>
                  ) : (
                    <Phone size={36} className="animate-pulse" />
                  )}
                </div>
              </div>
            </div>

            {/* Speaking Status text */}
            <div className="mt-4 text-xs font-bold text-emerald-300 flex items-center gap-1.5">
              {aiSpeaking ? (
                <>
                  <Volume2 size={15} className="animate-pulse" />
                  <span>দেশ AI কথা বলছেন...</span>
                </>
              ) : isMuted ? (
                <span className="text-rose-400">মাইক্রোফোন মিউট করা</span>
              ) : (
                <span>কথা বলুন, দেশ AI শুনছে...</span>
              )}
            </div>

            {/* Live Visualizer sound wave */}
            <div className="flex items-center gap-1 mt-3 h-5">
              {[4, 8, 14, 10, 18, 12, 6].map((baseH, idx) => {
                const height = aiSpeaking
                  ? Math.max(4, Math.random() * 20)
                  : micWaveActivity > 0.05
                  ? Math.max(4, micWaveActivity * 24 * Math.random())
                  : 4;
                return (
                  <div
                    key={idx}
                    className="w-1 bg-emerald-400 rounded-full transition-all duration-75"
                    style={{ height: `${height}px` }}
                  ></div>
                );
              })}
            </div>
          </div>

          {/* Transcript / Subtitles Drawer */}
          <div className="bg-black/40 backdrop-blur-md rounded-2xl p-3 border border-white/10 max-h-24 overflow-y-auto mb-4 text-xs text-slate-300 space-y-1">
            {transcript.slice(-3).map((line, idx) => (
              <p key={idx} className="leading-relaxed">
                {line}
              </p>
            ))}
          </div>

          {/* In-Call Keypad (if opened) */}
          {showInCallKeypad && (
            <div className="bg-slate-900/90 backdrop-blur-md p-3 rounded-2xl border border-white/10 mb-3 grid grid-cols-3 gap-2">
              {['1', '2', '3', '4', '5', '6', '7', '8', '9', '*', '0', '#'].map((d) => (
                <button
                  key={d}
                  onClick={() => handleKeyPress(d)}
                  className="py-2 rounded-xl bg-white/10 hover:bg-emerald-600/40 text-sm font-bold text-white transition-colors"
                >
                  {d}
                </button>
              ))}
            </div>
          )}

          {/* In-Call Text Input (Alternative if mic issue) */}
          <form onSubmit={handleSendInCallText} className="flex gap-2 mb-4">
            <input
              type="text"
              value={inCallTextInput}
              onChange={(e) => setInCallTextInput(e.target.value)}
              placeholder="মুখে না বলে লিখে বলতে চাইলে এখানে টাইপ করুন..."
              className="flex-1 px-3 py-2 rounded-xl bg-white/10 border border-white/10 text-xs text-white placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-emerald-400"
            />
            <button
              type="submit"
              disabled={!inCallTextInput.trim()}
              className="p-2 rounded-xl bg-emerald-600 text-white disabled:opacity-40"
            >
              <Send size={15} />
            </button>
          </form>

          {/* In-Call Action Control Buttons */}
          <div className="flex items-center justify-around pt-2">
            {/* Mute Button */}
            <button
              onClick={() => setIsMuted(!isMuted)}
              className={`p-3.5 rounded-2xl flex flex-col items-center gap-1 text-xs font-semibold transition-all ${
                isMuted ? 'bg-rose-600 text-white' : 'bg-white/10 hover:bg-white/20 text-slate-200'
              }`}
            >
              {isMuted ? <MicOff size={20} /> : <Mic size={20} />}
              <span className="text-[10px]">{isMuted ? 'আনমিউট' : 'মিউট'}</span>
            </button>

            {/* In-Call Keypad Toggle */}
            <button
              onClick={() => setShowInCallKeypad(!showInCallKeypad)}
              className={`p-3.5 rounded-2xl flex flex-col items-center gap-1 text-xs font-semibold transition-all ${
                showInCallKeypad ? 'bg-emerald-600 text-white' : 'bg-white/10 hover:bg-white/20 text-slate-200'
              }`}
            >
              <Grid size={20} />
              <span className="text-[10px]">কিপ্যাড</span>
            </button>

            {/* Speaker Toggle */}
            <button
              onClick={() => setSpeakerOn(!speakerOn)}
              className={`p-3.5 rounded-2xl flex flex-col items-center gap-1 text-xs font-semibold transition-all ${
                speakerOn ? 'bg-white/20 text-emerald-300' : 'bg-white/10 text-slate-400'
              }`}
            >
              {speakerOn ? <Volume2 size={20} /> : <VolumeX size={20} />}
              <span className="text-[10px]">স্পিকার</span>
            </button>

            {/* End Call Button */}
            <button
              onClick={hangupCall}
              title="কল শেষ করুন"
              className="w-14 h-14 rounded-2xl bg-rose-600 hover:bg-rose-700 active:scale-95 text-white flex items-center justify-center shadow-lg shadow-rose-700/50 transition-all"
            >
              <PhoneOff size={24} />
            </button>
          </div>
        </div>
      )}

      {/* Avatar & Custom Emoji Picker Modal */}
      {editingAvatarTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/60 backdrop-blur-sm animate-fade-in">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-md shadow-2xl overflow-hidden flex flex-col">
            {/* Modal Header */}
            <div className="p-4 sm:p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
                  <Smile size={20} />
                </div>
                <div>
                  <h3 className="font-extrabold text-sm sm:text-base text-slate-900 dark:text-white">
                    অবতার ও ইমোজি নির্বাচন
                  </h3>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    {editingAvatarTarget.name} ({editingAvatarTarget.number})
                  </p>
                </div>
              </div>
              <button
                onClick={() => setEditingAvatarTarget(null)}
                className="p-1.5 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              >
                <X size={18} />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-5 space-y-4 max-h-[70vh] overflow-y-auto">
              {/* Live Preview Box */}
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/80 flex items-center gap-4">
                <div className={`w-14 h-14 rounded-2xl bg-gradient-to-tr ${getGradientForString(editingAvatarTarget.number + editingAvatarTarget.name)} flex items-center justify-center text-white font-bold shadow-md select-none`}>
                  {customEmojiInput.trim() ? (
                    <span className="text-2xl leading-none">{customEmojiInput.trim()}</span>
                  ) : (
                    <span className="font-mono text-base">{getInitials(editingAvatarTarget.name, editingAvatarTarget.number)}</span>
                  )}
                </div>
                <div>
                  <div className="font-extrabold text-sm text-slate-900 dark:text-white">
                    {editingAvatarTarget.name}
                  </div>
                  <div className="text-xs text-slate-400 mt-0.5">
                    {customEmojiInput.trim() ? 'কাস্টম ইমোজি নির্ধারিত আছে' : 'অটো-জেনারেটেড গ্রেডিয়েন্ট অবতার সক্রিয়'}
                  </div>
                </div>
              </div>

              {/* Custom Input */}
              <div>
                <label className="text-xs font-bold text-slate-600 dark:text-slate-300 block mb-1">
                  কীবোর্ড থেকে যেকোনো ইমোজি লিখুন বা পেস্ট করুন:
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={customEmojiInput}
                    onChange={(e) => setCustomEmojiInput(e.target.value)}
                    placeholder="যেকোনো ইমোজি দিন (যেমন: 🇧🇩, 🎓, 🌾)..."
                    className="flex-1 px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                  />
                  {customEmojiInput && (
                    <button
                      onClick={() => setCustomEmojiInput('')}
                      className="px-2.5 py-2 rounded-xl text-xs font-bold bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300"
                    >
                      মুছুন
                    </button>
                  )}
                </div>
              </div>

              {/* Quick Emojis by Category */}
              <div className="space-y-3 pt-1">
                <label className="text-xs font-bold text-slate-600 dark:text-slate-300 block">
                  অথবা তালিকা থেকে বেছে নিন:
                </label>
                {EMOJI_CATEGORIES.map((cat, cIdx) => (
                  <div key={cIdx} className="space-y-1.5">
                    <span className="text-[10px] font-bold uppercase text-slate-400 tracking-wider">
                      {cat.name}
                    </span>
                    <div className="grid grid-cols-10 gap-1.5">
                      {cat.emojis.map((emoji, eIdx) => {
                        const isSelected = customEmojiInput === emoji;
                        return (
                          <button
                            key={eIdx}
                            type="button"
                            onClick={() => setCustomEmojiInput(emoji)}
                            className={`w-8 h-8 rounded-xl text-lg flex items-center justify-center transition-all ${
                              isSelected
                                ? 'bg-emerald-600 text-white shadow-sm ring-2 ring-emerald-400 scale-110'
                                : 'bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700'
                            }`}
                          >
                            {emoji}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Modal Actions */}
            <div className="p-4 border-t border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50 flex items-center justify-between gap-2">
              <button
                type="button"
                onClick={() => handleAssignEmoji(editingAvatarTarget.number, null)}
                className="px-3.5 py-2 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors flex items-center gap-1.5"
              >
                <RotateCcw size={13} />
                <span>অটো অবতার (রিসেট)</span>
              </button>

              <button
                type="button"
                onClick={() => handleAssignEmoji(editingAvatarTarget.number, customEmojiInput.trim() || null)}
                className="px-5 py-2 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white transition-all shadow-sm"
              >
                সংরক্ষণ করুন
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Schedule Call Modal Dialog */}
      {isScheduleModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/60 backdrop-blur-sm animate-fade-in">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-md shadow-2xl overflow-hidden flex flex-col">
            {/* Modal Header */}
            <div className="p-4 sm:p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
                  <CalendarClock size={20} />
                </div>
                <div>
                  <h3 className="font-extrabold text-sm sm:text-base text-slate-900 dark:text-white">
                    কল শিডিউল করুন
                  </h3>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    ভবিষ্যতের সময় ও তারিখ নির্ধারণ করুন
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsScheduleModalOpen(false)}
                className="p-1.5 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              >
                <X size={18} />
              </button>
            </div>

            {/* Modal Form */}
            <form onSubmit={handleSaveSchedule} className="p-5 space-y-4 max-h-[75vh] overflow-y-auto">
              {/* Quick Contact Chips from Hotlines */}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                  দ্রুত নির্বাচন (হটলাইন):
                </label>
                <div className="flex gap-1.5 overflow-x-auto pb-1 no-scrollbar">
                  {HOTLINES.slice(0, 5).map((h) => (
                    <button
                      key={h.number}
                      type="button"
                      onClick={() => {
                        setScheduleForm((prev) => ({
                          ...prev,
                          contactName: h.name,
                          contactNumber: h.number,
                        }));
                      }}
                      className="px-2.5 py-1 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-emerald-100 dark:hover:bg-emerald-950 text-[11px] font-semibold text-slate-700 dark:text-slate-300 hover:text-emerald-700 dark:hover:text-emerald-300 shrink-0 transition-colors"
                    >
                      {h.name.split(' ')[0]} ({h.number})
                    </button>
                  ))}
                </div>
              </div>

              {/* Name & Phone */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    কন্টাক্টের নাম
                  </label>
                  <input
                    type="text"
                    value={scheduleForm.contactName}
                    onChange={(e) => setScheduleForm({ ...scheduleForm, contactName: e.target.value })}
                    placeholder="যেমন: বিসিএস প্রস্তুতি বা নাম"
                    className="w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-white placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-emerald-500/40"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    ফোন নম্বর <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="tel"
                    required
                    value={scheduleForm.contactNumber}
                    onChange={(e) => setScheduleForm({ ...scheduleForm, contactNumber: e.target.value })}
                    placeholder="যেমন: 16122"
                    className="w-full px-3 py-2 text-xs font-mono rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-white placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-emerald-500/40"
                  />
                </div>
              </div>

              {/* Date & Time */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    তারিখ
                  </label>
                  <input
                    type="date"
                    required
                    value={scheduleForm.date}
                    onChange={(e) => setScheduleForm({ ...scheduleForm, date: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-emerald-500/40"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    সময়
                  </label>
                  <input
                    type="time"
                    required
                    value={scheduleForm.time}
                    onChange={(e) => setScheduleForm({ ...scheduleForm, time: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-emerald-500/40"
                  />
                </div>
              </div>

              {/* Quick Presets */}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                  দ্রুত সময় প্রিসেট:
                </label>
                <div className="flex flex-wrap gap-1.5">
                  <button
                    type="button"
                    onClick={() => setPresetScheduleTime(15)}
                    className="px-2.5 py-1 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 text-[11px] font-semibold text-emerald-800 dark:text-emerald-300 hover:bg-emerald-100 transition-colors"
                  >
                    +১৫ মিনিট
                  </button>
                  <button
                    type="button"
                    onClick={() => setPresetScheduleTime(30)}
                    className="px-2.5 py-1 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 text-[11px] font-semibold text-emerald-800 dark:text-emerald-300 hover:bg-emerald-100 transition-colors"
                  >
                    +৩০ মিনিট
                  </button>
                  <button
                    type="button"
                    onClick={() => setPresetScheduleTime(60)}
                    className="px-2.5 py-1 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 text-[11px] font-semibold text-emerald-800 dark:text-emerald-300 hover:bg-emerald-100 transition-colors"
                  >
                    +১ ঘণ্টা
                  </button>
                  <button
                    type="button"
                    onClick={() => setEveningOrMorningPreset(false, 19, 0)}
                    className="px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-[11px] font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-200 transition-colors"
                  >
                    আজ সন্ধ্যা ৭:০০
                  </button>
                  <button
                    type="button"
                    onClick={() => setEveningOrMorningPreset(true, 10, 0)}
                    className="px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-[11px] font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-200 transition-colors"
                  >
                    কাল সকাল ১০:০০
                  </button>
                </div>
              </div>

              {/* Note / Purpose */}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  নোট বা আলোচনার বিষয় (ঐচ্ছিক)
                </label>
                <textarea
                  rows={2}
                  value={scheduleForm.note}
                  onChange={(e) => setScheduleForm({ ...scheduleForm, note: e.target.value })}
                  placeholder="যেমন: গণিত শর্টকাট টেকনিক ও বাংলা সাহিত্যের পরামর্শ নেওয়া..."
                  className="w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-white placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-emerald-500/40 resize-none"
                />
              </div>

              {/* Submit Buttons */}
              <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsScheduleModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white transition-all shadow-md shadow-emerald-700/30 flex items-center gap-1.5"
                >
                  <CalendarPlus size={14} />
                  <span>শিডিউল সংরক্ষণ করুন</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Active Call Reminder Alert Modal */}
      {activeReminder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-md animate-fade-in">
          <div className="bg-gradient-to-b from-slate-900 via-emerald-950/90 to-slate-950 border border-emerald-500/40 rounded-3xl w-full max-w-sm shadow-2xl p-6 text-center text-white space-y-4">
            {/* Pulsing Bell */}
            <div className="w-16 h-16 mx-auto rounded-full bg-emerald-500/20 border-2 border-emerald-400 flex items-center justify-center text-emerald-400 animate-bounce">
              <BellRing size={32} />
            </div>

            <div>
              <span className="text-[11px] font-extrabold uppercase tracking-wider text-emerald-400 bg-emerald-950/80 border border-emerald-500/30 px-3 py-1 rounded-full">
                শিডিউল কলের সময় হয়েছে!
              </span>
              <h3 className="text-xl font-black mt-2 text-white">
                {activeReminder.contactName}
              </h3>
              <p className="font-mono text-sm text-emerald-300 mt-0.5">
                {activeReminder.contactNumber}
              </p>
            </div>

            {activeReminder.note && (
              <div className="p-3 rounded-2xl bg-white/5 border border-white/10 text-xs text-slate-300 text-left">
                <span className="font-bold text-slate-400 block mb-0.5">নোট:</span>
                {activeReminder.note}
              </div>
            )}

            {/* Action Buttons */}
            <div className="space-y-2 pt-2">
              <button
                onClick={handleCallNowFromReminder}
                className="w-full py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-extrabold text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-700/50 transition-all"
              >
                <PhoneCall size={18} />
                <span>এখনই কল করুন (Call Now)</span>
              </button>

              <div className="flex gap-2">
                <button
                  onClick={() => handleSnoozeReminder(10)}
                  className="flex-1 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-slate-200 text-xs font-bold transition-colors"
                >
                  ১০ মিনিট পেছান
                </button>
                <button
                  onClick={handleDismissReminder}
                  className="flex-1 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-slate-400 hover:text-white text-xs font-bold transition-colors"
                >
                  সম্পন্ন (Dismiss)
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
