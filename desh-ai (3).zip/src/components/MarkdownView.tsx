import React, { useState } from 'react';
import { Check, Copy } from 'lucide-react';

interface MarkdownViewProps {
  content: string;
  className?: string;
}

export const MarkdownView: React.FC<MarkdownViewProps> = ({ content, className = '' }) => {
  return (
    <div className={`prose-desh text-sm md:text-base leading-relaxed break-words space-y-3 ${className}`}>
      {renderMarkdown(content)}
    </div>
  );
};

function renderMarkdown(text: string) {
  if (!text) return null;

  // Split by code blocks first
  const parts = text.split(/(```[\s\S]*?```)/g);

  return parts.map((part, index) => {
    if (part.startsWith('```') && part.endsWith('```')) {
      return <CodeBlock key={index} raw={part} />;
    }
    return <TextBlock key={index} text={part} />;
  });
}

const CodeBlock: React.FC<{ raw: string }> = ({ raw }) => {
  const [copied, setCopied] = useState(false);
  
  // Extract language and code
  const lines = raw.slice(3, -3).trim().split('\n');
  const firstLine = lines[0].trim();
  const hasLang = /^[a-zA-Z0-9_-]+$/.test(firstLine);
  const lang = hasLang ? firstLine : '';
  const code = hasLang ? lines.slice(1).join('\n') : lines.join('\n');

  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="relative my-3 rounded-xl overflow-hidden border border-emerald-950/30 bg-slate-900 text-slate-100 font-mono text-xs md:text-sm">
      <div className="flex items-center justify-between px-3.5 py-1.5 bg-slate-950/80 border-b border-slate-800 text-xs text-slate-400">
        <span className="font-semibold uppercase tracking-wider text-emerald-400">{lang || 'CODE'}</span>
        <button
          onClick={handleCopy}
          className="flex items-center gap-1.5 px-2 py-0.5 rounded hover:bg-slate-800 text-slate-300 transition-colors"
          title="কপি করুন"
        >
          {copied ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
          <span>{copied ? 'কপি হয়েছে' : 'কপি'}</span>
        </button>
      </div>
      <div className="p-3.5 overflow-x-auto">
        <pre className="m-0 font-mono leading-relaxed">{code}</pre>
      </div>
    </div>
  );
};

const TextBlock: React.FC<{ text: string }> = ({ text }) => {
  const lines = text.split('\n');
  const elements: React.ReactNode[] = [];
  let inList = false;
  let listItems: React.ReactNode[] = [];
  let listType: 'ul' | 'ol' = 'ul';

  const flushList = () => {
    if (inList && listItems.length > 0) {
      if (listType === 'ol') {
        elements.push(
          <ol key={`ol-${elements.length}`} className="list-decimal pl-5 space-y-1 my-2">
            {listItems}
          </ol>
        );
      } else {
        elements.push(
          <ul key={`ul-${elements.length}`} className="list-disc pl-5 space-y-1 my-2">
            {listItems}
          </ul>
        );
      }
      listItems = [];
      inList = false;
    }
  };

  lines.forEach((line, i) => {
    const trimmed = line.trim();

    // Blank line
    if (!trimmed) {
      flushList();
      return;
    }

    // Headings
    if (trimmed.startsWith('### ')) {
      flushList();
      elements.push(
        <h4 key={i} className="text-base md:text-lg font-bold text-emerald-700 dark:text-emerald-400 mt-3 mb-1">
          {formatInline(trimmed.slice(4))}
        </h4>
      );
      return;
    }
    if (trimmed.startsWith('## ')) {
      flushList();
      elements.push(
        <h3 key={i} className="text-lg md:text-xl font-bold text-slate-900 dark:text-white mt-4 mb-2 pb-1 border-b border-emerald-500/20">
          {formatInline(trimmed.slice(3))}
        </h3>
      );
      return;
    }
    if (trimmed.startsWith('# ')) {
      flushList();
      elements.push(
        <h2 key={i} className="text-xl md:text-2xl font-bold text-slate-900 dark:text-white mt-5 mb-2">
          {formatInline(trimmed.slice(2))}
        </h2>
      );
      return;
    }

    // Blockquote
    if (trimmed.startsWith('> ')) {
      flushList();
      elements.push(
        <blockquote
          key={i}
          className="border-l-4 border-emerald-500 pl-3 py-1 my-2 italic text-slate-600 dark:text-slate-300 bg-emerald-50/50 dark:bg-emerald-950/20 rounded-r"
        >
          {formatInline(trimmed.slice(2))}
        </blockquote>
      );
      return;
    }

    // Unordered List (- or *)
    const bulletMatch = trimmed.match(/^[-*]\s+(.*)$/);
    if (bulletMatch) {
      if (!inList || listType !== 'ul') {
        flushList();
        inList = true;
        listType = 'ul';
      }
      listItems.push(<li key={`li-${i}`}>{formatInline(bulletMatch[1])}</li>);
      return;
    }

    // Numbered List (1. or ১.)
    const numMatch = trimmed.match(/^([0-9]+|[০-৯]+)\.\s+(.*)$/);
    if (numMatch) {
      if (!inList || listType !== 'ol') {
        flushList();
        inList = true;
        listType = 'ol';
      }
      listItems.push(<li key={`li-${i}`}>{formatInline(numMatch[2])}</li>);
      return;
    }

    // Table divider line (ignore or handle)
    if (/^\|[-:| ]+\|$/.test(trimmed)) {
      return;
    }

    // Table Row
    if (trimmed.startsWith('|') && trimmed.endsWith('|')) {
      flushList();
      const cells = trimmed
        .slice(1, -1)
        .split('|')
        .map((c) => c.trim());
      elements.push(
        <div key={i} className="my-1 flex divide-x divide-slate-200 dark:divide-slate-700 bg-slate-50 dark:bg-slate-800/60 rounded border border-slate-200 dark:border-slate-700 text-xs md:text-sm">
          {cells.map((cell, ci) => (
            <div key={ci} className="px-3 py-1.5 flex-1 font-medium">
              {formatInline(cell)}
            </div>
          ))}
        </div>
      );
      return;
    }

    // Normal paragraph line
    flushList();
    elements.push(
      <p key={i} className="my-1.5">
        {formatInline(line)}
      </p>
    );
  });

  flushList();

  return <>{elements}</>;
};

function formatInline(text: string): React.ReactNode[] {
  // Handles bold (**text**), code (`code`), italic (*text*)
  const regex = /(\*\*.*?\*\*|`.*?`|\*.*?\*)/g;
  const parts = text.split(regex);

  return parts.map((part, i) => {
    if (part.startsWith('**') && part.endsWith('**')) {
      return (
        <strong key={i} className="font-bold text-slate-900 dark:text-emerald-300">
          {part.slice(2, -2)}
        </strong>
      );
    }
    if (part.startsWith('`') && part.endsWith('`')) {
      return (
        <code
          key={i}
          className="px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-emerald-700 dark:text-emerald-300 font-mono text-xs md:text-sm font-semibold border border-slate-200 dark:border-slate-700"
        >
          {part.slice(1, -1)}
        </code>
      );
    }
    if (part.startsWith('*') && part.endsWith('*')) {
      return (
        <em key={i} className="italic">
          {part.slice(1, -1)}
        </em>
      );
    }
    return part;
  });
}
