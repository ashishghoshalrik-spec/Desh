import React, { useState } from 'react';
import { 
  GraduationCap, 
  Sparkles, 
  CheckCircle2, 
  XCircle, 
  RotateCcw, 
  Trophy, 
  HelpCircle, 
  BookOpen, 
  Clock,
  ArrowRight
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { QuizQuestion } from '../types';
import { MarkdownView } from './MarkdownView';

const CATEGORIES = [
  'বাংলাদেশ বিষয়াবলী',
  'বাংলা ভাষা ও সাহিত্য',
  'আন্তর্জাতিক বিষয়াবলী',
  'সাধারণ বিজ্ঞান ও আইসিটি',
  'গাণিতিক যুক্তি ও মানসিক দক্ষতা',
  'ইংরেজি ব্যাকরণ ও সাহিত্য',
];

const BANGLA_NUMERALS = ['১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯', '১০'];
const BANGLA_OPTION_PREFIX = ['ক', 'খ', 'গ', 'ঘ'];

export const QuizTab: React.FC = () => {
  const [category, setCategory] = useState(CATEGORIES[0]);
  const [questionCount, setQuestionCount] = useState(5);
  const [difficulty, setDifficulty] = useState('মাঝারি');

  const [loading, setLoading] = useState(false);
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const [showExplanation, setShowExplanation] = useState<Record<number, boolean>>({});
  const [quizFinished, setQuizFinished] = useState(false);

  const startQuiz = async () => {
    setLoading(true);
    setQuizFinished(false);
    setCurrentIndex(0);
    setAnswers({});
    setShowExplanation({});

    try {
      const res = await fetch('/api/quiz', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          category,
          count: questionCount,
          difficulty,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'কুইজ লোড করা যায়নি');

      if (!Array.isArray(data.questions) || data.questions.length === 0) {
        throw new Error('কোনো প্রশ্ন প্রস্তুত হয়নি');
      }

      setQuestions(data.questions);
    } catch (err: any) {
      alert(err.message || 'কুইজ তৈরিতে সমস্যা হয়েছে');
    } finally {
      setLoading(false);
    }
  };

  const handleSelectOption = (optionIndex: number) => {
    // If already answered this question, don't re-select
    if (answers[currentIndex] !== undefined) return;

    const newAnswers = { ...answers, [currentIndex]: optionIndex };
    setAnswers(newAnswers);
    setShowExplanation((prev) => ({ ...prev, [currentIndex]: true }));

    // If last question answered, calculate finish
    if (Object.keys(newAnswers).length === questions.length) {
      setTimeout(() => {
        setQuizFinished(true);
        // Calculate score
        let correct = 0;
        questions.forEach((q, idx) => {
          if (newAnswers[idx] === q.correctIndex) correct++;
        });
        if (correct / questions.length >= 0.7) {
          try {
            confetti({
              particleCount: 100,
              spread: 70,
              origin: { y: 0.6 },
            });
          } catch (e) {
            // ignore
          }
        }
      }, 1000);
    }
  };

  const currentQ = questions[currentIndex];
  const answeredCount = Object.keys(answers).length;
  const score = questions.reduce(
    (acc, q, idx) => (answers[idx] === q.correctIndex ? acc + 1 : acc),
    0
  );

  return (
    <div className="max-w-4xl mx-auto px-3 sm:px-6 py-6 space-y-6">
      {/* Banner */}
      <div className="bg-gradient-to-r from-emerald-800 to-teal-900 rounded-3xl p-6 text-white shadow-lg flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-700/60 text-emerald-200 border border-emerald-500/30 mb-2">
            <GraduationCap size={14} />
            বিসিএস ও সরকারি চাকরি প্রস্তুতি মেন্টর
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            স্মার্ট কুইজ ও প্রস্তুতি চ্যালেঞ্জ
          </h1>
          <p className="text-emerald-100 text-xs sm:text-sm mt-1 max-w-xl">
            বিসিএস প্রিলিমিনারি ও চাকরির পরীক্ষার গুরুত্বপূর্ণ টপিকগুলোতে নিজের প্রস্তুতি যাচাই করুন এবং প্রতিটি উত্তরের বিস্তারিত ব্যাখ্যা জেনে নিন।
          </p>
        </div>

        {questions.length > 0 && !quizFinished && (
          <div className="bg-emerald-950/60 border border-emerald-600/30 px-4 py-2.5 rounded-2xl flex items-center gap-3">
            <Trophy size={20} className="text-amber-400" />
            <div>
              <div className="text-[10px] uppercase font-bold text-emerald-300">বর্তমান স্কোর</div>
              <div className="text-lg font-black text-white">
                {score} / {questions.length}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Configuration & Category Selection (if quiz not started or finished) */}
      {questions.length === 0 && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-5">
          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 block mb-2">
              ১. পরীক্ষার বিষয় নির্বাচন করুন:
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
              {CATEGORIES.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setCategory(cat)}
                  className={`p-3.5 rounded-2xl text-left border text-sm font-semibold transition-all ${
                    category === cat
                      ? 'bg-emerald-600 text-white border-emerald-600 shadow-md shadow-emerald-700/20'
                      : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:border-emerald-500/40'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-3 border-t border-slate-100 dark:border-slate-800">
            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 block mb-1.5">
                ২. প্রশ্নের সংখ্যা:
              </label>
              <div className="flex gap-2">
                {[5, 10].map((num) => (
                  <button
                    key={num}
                    onClick={() => setQuestionCount(num)}
                    className={`flex-1 py-2.5 rounded-xl text-xs sm:text-sm font-bold border transition-all ${
                      questionCount === num
                        ? 'bg-emerald-600 text-white border-emerald-600'
                        : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    {num} টি প্রশ্ন
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 block mb-1.5">
                ৩. কাঠিন্যের মাত্রা:
              </label>
              <div className="flex gap-2">
                {['সহজ', 'মাঝারি', 'কঠিন'].map((lvl) => (
                  <button
                    key={lvl}
                    onClick={() => setDifficulty(lvl)}
                    className={`flex-1 py-2.5 rounded-xl text-xs sm:text-sm font-bold border transition-all ${
                      difficulty === lvl
                        ? 'bg-emerald-600 text-white border-emerald-600'
                        : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    {lvl}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <button
            onClick={startQuiz}
            disabled={loading}
            className="w-full py-4 rounded-2xl bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-bold text-base shadow-lg shadow-emerald-700/25 flex items-center justify-center gap-2 transition-all"
          >
            {loading ? (
              <>
                <Sparkles size={18} className="animate-spin" />
                <span>দেশ AI প্রশ্নমালা প্রস্তুত করছে...</span>
              </>
            ) : (
              <>
                <GraduationCap size={20} />
                <span>কুইজ শুরু করুন</span>
              </>
            )}
          </button>
        </div>
      )}

      {/* Active Quiz Question */}
      {questions.length > 0 && !quizFinished && currentQ && (
        <div className="space-y-4">
          {/* Progress Bar & Indicators */}
          <div className="flex items-center justify-between text-xs font-semibold text-slate-500 dark:text-slate-400">
            <span>
              প্রশ্ন {BANGLA_NUMERALS[currentIndex] || currentIndex + 1} / {BANGLA_NUMERALS[questions.length - 1] || questions.length}
            </span>
            <span className="text-emerald-600 dark:text-emerald-400 font-bold">
              {currentQ.topic || category}
            </span>
          </div>

          <div className="w-full h-2 rounded-full bg-slate-200 dark:bg-slate-800 overflow-hidden">
            <div
              className="h-full bg-emerald-600 transition-all duration-300"
              style={{ width: `${((answeredCount) / questions.length) * 100}%` }}
            ></div>
          </div>

          {/* Question Card */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
            <h2 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white leading-relaxed">
              {currentQ.question}
            </h2>

            {/* Options List */}
            <div className="space-y-3">
              {currentQ.options.map((opt, optIdx) => {
                const userPicked = answers[currentIndex];
                const isSelected = userPicked === optIdx;
                const isCorrect = currentQ.correctIndex === optIdx;
                const showResult = userPicked !== undefined;

                let optClass = 'bg-slate-50 dark:bg-slate-800/80 border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 hover:border-emerald-500/50';

                if (showResult) {
                  if (isCorrect) {
                    optClass = 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-500 text-emerald-900 dark:text-emerald-200 font-semibold ring-1 ring-emerald-500';
                  } else if (isSelected && !isCorrect) {
                    optClass = 'bg-rose-50 dark:bg-rose-950/60 border-rose-500 text-rose-900 dark:text-rose-200 font-semibold ring-1 ring-rose-500';
                  } else {
                    optClass = 'opacity-50 bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800';
                  }
                }

                return (
                  <button
                    key={optIdx}
                    onClick={() => handleSelectOption(optIdx)}
                    disabled={showResult}
                    className={`w-full p-4 rounded-2xl text-left border flex items-center justify-between transition-all ${optClass}`}
                  >
                    <div className="flex items-center gap-3">
                      <span className="w-7 h-7 rounded-lg bg-white dark:bg-slate-700/60 flex items-center justify-center font-bold text-xs text-slate-700 dark:text-slate-200 shrink-0 shadow-xs">
                        {BANGLA_OPTION_PREFIX[optIdx]}
                      </span>
                      <span className="text-sm sm:text-base">{opt}</span>
                    </div>

                    {showResult && (
                      <div className="shrink-0">
                        {isCorrect && <CheckCircle2 size={20} className="text-emerald-600 dark:text-emerald-400" />}
                        {isSelected && !isCorrect && <XCircle size={20} className="text-rose-600 dark:text-rose-400" />}
                      </div>
                    )}
                  </button>
                );
              })}
            </div>

            {/* Explanation Box */}
            {answers[currentIndex] !== undefined && (
              <div className="p-4 rounded-2xl bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800/50 space-y-1.5">
                <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-800 dark:text-emerald-300">
                  <HelpCircle size={14} />
                  <span>ব্যাখ্যা ও তথ্যকোষ:</span>
                </div>
                <p className="text-xs sm:text-sm text-slate-700 dark:text-slate-200 leading-relaxed">
                  {currentQ.explanation}
                </p>
              </div>
            )}

            {/* Navigation buttons */}
            <div className="flex items-center justify-between pt-4 border-t border-slate-100 dark:border-slate-800">
              <button
                onClick={() => setCurrentIndex((prev) => Math.max(0, prev - 1))}
                disabled={currentIndex === 0}
                className="px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold text-slate-600 dark:text-slate-300 disabled:opacity-30 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              >
                আগের প্রশ্ন
              </button>

              {currentIndex < questions.length - 1 ? (
                <button
                  onClick={() => setCurrentIndex((prev) => prev + 1)}
                  className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm flex items-center gap-1.5 transition-all"
                >
                  <span>পরবর্তী প্রশ্ন</span>
                  <ArrowRight size={14} />
                </button>
              ) : (
                <button
                  onClick={() => setQuizFinished(true)}
                  className="px-5 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs sm:text-sm flex items-center gap-1.5 transition-all shadow-sm"
                >
                  <Trophy size={14} />
                  <span>ফলাফল দেখুন</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Quiz Finished Result Screen */}
      {quizFinished && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-8 border border-slate-200 dark:border-slate-800 shadow-sm text-center space-y-6">
          <div className="w-20 h-20 mx-auto rounded-3xl bg-emerald-100 dark:bg-emerald-950 flex items-center justify-center text-emerald-600 dark:text-emerald-400 shadow-inner">
            <Trophy size={40} />
          </div>

          <div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
              অভিনন্দন! কুইজ সমাপ্ত হয়েছে
            </h2>
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
              বিষয়: <strong className="text-emerald-600 dark:text-emerald-400">{category}</strong>
            </p>
          </div>

          <div className="max-w-xs mx-auto p-5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
            <div className="text-xs font-bold uppercase tracking-wider text-slate-400">আপনার প্রাপ্ত নম্বর</div>
            <div className="text-4xl font-black text-emerald-600 dark:text-emerald-400 mt-1">
              {score} / {questions.length}
            </div>
            <div className="text-xs font-semibold text-slate-500 mt-1">
              সঠিক উত্তরের হার: {Math.round((score / questions.length) * 100)}%
            </div>
          </div>

          <p className="text-sm text-slate-600 dark:text-slate-300 max-w-md mx-auto leading-relaxed">
            {score / questions.length >= 0.8
              ? 'চমৎকার পারফরম্যান্স! আপনার পড়াশোনা ও দখল প্রশংসনীয়।'
              : score / questions.length >= 0.5
              ? 'ভালো হয়েছে! নিয়মিত আরও কিছু অনুশীলন করলে নিশ্চিতভাবেই শতভাগ সঠিক হবে।'
              : 'আরও একটু মনোযোগ প্রয়োজন। ব্যাখ্যাগুলো বারবার পড়ে পুনরায় পরীক্ষা দিন।'}
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
            <button
              onClick={() => {
                setQuizFinished(false);
                setAnswers({});
                setCurrentIndex(0);
              }}
              className="w-full sm:w-auto px-6 py-3 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 font-bold text-sm hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors flex items-center justify-center gap-2"
            >
              <RotateCcw size={16} />
              <span>এই কুইজটি পুনরায় দিন</span>
            </button>
            <button
              onClick={() => {
                setQuestions([]);
                setQuizFinished(false);
              }}
              className="w-full sm:w-auto px-6 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm shadow-md shadow-emerald-700/20 transition-all flex items-center justify-center gap-2"
            >
              <GraduationCap size={16} />
              <span>নতুন বিষয় নির্বাচন করুন</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
