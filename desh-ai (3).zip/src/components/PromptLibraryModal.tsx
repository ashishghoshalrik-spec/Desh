import React, { useState } from 'react';
import { X, Sparkles, Copy, Check, ArrowRight, BookOpen, Briefcase, Code, Sprout, Feather } from 'lucide-react';

interface PromptLibraryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectPrompt: (promptText: string) => void;
}

interface PromptItem {
  category: string;
  title: string;
  prompt: string;
  badge: string;
}

const CURATED_PROMPTS: PromptItem[] = [
  {
    category: 'শিক্ষা ও বিসিএস',
    title: 'সংবিধানের মৌলিক অধিকারসমূহ',
    prompt: 'বাংলাদেশ সংবিধানের তৃতীয় ভাগে বর্ণিত মৌলিক অধিকারগুলো সহজে মনে রাখার পয়েন্ট ও তাৎপর্য বুঝিয়ে দাও।',
    badge: 'বিসিএস',
  },
  {
    category: 'শিক্ষা ও বিসিএস',
    title: 'মুক্তিযুদ্ধের সেক্টর ও সেক্টর কমান্ডারদের তালিকা',
    prompt: '১৯৭১ সালের মহান মুক্তিযুদ্ধের ১১টি সেক্টর, তাদের ভৌগোলিক সীমানা এবং সেক্টর কমান্ডারদের নামের নির্ভুল ছক দাও।',
    badge: 'ইতিহাস',
  },
  {
    category: 'অফিস ও ক্যারিয়ার',
    title: 'বেতন বৃদ্ধির মার্জিত আবেদনপত্র',
    prompt: 'গত দুই বছরে আমার কাজের অগ্রগতি ও অর্জন উল্লেখ করে ম্যানেজমেন্টের কাছে বেতন পর্যালোচনার একটি পেশাদার ইমেইল ড্রাফট করে দাও।',
    badge: 'কর্পোরেট',
  },
  {
    category: 'অফিস ও ক্যারিয়ার',
    title: 'সফটওয়্যার ডেভেলপার পদের জন্য বাংলা/ইংরেজি সিভি সামারি',
    prompt: 'ফুল-স্ট্যাক ওয়েব ডেভেলপার হিসেবে ৩ বছরের অভিজ্ঞতা তুলে ধরে লিঙ্কডইন ও সিভির জন্য একটি শক্তিশালী প্রফেশনাল সামারি লেখো।',
    badge: 'সিভি',
  },
  {
    category: 'সাহিত্য ও সংস্কৃতি',
    title: 'ঋতুভিত্তিক বাংলা কবিতা',
    prompt: 'শরতের কাশফুল, নীল আকাশ আর শিউলি ফুলের ঘ্রাণ নিয়ে আট চরণের ছন্দময় একটি মনমাতানো বাংলা কবিতা রচনা করো।',
    badge: 'কবিতা',
  },
  {
    category: 'সাহিত্য ও সংস্কৃতি',
    title: 'বাংলা নাটকের সংলাপ দৃশ্য',
    prompt: 'গ্রামে ফিরে আসা এক প্রবাসী যুবক এবং তার বৃদ্ধ পিতার স্মৃতিবিজড়িত কথপোকথন নিয়ে একটি আবেগঘন নাট্যদৃশ্যের স্ক্রিপ্ট লেখো।',
    badge: 'নাটক',
  },
  {
    category: 'ফ্রিল্যান্সিং ও টেক',
    title: 'আপওয়ার্ক ও ফাইভার কভার লেটার',
    prompt: 'React ও Node.js ওয়েব অ্যাপ তৈরির জন্য বিদেশি ক্লায়েন্টের প্রজেক্টে বিড করার মতো একটি আকর্ষণীয় আপওয়ার্ক প্রপোজাল তৈরি করো।',
    badge: 'ফ্রিল্যান্সিং',
  },
  {
    category: 'ফ্রিল্যান্সিং ও টেক',
    title: 'পাইথনে বাংলা টেক্সট প্রসেসিং কোড',
    prompt: 'পাইথন দিয়ে বাংলা টেক্সট থেকে স্টপ-ওয়ার্ডস রিমুভ ও ফ্রিকোয়েন্সি কাউন্ট করার সহজ কোড উদাহরণসহ বুঝিয়ে দাও।',
    badge: 'পাইথন',
  },
  {
    category: 'কৃষি ও প্রাত্যহিক জীবন',
    title: 'ছাদবাগানে জৈব বালাইনাশক তৈরি',
    prompt: 'কীটনাশক ছাড়া নিমপাতা, রসুনের নির্যাস দিয়ে কীভাবে ঘরোয়া উপায়ে গাছের পোকা দূর করার নিরাপদ মিশ্রণ বানানো যায়?',
    badge: 'কৃষি',
  },
  {
    category: 'কৃষি ও প্রাত্যহিক জীবন',
    title: 'পদ্মা সেতু ও কর্ণফুলী টানেলের অর্থনৈতিক প্রভাব',
    prompt: 'পদ্মা সেতু এবং বঙ্গবন্ধু টানেল বাংলাদেশের জিডিপি ও যোগাযোগ ব্যবস্থায় কী কী বিপ্লব এনেছে তা বুলেট পয়েন্টে বিশ্লেষণ করো।',
    badge: 'অর্থনীতি',
  },
];

export const PromptLibraryModal: React.FC<PromptLibraryModalProps> = ({
  isOpen,
  onClose,
  onSelectPrompt,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('সকল');
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  if (!isOpen) return null;

  const categories = ['সকল', 'শিক্ষা ও বিসিএস', 'অফিস ও ক্যারিয়ার', 'সাহিত্য ও সংস্কৃতি', 'ফ্রিল্যান্সিং ও টেক', 'কৃষি ও প্রাত্যহিক জীবন'];

  const filtered = selectedCategory === 'সকল'
    ? CURATED_PROMPTS
    : CURATED_PROMPTS.filter((p) => p.category === selectedCategory);

  const handleCopy = (e: React.MouseEvent, text: string, idx: number) => {
    e.stopPropagation();
    navigator.clipboard.writeText(text);
    setCopiedIndex(idx);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/60 backdrop-blur-sm animate-fade-in">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-3xl max-h-[85vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="p-5 sm:p-6 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-100 dark:bg-emerald-950 flex items-center justify-center text-emerald-600 dark:text-emerald-400">
              <Sparkles size={20} />
            </div>
            <div>
              <h2 className="font-extrabold text-lg sm:text-xl text-slate-900 dark:text-white">
                দেশ AI প্রম্পট গ্যালারি
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                পছন্দের প্রম্পটে ক্লিক করে সরাসরি চ্যাটে নিয়ে যান
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        {/* Categories Bar */}
        <div className="px-5 py-3 border-b border-slate-100 dark:border-slate-800 flex items-center gap-2 overflow-x-auto no-scrollbar">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                selectedCategory === cat
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Prompts Grid */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-3">
          {filtered.map((item, index) => (
            <div
              key={index}
              onClick={() => {
                onSelectPrompt(item.prompt);
                onClose();
              }}
              className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/80 hover:border-emerald-500/60 hover:bg-emerald-50/20 dark:hover:bg-emerald-950/20 cursor-pointer transition-all group flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3"
            >
              <div className="flex-1 space-y-1">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-slate-900 dark:text-white group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors">
                    {item.title}
                  </span>
                  <span className="text-[10px] px-1.5 py-0.2 rounded bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 font-semibold">
                    {item.badge}
                  </span>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-300 line-clamp-2 leading-relaxed">
                  {item.prompt}
                </p>
              </div>

              <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
                <button
                  type="button"
                  onClick={(e) => handleCopy(e, item.prompt, index)}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-200/60 dark:hover:bg-slate-700 transition-colors"
                  title="কপি করুন"
                >
                  {copiedIndex === index ? <Check size={15} className="text-emerald-500" /> : <Copy size={15} />}
                </button>
                <div className="flex items-center gap-1 text-xs font-bold text-emerald-600 dark:text-emerald-400 group-hover:translate-x-1 transition-transform">
                  <span>ব্যবহার করুন</span>
                  <ArrowRight size={13} />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
