import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { ChatTab } from './components/ChatTab';
import { CallTab } from './components/CallTab';
import { IpPhoneCall } from './components/IpPhoneCall';
import { WriterTab } from './components/WriterTab';
import { TranslatorTab } from './components/TranslatorTab';
import { QuizTab } from './components/QuizTab';
import { PromptLibraryModal } from './components/PromptLibraryModal';
import { ActiveTab } from './types';
import { Heart, Sparkles, ShieldCheck } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('call');
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    const saved = localStorage.getItem('desh_theme');
    if (saved) return saved === 'dark';
    return window.matchMedia('(prefers-color-scheme: dark)').matches;
  });
  const [isPromptsOpen, setIsPromptsOpen] = useState(false);
  const [injectedPrompt, setInjectedPrompt] = useState<string | null>(null);

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('desh_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('desh_theme', 'light');
    }
  }, [darkMode]);

  const handleSelectPrompt = (prompt: string) => {
    setInjectedPrompt(prompt);
    setActiveTab('chat');
    // We can also trigger a custom event or let ChatTab read it
    const event = new CustomEvent('desh:insert-prompt', { detail: { prompt } });
    window.dispatchEvent(event);
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors flex flex-col font-sans">
      {/* Sticky Header Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        darkMode={darkMode}
        setDarkMode={setDarkMode}
        onOpenPromptsModal={() => setIsPromptsOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        {activeTab === 'call' && <CallTab onNavigateToIpPhone={() => setActiveTab('ipphone')} />}
        {activeTab === 'ipphone' && <IpPhoneCall />}
        {activeTab === 'chat' && <ChatTab />}
        {activeTab === 'writer' && <WriterTab />}
        {activeTab === 'translator' && <TranslatorTab />}
        {activeTab === 'quiz' && <QuizTab />}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-200/80 dark:border-slate-800/80 py-4 px-4 bg-white/50 dark:bg-slate-950/50 backdrop-blur-xs text-xs text-slate-500 dark:text-slate-400">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2.5">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
            <span className="font-semibold text-slate-700 dark:text-slate-300">
              দেশ AI (Desh AI)
            </span>
            <span>—</span>
            <span>বাংলার নিজস্ব আধুনিক কৃত্রিম বুদ্ধিমত্তা প্ল্যাটফর্ম</span>
          </div>

          <div className="flex items-center gap-4 text-[11px]">
            <span className="flex items-center gap-1">
              <ShieldCheck size={13} className="text-emerald-500" />
              নিরাপদ ও নির্ভরযোগ্য
            </span>
            <span className="flex items-center gap-1">
              ভালোবাসার সাথে নির্মিত <Heart size={12} className="text-rose-500 fill-rose-500" />
            </span>
          </div>
        </div>
      </footer>

      {/* Prompts Library Modal */}
      <PromptLibraryModal
        isOpen={isPromptsOpen}
        onClose={() => setIsPromptsOpen(false)}
        onSelectPrompt={handleSelectPrompt}
      />
    </div>
  );
}
