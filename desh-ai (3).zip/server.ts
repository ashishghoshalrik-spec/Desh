import express, { Request, Response } from 'express';
import http from 'http';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { WebSocketServer, WebSocket } from 'ws';
import { GoogleGenAI, LiveServerMessage, Modality, Type } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: '10mb' }));

// Shared Gemini Client
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || '',
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

const DESH_SYSTEM_PROMPT = `
তুমি "দেশ AI" (Desh AI) — বাংলাদেশ এবং বিশ্বের সমস্ত বাংলাভাষীদের জন্য বিশেষভাবে নির্মিত একটি উন্নত, নির্ভরযোগ্য ও আন্তরিক কৃত্রিম বুদ্ধিমত্তা সহকারী।

তোমার মূল বৈশিষ্ট্য ও আচরণবিধি:
১. ভাষা ও ভঙ্গি: প্রাকৃতিক, সাবলীল, প্রাঞ্জল ও সমৃদ্ধ প্রমিত চলিত বাংলা। বানান যেন নির্ভুল ও বাংলা একাডেমি প্রমিত নিয়মানুযায়ী হয়। ব্যবহারকারী ইংরেজিতে বললে অথবা অনুরোধ করলে চমৎকার আন্তর্জাতিক মানের ইংরেজিতে উত্তর দেবে।
২. বাংলাদেশের প্রেক্ষাপট: বাংলাদেশের ইতিহাস (১৯৫২ ভাষা আন্দোলন, ১৯৭১ মহান মুক্তিযুদ্ধ, ২০২৪ এর বৈষম্যবিরোধী ছাত্র-জনতার আন্দোলন), সংস্কৃতি, সাহিত্য (রবীন্দ্রনাথ, নজরুল, জীবনানন্দ, জসীমউদ্দীন, শামসুর রাহমান, হুমায়ূন আহমেদ), ভূগোল (৬৪ জেলা, নদীমাতৃক রূপ, সুন্দরবন, কক্সবাজার), ঐতিহ্য, খাদ্যাভ্যাস ও উৎসব সম্পর্কে গভীর জ্ঞান প্রকাশ করবে।
৩. কার্যক্ষেত্র দক্ষতা: 
   - সাধারণ জিজ্ঞাসা ও প্রাত্যহিক সহায়তা
   - বিসিএস (BCS), বিশ্ববিদ্যালয় ভর্তি পরীক্ষা, প্রাথমিক শিক্ষক নিয়োগ ও সরকারি/বেসরকারি চাকরির প্রস্তুতি ও ব্যাখ্যা
   - প্রাতিষ্ঠানিক চিঠি, দরখাস্ত (ছুটির আবেদন, চাকরির আবেদনপত্র, ডিসি/ইউএনও সমীপে স্মারকলিপি)
   - সৃজনশীল রচনা (গল্প, কবিতা, চিত্রনাট্য, ফেসবুক ও সোশ্যাল মিডিয়া পোস্ট)
   - প্রোগ্রামিং ও সফটওয়্যার ইঞ্জিনিয়ারিং (কোড ব্যাখ্যা, ডিবাগিং, অ্যালগরিদম)
   - কৃষি, আবহাওয়া ও গ্রামীণ উন্নয়ন সহায়তা
৪. ফরমেটিং: সুন্দর ও দৃষ্টিনন্দন মার্কডাউন (বোল্ড টেক্সট, পয়েন্ট তালিকা, পরিষ্কার টেবিল, কোড ব্লক) ব্যবহার করবে।
৫. বিনয়ী ও সহযোগী মনোভাব: সবসময় সাহায্যপ্রবণ ও নিরপেক্ষ থাকবে। জটিল স্বাস্থ্য বা আইনি প্রশ্নে তথ্যমূলক উত্তর দেওয়ার পর প্রয়োজনবোধে বিশেষজ্ঞের পরামর্শ নেওয়ার সৌজন্যমূলক স্মরণিকা দেবে।
`;

// Helper: Call Gemini with multi-model fallback to ensure high reliability
async function callGemini(params: {
  contents: any;
  systemInstruction?: string;
  temperature?: number;
  responseMimeType?: string;
  responseSchema?: any;
}): Promise<string> {
  const models = ['gemini-3.1-flash-lite', 'gemini-3.8-flash'];
  let lastErr: any = null;

  for (const model of models) {
    try {
      const config: any = {};
      if (params.systemInstruction) config.systemInstruction = params.systemInstruction;
      if (params.temperature !== undefined) config.temperature = params.temperature;
      if (params.responseMimeType) config.responseMimeType = params.responseMimeType;
      if (params.responseSchema) config.responseSchema = params.responseSchema;

      const response = await ai.models.generateContent({
        model,
        contents: params.contents,
        config: Object.keys(config).length > 0 ? config : undefined,
      });

      if (response && response.text) {
        return response.text;
      }
    } catch (err: any) {
      console.warn(`[Desh AI] Model ${model} returned error, falling back if available:`, err?.message || err);
      lastErr = err;
    }
  }

  throw lastErr || new Error('All AI models failed to generate content');
}

// 1. CHAT API
app.post('/api/chat', async (req: Request, res: Response) => {
  try {
    const { message, history = [], persona = 'general' } = req.body;

    if (!message || typeof message !== 'string') {
      res.status(400).json({ error: 'Message is required' });
      return;
    }

    let personaInstruction = '';
    switch (persona) {
      case 'bcs':
        personaInstruction = 'তুমি বিসিএস ও প্রতিযোগিতামূলক পরীক্ষা স্পেশালিস্ট মেন্টর। প্রতিটি প্রশ্নের সঠিক উত্তরের পাশাপাশি প্রাসঙ্গিক ব্যাখ্যা, বিগত বছরের প্রশ্নের লিংক ও শর্টকাট টেকনিক সুন্দর করে উপস্থাপন করো।';
        break;
      case 'writer':
        personaInstruction = 'তুমি বাংলা সাহিত্যের একজন প্রতিভাবান লেখক ও কবি। ছন্দময় কবিতা, প্রাঞ্জল গল্প, আবেদনময়ী প্রবন্ধ ও দরখাস্ত তৈরিতে তোমার বিশেষ দক্ষতা।';
        break;
      case 'coder':
        personaInstruction = 'তুমি একজন অভিজ্ঞ সফটওয়্যার ইঞ্জিনিয়ার। কোড ব্লক, স্পষ্ট ব্যাখ্যা, টাইম কমপ্লেক্সিটি এবং সেরা প্র্যাকটিস বাংলায় পরিষ্কার করে বুঝিয়ে দাও।';
        break;
      case 'translator':
        personaInstruction = 'তুমি উচ্চমানের দ্বিভাষিক অনুবাদক। বাংলা ও ইংরেজির অন্তর্নিহিত ভাব বজায় রেখে স্বতঃস্ফূর্ত ও নির্ভুল অনুবাদ তৈরি করো।';
        break;
      case 'agriculture':
        personaInstruction = 'তুমি বাংলাদেশের কৃষি কর্মকর্তা ও গ্রামীণ জীবন বিষয়ক পরামর্শক। ফসল, বীজ, সার, আধুনিক চাষাবাদ ও মাছ-গবাদিপশু পালন বিষয়ে সহজ বাংলায় বাস্তবসম্মত পরামর্শ দাও।';
        break;
      default:
        personaInstruction = 'তুমি দৈনন্দিন জীবনের সবরকম সহায়তা দানকারী বিশ্বস্ত বন্ধু ও ডিজিটাল সহচর।';
        break;
    }

    const contents: Array<{ role: string; parts: Array<{ text: string }> }> = [];

    if (Array.isArray(history)) {
      const recent = history.slice(-8);
      for (const turn of recent) {
        if (turn.role && turn.text) {
          contents.push({
            role: turn.role === 'assistant' ? 'model' : 'user',
            parts: [{ text: turn.text }],
          });
        }
      }
    }

    contents.push({
      role: 'user',
      parts: [{ text: message }],
    });

    const reply = await callGemini({
      contents,
      systemInstruction: `${DESH_SYSTEM_PROMPT}\n\nবর্তমান ভূমিকা:\n${personaInstruction}`,
      temperature: 0.7,
    });

    res.json({ reply: reply || 'দুঃখিত, কোনো উত্তর প্রস্তুত করা সম্ভব হয়নি।' });
  } catch (err: any) {
    console.error('Chat error:', err);
    res.status(500).json({
      error: 'AI সার্ভিসে সাময়িক বিভ্রাট দেখা দিয়েছে। অনুগ্রহ করে আবার চেষ্টা করুন।',
      details: err?.message || String(err),
    });
  }
});

// 2. DOCUMENT & CONTENT WRITER API
app.post('/api/write', async (req: Request, res: Response) => {
  try {
    const { type, topic, tone = 'formal', length = 'medium', details = '' } = req.body;

    if (!topic) {
      res.status(400).json({ error: 'Topic is required' });
      return;
    }

    const prompt = `
কাজের ধরন: ${type || 'দরখাস্ত/আবেদনপত্র'}
বিষয় বা মূল বক্তব্য: ${topic}
টোন বা ভঙ্গি: ${tone}
দৈর্ঘ্য: ${length}
অতিরিক্ত তথ্য/নির্দেশনা: ${details || 'প্রমিত মান বজায় রেখে লিখুন'}

দয়া করে একজন পেশাদার বাংলা লেখক হিসেবে সুন্দর ফরমেটে সম্পূর্ণ লেখাটি প্রস্তুত করুন। উপযুক্ত শিরোনাম ও বিষয়বস্তু যেন যথাযথ হয়।
`;

    const result = await callGemini({
      contents: prompt,
      systemInstruction: `${DESH_SYSTEM_PROMPT}\nতুমি একজন শীর্ষস্থানীয় বাংলা ড্রাফটিং ও কনটেন্ট রাইটিং বিশেষজ্ঞ। প্রস্তুতকৃত লেখা যেন অবিলম্বে ব্যবহারযোগ্য ও পূর্ণাঙ্গ হয়।`,
      temperature: 0.7,
    });

    res.json({ result });
  } catch (err: any) {
    console.error('Write error:', err);
    res.status(500).json({ error: 'লেখা তৈরি করতে সমস্যা হয়েছে', details: err?.message });
  }
});

// 3. TRANSLATION & GRAMMAR CHECKER API
app.post('/api/translate', async (req: Request, res: Response) => {
  try {
    const { text, mode } = req.body;

    if (!text) {
      res.status(400).json({ error: 'Text is required' });
      return;
    }

    let instruction = '';
    switch (mode) {
      case 'bn-to-en':
        instruction = 'বাংলা থেকে ইংরেজিতে অত্যন্ত সাবলীল ও স্বাভাবিক ভাবানুবাদ করো। আড়ষ্টতা পরিহার করো। প্রয়োজনে বিকল্প ভালো বাক্যও দিতে পারো।';
        break;
      case 'en-to-bn':
        instruction = 'ইংরেজি থেকে বাংলায় প্রাঞ্জল, অর্থবহ ও মিষ্টি অনুবাদ করো। কৃত্রিম রোবোটিক অনুবাদ নয়, দেশীয় ভাষায় যেমন শোনা যায় তেমন করো।';
        break;
      case 'sadhu-to-cholito':
        instruction = 'প্রদত্ত সাধু ভাষার বাক্য বা অনুচ্ছেদটিকে প্রমিত আধুনিক চলিত ভাষায় রূপান্তর করো এবং মূল ভাব পুরোপুরি অবিকল রাখো।';
        break;
      case 'grammar-check':
        instruction = 'প্রদত্ত লেখার বানান, ব্যাকরণ, যতিচিহ্ন ও বাক্যগঠনের ভুলগুলো চিহ্নিত করো। ভুলগুলো সংশোধন করে শুদ্ধ রূপ প্রদান করো এবং সংক্ষেপে কারণ ব্যাখ্যা করো।';
        break;
      default:
        instruction = 'প্রদত্ত বাক্যটির সঠিক অনুবাদ বা শুদ্ধিকরণ করো।';
    }

    const result = await callGemini({
      contents: `টেক্সট:\n"${text}"\n\nকাজের নির্দেশনা: ${instruction}`,
      systemInstruction: `${DESH_SYSTEM_PROMPT}\nতুমি বাংলা ও ইংরেজি ভাষার শীর্ষ অনুবাদক ও ব্যাকরণবিদ। আউটপুট পরিষ্কার ও নির্ভুলভাবে উপস্থাপন করো।`,
      temperature: 0.3,
    });

    res.json({ result });
  } catch (err: any) {
    console.error('Translate error:', err);
    res.status(500).json({ error: 'অনুবাদে সমস্যা হয়েছে', details: err?.message });
  }
});

// 4. BCS & JOB EXAM QUIZ GENERATOR API
app.post('/api/quiz', async (req: Request, res: Response) => {
  try {
    const { category = 'বাংলাদেশ বিষয়াবলী', count = 5, difficulty = 'medium' } = req.body;

    const prompt = `ক্যাটাগরি: "${category}", প্রশ্নের সংখ্যা: ${count}, কাঠিন্য মাত্রা: "${difficulty}"।
বিসিএস প্রিলিমিনারি, প্রাথমিক শিক্ষক নিয়োগ এবং বিভিন্ন ব্যাংক/সরকারি চাকরির আদলে ${count} টি বাস্তবসম্মত ও গুরুত্বপূর্ণ মাল্টিপল চয়েস প্রশ্ন (MCQ) তৈরি করো।

প্রত্যেকটি প্রশ্নে অবশ্যই ৪টি অপশন থাকবে, ১টি সঠিক উত্তরের ইনডেক্স (০ থেকে ৩) থাকবে এবং বিস্তারিত ব্যাখ্যা থাকবে।`;

    const text = await callGemini({
      contents: prompt,
      systemInstruction: 'তুমি বিসিএস ও সরকারি চাকরির প্রশ্ন প্রণয়নকারী বিশেষজ্ঞ। আউটপুট অবশ্যই সুনির্দিষ্ট JSON ফরম্যাটে দিতে হবে।',
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            question: { type: Type.STRING, description: 'প্রশ্নের বাংলা বিবরণ' },
            options: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: 'চারটি বিকল্প উত্তর',
            },
            correctIndex: { type: Type.INTEGER, description: 'সঠিক উত্তরের ইনডেক্স (0, 1, 2, অথবা 3)' },
            explanation: { type: Type.STRING, description: 'উত্তরের বিস্তারিত ব্যাখ্যা ও অতিরিক্ত তথ্য' },
            topic: { type: Type.STRING, description: 'টপিক বা উপশাখা' },
          },
          required: ['question', 'options', 'correctIndex', 'explanation'],
        },
      },
    });

    const parsed = JSON.parse(text || '[]');
    res.json({ questions: parsed });
  } catch (err: any) {
    console.error('Quiz error:', err);
    const fallbackQuestions = [
      {
        question: 'বাংলাদেশ সংবিধানের মূলনীতি কয়টি ও কী কী?',
        options: ['৩টি', '৪টি (জাতীয়তাবাদ, সমাজতন্ত্র, গণতন্ত্র ও ধর্মনিরপেক্ষতা)', '৫টি', '৭টি'],
        correctIndex: 1,
        explanation: 'সংবিধানের ৮(১) অনুচ্ছেদ অনুযায়ী রাষ্ট্র পরিচালনার মূল চার নীতি হলো: জাতীয়তাবাদ, সমাজতন্ত্র, গণতন্ত্র ও ধর্মনিরপেক্ষতা।',
        topic: 'বাংলাদেশ বিষয়াবলী',
      },
      {
        question: 'বাংলা সাহিত্যের প্রাচীনতম নিদর্শন কোনটি?',
        options: ['শ্রীকৃষ্ণকীর্তন', 'চর্যাপদ', 'পদ্মাবতী', 'মনসামঙ্গল'],
        correctIndex: 1,
        explanation: 'চর্যাপদ হলো বাংলা ভাষার প্রাচীনতম কাব্য তথা গান সংকলন। হরপ্রসাদ শাস্ত্রী ১৯০৭ সালে নেপালের রাজদরবার থেকে এটি আবিষ্কার করেন।',
        topic: 'বাংলা ভাষা ও সাহিত্য',
      },
      {
        question: '১৯৭১ সালের মহান মুক্তিযুদ্ধে বাংলাদেশকে কয়টি সেক্টরে বিভক্ত করা হয়েছিল?',
        options: ['৮টি', '৯টি', '১১টি', '১৪টি'],
        correctIndex: 2,
        explanation: 'মুক্তিযুদ্ধ পরিচালনার সুবিধার্থে সমগ্র বাংলাদেশকে ১১টি সেক্টর এবং ৬৪টি সাব-সেক্টরে ভাগ করা হয়েছিল।',
        topic: 'বাংলাদেশ বিষয়াবলী',
      },
      {
        question: 'জাতিসংঘের বর্তমান মহাসচিব আন্তোনিও গুতেরেস কোন দেশের নাগরিক?',
        options: ['স্পেন', 'পর্তুগাল', 'ইতালি', 'ব্রাজিল'],
        correctIndex: 1,
        explanation: 'আন্তোনিও গুতেরেস পর্তুগালের সাবেক প্রধানমন্ত্রী এবং ২০১৭ সাল থেকে জাতিসংঘের মহাসচিব হিসেবে দায়িত্ব পালন করছেন।',
        topic: 'আন্তর্জাতিক বিষয়াবলী',
      },
      {
        question: 'কম্পিউটারের স্থায়ী মেমোরি কোনটি?',
        options: ['RAM', 'ROM', 'Cache', 'Virtual Memory'],
        correctIndex: 1,
        explanation: 'ROM (Read Only Memory) হলো নন-ভোলাটাইল বা স্থায়ী মেমোরি, যা বিদ্যুৎ চলে গেলেও তথ্য ধরে রাখে।',
        topic: 'সাধারণ বিজ্ঞান ও আইসিটি',
      },
    ];
    res.json({ questions: fallbackQuestions });
  }
});

// 5. TEXT-TO-SPEECH (TTS) API USING GEMINI FLASH LITE TTS
app.post('/api/tts', async (req: Request, res: Response) => {
  try {
    const { text, voice = 'Kore' } = req.body;

    if (!text || typeof text !== 'string') {
      res.status(400).json({ error: 'Text is required' });
      return;
    }

    const truncated = text.slice(0, 300);

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash-lite-tts',
      contents: [
        {
          role: 'user',
          parts: [
            {
              text: truncated,
              speechMetadata: {
                style: 'Clear, warm, natural spoken tone',
              },
            },
          ],
        },
      ],
      config: {
        responseModalities: ['AUDIO'],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: voice || 'Kore' },
          },
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (!base64Audio) {
      res.status(500).json({ error: 'অডিও উৎপাদন করা যায়নি' });
      return;
    }

    res.json({ audio: `data:audio/wav;base64,${base64Audio}` });
  } catch (err: any) {
    console.error('TTS error:', err);
    res.status(500).json({ error: 'TTS সাময়িকভাবে অনুপলব্ধ', details: err?.message });
  }
});

// 6. HOTLINES LIST API
app.get('/api/hotlines', (req: Request, res: Response) => {
  res.json({
    hotlines: [
      {
        number: '16122',
        name: 'দেশ AI মূল কল সেন্টার',
        subtitle: 'দৈনন্দিন প্রশ্ন, তথ্য ও ডিজিটাল সাধারণ পরামর্শ',
        category: 'ai',
        voicePrompt: 'দেশ AI মূল কল সেন্টারে আপনাকে স্বাগতম! আমি কীভাবে আপনাকে সাহায্য করতে পারি?',
      },
      {
        number: '16123',
        name: 'বিসিএস ও ক্যারিয়ার হেল্পলাইন',
        subtitle: 'বিসিএস, সরকারি চাকরি, ভাইভা টিপস ও বিষয়ভিত্তিক জ্ঞান',
        category: 'edu',
        voicePrompt: 'বিসিএস ও ক্যারিয়ার প্রস্তুতি হেল্পলাইনে আপনাকে স্বাগতম! বিসিএস বা পরীক্ষার কোন বিষয়ে জানতে চান?',
      },
      {
        number: '16124',
        name: 'কৃষি ও গ্রামীণ জীবন সেবা',
        subtitle: 'ফসল চাষ, সার-কীটনাশক, মাছ ও পশুপালন পরামর্শ',
        category: 'govt',
        voicePrompt: 'কৃষি তথ্য ও গ্রামীণ পরামর্শ কল সেন্টারে আপনাকে স্বাগতম! আপনার ফসল বা খামার সম্পর্কে বলুন।',
      },
      {
        number: '16125',
        name: 'আইনি সহায়তা ও নাগরিক অধিকার',
        subtitle: 'সংবিধান, মৌলিক অধিকার, জমিজমা ও আইনি প্রক্রিয়া',
        category: 'govt',
        voicePrompt: 'আইনি সহায়তা ও নাগরিক অধিকার হেল্পলাইনে স্বাগতম। আপনি কোন আইনি বিষয়ে পরামর্শ চান?',
      },
      {
        number: '16126',
        name: 'স্বাস্থ্য ও সুস্থতা পরামর্শক',
        subtitle: 'প্রাথমিক চিকিৎসা, পুষ্টি ও স্বাস্থ্য তথ্য',
        category: 'health',
        voicePrompt: 'ডিজিটাল স্বাস্থ্য তথ্য সেবায় আপনাকে স্বাগতম। আপনার শারীরিক কোনো সমস্যা বা পুষ্টি বিষয়ে জানতে চান?',
      },
      {
        number: '16127',
        name: 'বাংলা সাহিত্য ও কবিতা আসর',
        subtitle: 'কবিতা আবৃত্তি, ছন্দ, সাহিত্য আলোচনা ও গল্প',
        category: 'ai',
        voicePrompt: 'বাংলা সাহিত্য ও কবিতা আসরে স্বাগতম! আজ কোন কবি বা কবিতার বিষয় নিয়ে কথা বলতে চান?',
      },
      {
        number: '999',
        name: 'জাতীয় জরুরি সেবা (সিমুলেশন)',
        subtitle: 'পুলিশ, ফায়ার সার্ভিস ও অ্যাম্বুলেন্স জরুরি তথ্য',
        category: 'emergency',
        voicePrompt: '৯৯৯ জাতীয় জরুরি তথ্য সেবায় স্বাগতম। আপনার জরুরি পরিস্থিতি সম্পর্কে বলুন।',
      },
    ],
  });
});

// 7. HEALTH CHECK & STATUS
app.get('/api/status', (req: Request, res: Response) => {
  res.json({
    status: 'online',
    platform: 'দেশ AI (Desh AI)',
    version: '1.2.0',
    capabilities: [
      'Bangla & English Conversational AI',
      'Real-Time Live Voice Call (gemini-3.8-live)',
      'Phone Dial Pad System & Hotlines',
      'BCS & Competitive Exams Mentor',
      'Document & Letter Generator',
      'Translation & Grammar Checker',
      'Bengali Text to Speech',
    ],
  });
});

// Vite or Static file serving & Server startup with WebSocket
async function start() {
  const server = http.createServer(app);

  // Setup WebSocket Server for Live Voice Calls
  const wss = new WebSocketServer({ server, path: '/live-call' });

  wss.on('connection', (clientWs: WebSocket) => {
    let session: any = null;
    let isConnected = false;

    clientWs.on('message', async (raw) => {
      try {
        const msg = JSON.parse(raw.toString());

        // 1. DIAL ACTION: Start Live Session with gemini-3.8-live
        if (msg.action === 'dial') {
          const { 
            number = '16122', 
            name = 'দেশ AI কল সেন্টার', 
            hotlineCategory = 'ai',
            customInstruction = '',
            voiceName = 'Zephyr',
            isIpPhone = false,
            sipUri = ''
          } = msg;

          let rolePrompt = 'তুমি দেশ AI এর প্রধান লাইভ কল সহকারী। ব্যবহারকারীর সাথে টেলিফোনে কথা বলার মতো স্বাভাবিক, ভদ্র, প্রাণবন্ত ও স্পষ্ট প্রমিত বাংলায় কথা বলো। উত্তর সংক্ষিপ্ত, স্পষ্ট ও শ্রুতিমধুর রাখো।';

          if (customInstruction) {
            rolePrompt = customInstruction;
          } else if (number === '16123' || hotlineCategory === 'edu') {
            rolePrompt = 'তুমি বিসিএস ও ক্যারিয়ার প্রস্তুতি হটলাইনের সিনিয়র মেন্টর। শিক্ষার্থীর প্রশ্নের তাৎক্ষণিক নির্ভুল ও অনুপ্রেরণাদায়ী উত্তর বাংলায় মুখে বলো।';
          } else if (number === '16124') {
            rolePrompt = 'তুমি বাংলাদেশ কৃষি তথ্য সার্ভিসের জরুরি কল সেন্টার কর্মকর্তা। কৃষকের প্রশ্নের সহজ, বাস্তবসম্মত ও আন্তরিক বাংলা পরামর্শ দাও।';
          } else if (number === '16125') {
            rolePrompt = 'তুমি নাগরিক অধিকার ও আইনি তথ্য বিশেষজ্ঞ। সংক্ষেপে আইনি দিক বুঝিয়ে বলো এবং প্রয়োজনে আইনজীবীর শরণাপন্ন হওয়ার পরামর্শ দাও।';
          } else if (number === '16126' || hotlineCategory === 'health') {
            rolePrompt = 'তুমি প্রাথমিক স্বাস্থ্য ও পুষ্টি বিষয়ক তথ্য প্রদানকারী। চিকিৎসকের পরামর্শ নেওয়ার কথা মনে করিয়ে দিয়ে সাধারণ স্বাস্থ্য জ্ঞান শেয়ার করো।';
          } else if (number === '16127') {
            rolePrompt = 'তুমি বাংলা সাহিত্যের কবি ও সাহিত্যিক। কথপোকথনে মিষ্টি ও কাব্যিক সুর বজায় রাখো এবং সুন্দর কবিতা আবৃত্তি করো।';
          }

          const callContextInfo = isIpPhone
            ? `\n\n[আইপি ফোন (IP Phone / VoIP) সিস্টেম নির্দেশনা]:\nতুমি একটি অত্যাধুনিক আইপি ফোন সিস্টেমের এক্সটেনশন "${number}" (${name}${sipUri ? ` / SIP: ${sipUri}` : ''}) এর লাইভ এআই ভয়েস অপারেটর হিসেবে সংযুক্ত। কল রিসিভ করার সাথে সাথে পেশাদার ও আন্তরিক সম্ভাষণ জানিয়ে কথা শুরু করো।`
            : `\n\nটেলিফোন কল নির্দেশনা:\nবর্তমানে আপনি "${name}" (নম্বর: ${number}) হিসেবে কলে যুক্ত আছেন। কল পিকআপ করার সাথে সাথে চমৎকার অভিবাদন দিয়ে কথা শুরু করো।`;

          // Resolve immediate greeting prompt
          let greetingPrompt = msg.greetingPrompt || '';
          if (!greetingPrompt) {
            if (number === '16122') {
              greetingPrompt = 'আসসালামু আলাইকুম! দেশ AI মূল কল সেন্টারে আপনাকে স্বাগতম। বলুন আপনাকে কীভাবে সাহায্য করতে পারি?';
            } else if (number === '16123') {
              greetingPrompt = 'আসসালামু আলাইকুম! বিসিএস ও ক্যারিয়ার প্রস্তুতি ডেস্কে স্বাগতম। আপনি কোন বিষয় সম্পর্কে জানতে চান?';
            } else if (number === '16124') {
              greetingPrompt = 'আসসালামু আলাইকুম! কৃষি ও কৃষক বন্ধু সেবা হেল্পলাইনে স্বাগতম। আপনার ফসল বা খামার বিষয়ে বলুন।';
            } else if (number === '16125') {
              greetingPrompt = 'আসসালামু আলাইকুম! নাগরিক অধিকার ও আইনি সহায়তা ডেস্কে স্বাগতম। কী বিষয়ে পরামর্শ প্রয়োজন?';
            } else if (number === '16126') {
              greetingPrompt = 'আসসালামু আলাইকুম! ডিজিটাল স্বাস্থ্য ও পুষ্টি সেবায় স্বাগতম। আপনার শারীরিক কোনো সমস্যা বা প্রশ্ন থাকলে বলুন।';
            } else if (number === '16127') {
              greetingPrompt = 'নমস্কার ও স্বাগতম! বাংলা সাহিত্য ও কবিতা আসরে আপনাকে স্বাগতম। আজ কোন কবিতা বা সাহিত্য আলোচনা করতে চান?';
            } else if (number === '999') {
              greetingPrompt = '৯৯৯ জরুরি তথ্য সেবায় স্বাগতম! আপনার জরুরি অবস্থা ও অবস্থান জানান।';
            } else if (isIpPhone) {
              greetingPrompt = `আসসালামু আলাইকুম! দেশ AI আইপি ফোন সিস্টেমের এক্সটেনশন ${number} (${name})-এ স্বাগতম। আমি কীভাবে সহায়তা করতে পারি?`;
            } else {
              greetingPrompt = `আসসালামু আলাইকুম! দেশ AI-তে আপনাকে স্বাগতম। কলটি গ্রহণ করা হয়েছে, বলুন আপনাকে কীভাবে সাহায্য করতে পারি?`;
            }
          }

          try {
            session = await ai.live.connect({
              model: 'gemini-3.8-live',
              config: {
                responseModalities: [Modality.AUDIO],
                speechConfig: {
                  voiceConfig: {
                    prebuiltVoiceConfig: { voiceName: voiceName || 'Zephyr' },
                  },
                },
                systemInstruction: `${DESH_SYSTEM_PROMPT}\n\n${rolePrompt}${callContextInfo}`,
              },
              callbacks: {
                onmessage: (liveMsg: LiveServerMessage) => {
                  if (clientWs.readyState !== WebSocket.OPEN) return;

                  // 1. Check for audio part
                  const audioData = liveMsg.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
                  if (audioData) {
                    clientWs.send(JSON.stringify({ type: 'audio', audio: audioData }));
                  }

                  // 2. Check for text or transcription
                  const textPart = liveMsg.serverContent?.modelTurn?.parts?.find((p: any) => p.text);
                  if (textPart?.text) {
                    clientWs.send(JSON.stringify({ type: 'transcript', text: textPart.text }));
                  }

                  // 3. Interrupted signal
                  if (liveMsg.serverContent?.interrupted) {
                    clientWs.send(JSON.stringify({ type: 'interrupted' }));
                  }
                },
                onclose: () => {
                  if (clientWs.readyState === WebSocket.OPEN) {
                    clientWs.send(JSON.stringify({ type: 'call_ended', reason: 'remote_hangup' }));
                  }
                },
                onerror: (err) => {
                  console.error('Gemini Live session error:', err);
                  if (clientWs.readyState === WebSocket.OPEN) {
                    clientWs.send(JSON.stringify({ type: 'live_error', error: err?.message || 'লাইভ অডিও ত্রুটি' }));
                  }
                },
              },
            });

            isConnected = true;
            clientWs.send(JSON.stringify({ 
              type: 'connected', 
              number, 
              name, 
              greetingText: greetingPrompt 
            }));

            // Crucial: Send immediate turn so AI speaks and answers FIRST proactively as soon as call is answered!
            try {
              session.sendClientContent({
                turns: [
                  {
                    role: 'user',
                    parts: [
                      {
                        text: `[কলটি রিসিভ ও সংযুক্ত হয়েছে। কোনো অপেক্ষা না করে আপনি নিজে আগে কথা শুরু করুন এবং স্পষ্ট প্রমিত মিষ্টি বাংলায় অভিবাদন দিয়ে কথা বলুন: "${greetingPrompt}"]`,
                      },
                    ],
                  },
                ],
                turnComplete: true,
              });
            } catch (greetErr) {
              console.warn('Initial proactive greeting trigger error:', greetErr);
            }
          } catch (sessionErr: any) {
            console.error('Failed to establish gemini-3.8-live connection:', sessionErr);
            clientWs.send(JSON.stringify({
              type: 'fallback_ready',
              error: sessionErr?.message,
              number,
              name,
              greetingText: greetingPrompt,
              message: 'কল সংযুক্ত হয়েছে। এআই অপারেটর কথা বলছেন...'
            }));

            // Also synthesize immediate audio greeting via TTS in fallback mode!
            (async () => {
              try {
                const ttsRes = await ai.models.generateContent({
                  model: 'gemini-3.8-flash-lite-tts',
                  contents: [{
                    role: 'user',
                    parts: [{
                      text: greetingPrompt,
                      speechMetadata: { style: 'Warm, polite, clear Bengali telephone operator greeting' }
                    }]
                  }],
                  config: {
                    responseModalities: ['AUDIO'],
                    speechConfig: {
                      voiceConfig: {
                        prebuiltVoiceConfig: { voiceName: voiceName || 'Zephyr' }
                      }
                    }
                  }
                });
                const b64 = ttsRes.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
                if (b64 && clientWs.readyState === WebSocket.OPEN) {
                  clientWs.send(JSON.stringify({
                    type: 'tts_audio',
                    audio: b64,
                    text: greetingPrompt
                  }));
                }
              } catch (ttsErr) {
                console.warn('Fallback greeting TTS synthesis error:', ttsErr);
              }
            })();
          }
        }

        // 2. AUDIO STREAM FROM CLIENT (16kHz PCM little endian base64)
        else if (msg.action === 'audio' && msg.audio && session) {
          session.sendRealtimeInput({
            audio: { data: msg.audio, mimeType: 'audio/pcm;rate=16000' },
          });
        }

        // 3. TEXT / DTMF KEYPAD INPUT DURING CALL
        else if (msg.action === 'dtmf' && msg.digit && session) {
          session.sendRealtimeInput({
            text: `[কলার ডায়াল প্যাডে বোতাম চাপলেন: '${msg.digit}']`,
          });
        }

        // 4. USER SPOKE TEXT MESSAGE
        else if (msg.action === 'user_text' && msg.text) {
          if (session) {
            session.sendRealtimeInput({
              text: msg.text,
            });
          } else {
            // Interactive fallback for simulated voice call
            try {
              const reply = await callGemini({
                contents: [{ role: 'user', parts: [{ text: msg.text }] }],
                systemInstruction: `${DESH_SYSTEM_PROMPT}\n\nসংক্ষিপ্ত, স্পষ্ট ও শ্রুতিমধুর টেলিফোন কথোপকথন বজায় রাখো। কলারের প্রশ্নের উত্তর অবিলম্বে মুখে বলো।`,
              });
              clientWs.send(JSON.stringify({ type: 'transcript', text: reply }));

              const ttsRes = await ai.models.generateContent({
                model: 'gemini-3.8-flash-lite-tts',
                contents: [{ role: 'user', parts: [{ text: reply.slice(0, 250) }] }],
                config: {
                  responseModalities: ['AUDIO'],
                },
              });
              const audioData = ttsRes.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
              if (audioData && clientWs.readyState === WebSocket.OPEN) {
                clientWs.send(JSON.stringify({ type: 'tts_audio', audio: audioData, text: reply }));
              }
            } catch (fallbackErr) {
              console.warn('Fallback conversational response error:', fallbackErr);
            }
          }
        }

        // 5. HANGUP ACTION
        else if (msg.action === 'hangup') {
          if (session) {
            try {
              session.close();
            } catch (e) {}
            session = null;
          }
          clientWs.send(JSON.stringify({ type: 'call_ended', reason: 'user_hangup' }));
        }
      } catch (e) {
        console.error('WebSocket message parsing error:', e);
      }
    });

    clientWs.on('close', () => {
      if (session) {
        try {
          session.close();
        } catch (e) {}
        session = null;
      }
    });
  });

  if (process.env.NODE_ENV === 'production') {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`দেশ AI Server with Live Calls listening on port ${PORT}`);
  });
}

start();
